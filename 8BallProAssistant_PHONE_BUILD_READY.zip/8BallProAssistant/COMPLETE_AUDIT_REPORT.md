> Superseded by FINAL_AUDIT_REPORT.md. This report said Android integration was blocked; that is no longer true. Kept for history.

# Complete audit report

## Scope of this increment
Batch 4 continuation. Labelled "Batch 5" in the request, but it is NOT Batch 5 complete: it covers only the pure-domain part of Phase 5. Android integration (Phases 2–4) is stopped, as the rules require.

## Baseline
- Batch 4 ZIP: `8BallProAssistant-batch4.zip`, SHA-256 `e70c4767fc0ba59aea7bebba3c8f63665f93a79cff42c2257036e22823e9fc0b`. Preserved as an immutable backup in `outputs/backup/`.
- Batch 3 ZIP: SHA-256 `b8bf07ce8d5967122ddf1b877a81fdaa99fcca942e6791cfb199a1107c43e34a`. Unchanged.
- Working copy: `work-batch5/8BallProAssistant`, extracted from the Batch 4 baseline.

## Phase 1: inspection
- Inspected all 85 entries of the Batch 4 baseline.
- Android Studio project: NOT PRESENT in `uploads/`. The baseline has no service, overlay window, MediaProjection, bitmap adapter, or manifest service/permission entries.
- Existing overlay code: `domain/overlay/OverlayStateMachine.kt` (pure state, no window). Reused, not duplicated.
- Existing capture code: `domain/capture/CaptureStateMachine.kt` (pure state, no MediaProjection). Reused, not duplicated.

## Phase 2–4: Android integration — STOPPED (blocked)
No Android code was written. Writing it now would duplicate the service, overlay, and capture code the request says already exists.

### Exact files required before integration can continue
1. `app/src/main/AndroidManifest.xml`: service declarations, permissions, and any existing overlay/capture entries.
2. The floating overlay service source (every `*Service.kt`).
3. Bubble and panel sources (Compose and view code, including the "8B" bubble and "Start Bubble / Stop / Capture One Frame" controls).
4. MediaProjection handler source (consent flow, VirtualDisplay, ImageReader, and any notification channel code).
5. Any existing bitmap or image conversion code.
6. `app/build.gradle.kts`, root `build.gradle.kts`, `settings.gradle.kts`, `gradle/libs.versions.toml`.
7. Gradle wrapper: `gradle/wrapper/gradle-wrapper.jar`, `gradlew`, `gradlew.bat`.
8. `res/` resources referenced by the above (strings, drawables, layouts, notification icon).
9. Existing tests for the Android layer, if any.

## Phase 5: pure-domain vision integration — DONE (unexecuted)
- New: `domain/analysis/FrameAnalysisCoordinator.kt`. Connects `FrameAdapter` → `AnalysisPipeline` → `DetectionToPhysics` → `AssistantPresenter`.
- Overlap guard: one analysis at a time. A call made during analysis is skipped.
- Run-state guard: frames are analysed only while RUNNING.
- Frame ordering: frame ids must increase.
- Stale-state guard: a rejected frame clears the previous analysis; a prediction is current only while its frame is the latest analysed frame; `invalidate()` drops all predictions.
- Failure guard: an unexpected exception is reported as Rejected and never leaves the gate stuck.

## Phase 6: testing
See `TEST_REPORT.md`. Kotlin tests were NOT executed. Only Python reference checks ran.

## Phase 7: delivery
See `BUILD_REPORT.md` and `CHANGELOG_BATCH5.md`.

## Remaining bugs and risks
- Kotlin code has never been compiled. Any compile error would appear here first.
- Android layer is entirely absent from this project. The floating UI, service, and capture flows are unverified.
- Gradle wrapper is missing; no build can run in this environment.
- Device tests (service lifecycle, permission denial and revocation, rotation, cleanup) are DEVICE TEST REQUIRED.
