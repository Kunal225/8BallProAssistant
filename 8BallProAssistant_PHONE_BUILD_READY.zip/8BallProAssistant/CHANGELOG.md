# 8BallProAssistant — Changelog

## 0.2.0 — 2026-11-16 (Session 3 — Claude)

Not compiled and not tested in this session (no network for Gradle or the Android SDK). See `BUILD_REPORT.md`.

### Added
- `AimSourceMachine` (`AimSource.AUTO_DETECTION` / `USER_MANUAL`): detection never overwrites a user aim;
  `AssistantSession.resumeAutoAim()` and `AssistantController.resumeAutoAim()` switch back. The source is in
  `AssistantSnapshot.aimSource`, and the panel and overlay show MANUAL AIM or AUTO AIM.
- `FrameIntake`: reserve, convert, close and submit for each captured image, with duplicate-image protection.
- `ReaderSwap`: replace an image reader and release the old one only after the new one is attached.
- `BallCollision.point`: where the two balls touch, the midpoint of the two centres (optional constructor
  parameter, so existing four-argument calls still compile).
- `TrajectoryRenderer.physicsPaths`, `firstCueContact`, `aimAngleDegrees`, `overlayLayers`.
- `gradlew` launcher for macOS and Linux.
- 75 new unit tests in 7 new files (written, not run).

### Fixed
- Screen capture could keep running, unknown to the session, when the consent dialog was approved after the user
  had pressed Stop capture. The consent activity now starts the service only when the session accepts the grant.
- `ScreenCaptureService` copied every captured frame before the throttle decided to drop it. It now reserves first.
- A failed orientation resize closed the whole capture and could leak the new image reader. The old reader is
  now kept, the new one is released, and capture continues.
- Any `RuntimeException` during projection setup could crash the service. Setup failures now end capture cleanly.
- The full-screen overlay window stayed on screen if the panel window could not be added.
- The overlay was shifted on devices with a display cutout. It now extends into the cutout.
- The overlay's green "physics" line was the aim line drawn a second time. It now draws the simulated frames.
- The overlay drew nothing for a manual aim. The yellow preview is now independent of the simulation.
- The overlay and panel showed invented numbers: `targetU * 360°` as an aim angle, and `0.0°` for angles that
  were never measured. They now show a measured or computed angle, or "n/a".
- The red contact dot was drawn where the cue ball stops. It now uses the physics collision event.
- Automatic aim detection overwrote the user's sliders on every analysed frame.
- Moving an aim slider ran the full shot simulation on the UI thread, and building a snapshot could wait for a
  running frame analysis. Slider changes are now applied on the analysis thread and merged, and the snapshot
  read no longer takes the analysis lock.
- Physics settings sliders lagged and wrote to disk on every drag event. They now follow the finger and save once.
- The aim sliders were labelled the wrong way round (U runs along the table length).
- Log calls inside the canvas draw loop were removed.
- Detection markers no longer cover the ball: rings are drawn outside the ball, because the overlay is part of
  the captured display.

## [Unreleased] — 2026-11-14 (Session 2 — Antigravity)

### Fixed

#### Critical — `LiveTrajectoryCanvas.kt`
- **Zero-length trajectory bug**: Both `cueCenter` and `aimTo` were previously computed from
  `snapshot.aim.targetU/V` (the user aim target), making them identical. The trajectory line was
  zero-length and invisible. `cueCenter` is now taken from the detected cue ball position in
  `snapshot.latestResult.balls`; it falls back to table centre only when no detection exists.
- **Physics frames now rendered**: The predicted cue-ball path is now drawn by iterating
  `ShotResult.frames`, converting each `PoolBall.position` from metres to normalised (u,v) with
  `position.x / table.length` and `position.y / table.width`. Object ball paths that move more
  than 2 screen pixels are also drawn.
- **Zero-length draw guard**: `drawLine` is now guarded by `lineLen > 1.0f` to prevent a
  degenerate draw call when cue ball and aim target coincide.
- **Detected balls drawn**: All detected balls from `latestResult.balls` are rendered at their
  normalised positions on the mini-table canvas.
- **Unused import cleanup**: Removed `BallPhysics`, `Vec3` imports that referenced types no
  longer needed after the fix (replaced by direct frame iteration).

#### `AssistantPanelContent.kt`
- **`ModifierParameter` lint fix**: Moved `modifier: Modifier = Modifier` to be the first optional
  parameter in `AssistantPanelContent()`, conforming to Compose API guidelines.

#### `TableSimulatorScreen.kt`
- **`AutoboxingStateCreation` lint fix**: Changed `mutableStateOf(0.0)` to
  `mutableDoubleStateOf(0.0)` to avoid unnecessary boxing of a primitive `Double`.

#### `AssistantNotifications.kt`
- **`ObsoleteSdkInt` lint fix**: Removed the `if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)`
  guard in `ensureChannels()`, which was redundant given `minSdk = 26 (Android O)`. Also removed
  the now-unused `import android.os.Build`.

---

## Previous Sessions

### Session 1 (prior Antigravity session)
- Gradle 8.9 wrapper created and verified.
- JDK 17 detected.
- Build succeeded (`assembleDebug`).
- 178 unit tests passed, 0 failed.
- Lint was cancelled.
- Full backup created: `8BallProAssistant_BACKUP_20261114_005911`.
- Source files were being inspected when the usage quota ended.
