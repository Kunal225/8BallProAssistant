# Missing files and integrity report

Generated: 2026-11-05 12:19 UTC

## Required files missing

- gradle/wrapper/gradle-wrapper.jar
- gradlew
- gradlew.bat

## Empty files

None found.

## Files added since baseline

- FINAL_AUDIT_REPORT.md
- FINAL_TEST_REPORT.md

## Files removed since baseline

No baseline supplied or nothing removed.

## Files modified since baseline

- BATCH4_AUDIT.md
- BUILD_REPORT.md
- BUILD_REPORT_BATCH4.md
- CHANGELOG.md
- CHANGELOG_BATCH3.md
- CHANGELOG_BATCH4.md
- CHANGELOG_BATCH5.md
- COMPLETE_AUDIT_REPORT.md
- TEST_REPORT_BATCH4.md
- app/src/main/java/com/eightballpro/assistant/android/capture/ScreenCaptureService.kt
- app/src/main/java/com/eightballpro/assistant/android/overlay/OverlayService.kt

## Kotlin structure (braces, package, truncation)

None found.

## Unresolved project imports

- app/src/main/java/com/eightballpro/assistant/android/notifications/AssistantNotifications.kt: com.eightballpro.assistant.R

## Gradle catalog references

None found.

## Resource references

None found.

## Manifest class references

None found.

## Domain/data classes without a matching *Test.kt

- app/src/main/java/com/eightballpro/assistant/data/settings/SettingsDataStore.kt
- app/src/main/java/com/eightballpro/assistant/domain/analysis/AnalysisPipeline.kt
- app/src/main/java/com/eightballpro/assistant/domain/analysis/ShotPrediction.kt
- app/src/main/java/com/eightballpro/assistant/domain/assistant/AssistantPresenter.kt
- app/src/main/java/com/eightballpro/assistant/domain/assistant/AssistantRunMachine.kt
- app/src/main/java/com/eightballpro/assistant/domain/mode/GameMode.kt
- app/src/main/java/com/eightballpro/assistant/domain/physics3d/PoolBall.kt
- app/src/main/java/com/eightballpro/assistant/domain/settings/AppSettings.kt
- app/src/main/java/com/eightballpro/assistant/domain/vision/ArgbImage.kt
- app/src/main/java/com/eightballpro/assistant/domain/vision/BallDetector.kt
- app/src/main/java/com/eightballpro/assistant/domain/vision/ConfidenceEvaluator.kt
- app/src/main/java/com/eightballpro/assistant/domain/vision/PerspectiveCalibration.kt
- app/src/main/java/com/eightballpro/assistant/domain/vision/TableBoundaryDetector.kt

## Placeholder or TODO markers in source (review: pending screens say so intentionally)

None found.

## Binary assets (3D models, textures, shaders, fonts, audio)

None. Batch 1 needs no 3D, texture, shader or audio assets, and none are referenced.

## Not verifiable here

- External library imports (23 package prefixes) were not resolved against dependency artifacts, because no dependency cache or network is available.
- Compose, DataStore and Navigation API signatures were not type-checked by a compiler.
