# 8BallProAssistant — Build Report

## Session 3 (2026-11-16): build and tests NOT executed

| Step | Result |
| --- | --- |
| `:app:assembleDebug` | **Not run.** The Gradle wrapper started and stopped at the download of Gradle 8.9: `java.net.UnknownHostException: services.gradle.org`. |
| `:app:testDebugUnitTest` | **Not run**, for the same reason. |
| `:app:lintDebug` | **Not run.** |
| Install and launch on a device | **Not run.** No device, no `adb`, no Android SDK. |

Environment of that session: OpenJDK 21, no Gradle, no Kotlin compiler, no Android SDK, no network.
No APK was built, so none is included.

### What was done instead (static checks only; none of these is a compile or a test run)

- Bracket, parenthesis and brace balance of all 102 Kotlin files, ignoring comments and strings: all balanced.
- Every `com.eightballpro.assistant` import in every Kotlin file resolves to a declaration in the matching
  package. The one unresolved name is the generated `R` class.
- The 22 files edited or created in this session were checked for project classes used without an import: none.
- Every external type, constructor and field used by the new code was compared with its definition
  (`PredictionView`, `AngleAnalysis`, `FrameOutcome`, `AnalysisResult`, `AimResult`, `PhysicsInput`, `Frame`,
  `CushionImpact`, `DetectedBall`, `CueStickResult`, `RawFrame`).
- The expected numbers in the contact-point tests were reproduced with an independent Python model of the
  engine's step order: head-on contact error 4e-8 m, 30-degree cut error 5e-5 m, full-shot error 1.5e-4 m,
  against test tolerances of 5e-4 m and 1e-3 m. This checks the expectations, not the Kotlin code.
- The new `gradlew` passes `sh -n` and starts the wrapper jar (it then stops at the same download).

### Tests written in this session (not executed)

75 new `@Test` methods in 7 files, on top of 203 existing ones (278 by `@Test` count):
`AimSourceMachineTest` (11), `AimSourceSessionTest` (8), `CaptureLifecycleSessionTest` (13),
`FrameIntakeTest` (11), `ReaderSwapTest` (8), `BallCollisionContactTest` (7), `TrajectoryRendererPathsTest` (17).

### What a real build still has to confirm

Compilation of every changed file; the 278 tests; `lintDebug`; behaviour on a device (rotation, revoked
permission, overlay on a notched display, slider drag while capturing). See `FINAL_HANDOVER_REPORT.md`.

---

## Earlier reports (historical, not re-verified in Session 3)

The text below was written in earlier sessions on another machine. It was not re-run here, and it describes the
code before the Session 3 changes.

## Build Environment
- **Compile SDK:** 35
- **Target SDK:** 35
- **Min SDK:** 26
- **Kotlin Version:** 2.0.20
- **Android Gradle Plugin:** 8.7.2
- **Compose BOM:** 2024.09.00
- **Java Compatibility:** JDK 17

## Build Execution Results

### Task 1: `:app:compileDebugKotlin`
- **Result:** SUCCESS
- **Errors:** 0

### Task 2: `:app:testDebugUnitTest`
- **Result:** SUCCESS
- **Tests Executed:** 168
- **Tests Passed:** 168
- **Tests Failed:** 0

### Task 3: `:app:assembleDebug`
- **Result:** SUCCESS
- **Artifact Generated:** `app/build/outputs/apk/debug/app-debug.apk`
