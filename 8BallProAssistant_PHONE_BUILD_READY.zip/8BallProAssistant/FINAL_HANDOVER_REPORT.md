# FINAL HANDOVER REPORT — 8BallProAssistant 0.2.0

Date: 2026-11-16. Work done directly on the supplied project (`8BallProAssistant_FINAL_HANDOVER.zip`).

## 1. Status in one paragraph

All three tasks and the earlier audit items were implemented in the existing code. **Nothing was compiled and no
test was run**, because the sandbox has no network, and Gradle, the Android Gradle Plugin, the Kotlin compiler and
the Android SDK could not be downloaded (the real Gradle wrapper was started and failed with
`UnknownHostException: services.gradle.org`). No APK was built. 75 new unit tests were written but have never been
executed. Treat every change below as unverified until you run the build in section 10. Static checks that were
possible are listed in section 8.

## 2. Files inspected

Read in full or in the relevant part:

- **Build and config:** `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`, `gradle.properties`,
  `gradle/libs.versions.toml`, `gradle-wrapper.properties`, `AndroidManifest.xml`, `res/values/themes.xml`,
  `res/values/strings.xml`.
- **Android layer:** `MainActivity`, `AssistantController`, `ScreenCaptureService`, `CaptureConsentActivity`,
  `ImageConverter`, `OverlayService`, `OverlayWindowController`, `ServiceComposeOwner`, `OverlayComposables`,
  `AssistantNotifications`, `AssistantPermissions`.
- **Domain:** `AssistantSession`, `AssistantRunMachine`, `AssistantPresenter`, `CaptureStateMachine`,
  `FrameAnalysisCoordinator`, `ShotPrediction`, `AnalysisPipeline`, `AngleAnalyzer`, `AimEstimator`,
  `RawFrameFactory`, `FrameAdapter`, `PoolPhysicsEngine`, `PoolBall`, `TableGeometry3D`, `Vec3`.
- **UI:** `GameOverlayCanvas`, `LiveTrajectoryCanvas`, `TrajectoryRenderer`, `AssistantPanelContent`,
  `AssistantControlScreen`, `PhysicsSettingsScreen`, `SettingsViewModel`, `SettingsDataStore`, and the slider
  part of `TableSimulatorScreen`.
- **Tests:** `FrameAnalysisCoordinatorTest`, `AssistantSessionTest`, `AimEstimatorTest`, `SyntheticImage`, the head of
  `PoolPhysicsEngineTest`, and a search of all tests for the APIs that were changed.
- **Documents:** the earlier reports in the project root were skimmed.

**Not inspected in detail:** the vision detectors (`BallDetector`, `CueStickDetector`, `TableDetector`,
`GameStateClassifier`), the Mode B import screens, the table simulator view model, and `tools/`.

## 3. Files modified (12) and added (11)

Modified, with changed lines:

| File | + / − |
| --- | --- |
| `android/AssistantController.kt` | +88 / −9 |
| `android/capture/CaptureConsentActivity.kt` | +10 / −5 |
| `android/capture/ScreenCaptureService.kt` | +158 / −60 (rewritten around the helpers) |
| `android/overlay/OverlayWindowController.kt` | +26 / −5 |
| `domain/analysis/FrameAnalysisCoordinator.kt` | +7 / −2 |
| `domain/assistant/AssistantSession.kt` | +37 / −8 |
| `domain/physics3d/PoolPhysicsEngine.kt` | +13 / −2 |
| `ui/assistant/AssistantPanelContent.kt` | +70 / −24 |
| `ui/common/GameOverlayCanvas.kt` | +168 / −88 |
| `ui/common/LiveTrajectoryCanvas.kt` | +9 / −23 |
| `ui/common/TrajectoryRenderer.kt` | +136 / −22 |
| `ui/settings/PhysicsSettingsScreen.kt` | +16 / −3 |

(All paths under `app/src/main/java/com/eightballpro/assistant/`.) Also modified: `app/build.gradle.kts`
(version 1 → 2, `0.2.0-contact-aim-capture`), `README.md`, `CHANGELOG.md`, `BUILD_REPORT.md`.

Added (main): `android/capture/ReaderSwap.kt`, `domain/assistant/AimSourceMachine.kt`,
`domain/frame/FrameIntake.kt`, `gradlew`, `FINAL_HANDOVER_REPORT.md`.

Added (tests, under `app/src/test/java/com/eightballpro/assistant/`): `android/capture/ReaderSwapTest.kt`,
`domain/assistant/AimSourceMachineTest.kt`, `AimSourceSessionTest.kt`, `CaptureLifecycleSessionTest.kt`,
`domain/frame/FrameIntakeTest.kt`, `domain/physics3d/BallCollisionContactTest.kt`,
`ui/common/TrajectoryRendererPathsTest.kt`.

Nothing was deleted. No dependency was added. The ZIP leaves out `.gradle/`, `.kotlin/`, build output,
`local.properties` (machine-specific SDK path) and `.idea/caches` and `workspace.xml`; Android Studio regenerates them.

## 4. Task 1 — Aim source tracking

- New `AimSource { AUTO_DETECTION, USER_MANUAL }` and a pure reducer `AimSourceMachine` with events `UserSet`,
  `Detected`, `ResumeAuto`, in the same style as `AssistantRunMachine` and `CaptureStateMachine`.
- `AssistantSession` keeps one `AimState` (aim and source). `setAim` → `USER_MANUAL`. A detected aim is applied only
  while the source is `AUTO_DETECTION`. `resumeAutoAim()` switches back; it applies a target from the latest frame
  if there is one, and otherwise keeps the current aim until the next detection.
- `AssistantSnapshot` has new fields `aimSource` and `autoAimAvailable` (defaulted, so existing code compiles).
- UI: the panel shows "Aim: MANUAL (set by you)" or "Aim: AUTO (...)" and a **Use auto aim** button. The overlay
  badge shows MANUAL AIM or AUTO AIM.
- Races: the session methods are synchronised. `AssistantController.setAim` shows the new aim at once, merges bursts
  of slider events, and applies them on the single analysis thread. While a newer aim is waiting, the published
  snapshot says `USER_MANUAL` and hides the older shot, so the overlay never draws a simulation that belongs to a
  different aim than the one on screen.
- Decision to review: adjusting **power** also counts as setting the aim by hand (your requirement says "adjusts
  or sets the aim"). If you want power to leave auto aim alone, that is a one-line change in `AimSourceMachine`.
- Manual aim is not reset by pause, resume, stop, capture end, a new capture, overlay refresh or Activity
  recreation (state lives in the process-wide controller). It is **not** kept across process death.

## 5. Task 2 — ScreenCaptureService resource safety

Old behaviour: every image was converted to a byte array, then the session decided to drop most of them; a failed
rotation closed the whole capture and could leak the new reader; only two exception types were caught while the
projection was set up.

New behaviour:

- **Frames** (`FrameIntake`, pure Kotlin, generic over the image type): reserve first, convert only reserved
  images, drop an image whose timestamp equals the previous reserved one, close every image exactly once (before the
  frame is submitted), and end every reservation with exactly one submit (a null frame releases it).
  `AssistantController.reserveFrame` / `submitReservedFrame` are new; `offerFrame` still works.
- **Rotation** (`ReaderSwap`, pure Kotlin): create the new reader, attach it to the display, and only then release
  the old one. If create or attach fails, the new reader is released and the display is pointed back at the old
  reader (`KeptPrevious`, capture continues, orientation stays unchanged so the next change retries). Only if the old
  reader cannot be restored is the capture ended (`Failed`).
- **Locking:** projection, display and reader are `@Volatile` and changed under one lock. No call into
  `AssistantController` happens while it is held, so there is no lock-order problem.
- **Start:** foreground first, then projection, callback (before the display, as Android 14 requires), display and
  reader. Any `RuntimeException` ends the capture and releases what exists. A second start replaces the running
  session after releasing it; the state machine already refuses a second request while one runs.
- **Stop paths:** user stop, system stop, revoked permission, failure and `onDestroy` all go through one idempotent
  `releaseCapture`. The projection callback is unregistered before `stop()`, so it cannot fire back.
- **Consent activity:** it starts the service only when `onConsentResult(true)` returns no refusal. Before, a grant
  that arrived after the user had pressed Stop capture still started a capture the session knew nothing about.
- **Overlay window:** the full-screen drawing window is removed if the panel window fails to attach, and it extends
  into display cutouts so it lines up with the captured frame.

## 6. Task 3 — BallCollision contact point

Search result: `BallCollision` was constructed in one place (`PoolPhysicsEngine.step`), imported but unused in
`GameOverlayCanvas`, and read nowhere else; there is no serialisation. Tests only count events.

| | Old | New |
| --- | --- | --- |
| Event | `BallCollision(time, ballA, ballB, closingSpeed)`, no position | same, plus `point: Vec3? = null` |
| Contact marker (panel) | last point of the cue path, which is where the cue ball **stops** after the whole simulation | `firstCueContact` from the collision event |
| Contact marker (overlay) | the aim line's end point, or the geometric ghost-ball point | the same collision event |
| Value | none | `(a.position + b.position) * 0.5`, the midpoint of the two centres when the contact is detected |

An intermediate version in this session used the surface point `a.position + n * radius`. It was replaced; a search
confirms it no longer exists. There is now one producer (engine, one line) and one consumer function
(`TrajectoryRenderer.firstCueContact`), used by both canvases. Everything is in table metres, mapped with the same
`metresToNormalised` as the simulated frames. `AngleAnalysis.impactPoint` is a separate geometric idea and is used
only for the purple pocket guide.

Accuracy: the point is detected one 0.2 ms step after the overlap starts, so it is within about half the distance
travelled in one step of the exact touching point (at most about 0.3 mm at 3 m/s).

## 7. Other fixes from the audit

Overlay: the green "physics" line was the aim line drawn twice, and nothing was drawn for a manual aim; invented
numbers (`targetU × 360°`, `0.0°` for unmeasured angles) were shown; markers filled the balls, changing what the
next captured frame sees. Now: yellow = aim preview only; green/orange/red = simulated shot only; purple = geometry;
rings outside the balls; "n/a" for angles that were not measured. Sliders: the aim sliders no longer get overwritten
by detection, their labels were the wrong way round, and the shot simulation no longer runs on the UI thread for
each drag event; the physics-settings sliders follow the finger and save once on release. Smaller: `Log.d` calls in
the draw loop removed; frame analysis no longer holds a lock that the UI thread waits on when it builds a snapshot.

These were found by reading the code. None was reproduced on a device, and the size of the UI-thread stall was not
measured.

## 8. Verification actually done

- **Not run:** `:app:assembleDebug`, `:app:testDebugUnitTest`, `:app:lintDebug`, device install. Reason: no network.
- **Static checks (all passed):** bracket balance of 102 Kotlin files; every project import resolves (except the
  generated `R`); no missing project imports in the 22 touched files; every external signature used was compared with
  its definition; `gradlew` syntax check and wrapper start.
- **Independent numeric check:** the contact-point test values were reproduced in Python (errors 4e-8, 5e-5 and
  1.5e-4 m against tolerances 5e-4 and 1e-3 m).
- These checks cannot find type errors, smart-cast problems, overload ambiguity or runtime failures.

## 9. Tests written (75 new, never executed)

| Your scenario | Test coverage |
| --- | --- |
| A. Manual aim unchanged by a new detection | `AimSourceMachineTest`, `AimSourceSessionTest` |
| B. Back to auto allows updates | same files |
| C. Rapid manual input vs delayed detection | machine test (50 interleaved events); session test with a detector thread |
| D. Rotation does not leak readers | `ReaderSwapTest` (incl. 10 mixed rotations, at most one open reader) |
| E. Failed replacement keeps the old reader | `ReaderSwapTest` |
| F. Only reserved frames processed | `FrameIntakeTest`, `CaptureLifecycleSessionTest` |
| G. Existing BallCollision consumers | `BallCollisionContactTest` (old 4-argument form, destructuring, counts) |
| H. Contact point accuracy | `BallCollisionContactTest` (head-on, 30° cut, either ball order, full shot), `TrajectoryRendererPathsTest` |
| I. Overlay stable | only the pure parts (`overlayLayers`, paths, angle) are tested; the Compose overlay needs a device |

Also covered: first capture, repeated sessions, stop and restart, revoked permission, capture failure, a grant that
arrives after Stop, denied consent, throttling, pause.

## 10. Remaining issues and risks

1. **Unverified compilation.** Possible problem spots: sealed generic `ReaderSwap.Outcome` with `data object`,
   `when` over it in the service, local functions using `DrawScope` inside `Canvas`, `String.format(Locale, ...)`.
2. **Overlay feedback.** The overlay is part of the captured display. Rings reduce the effect; they do not remove
   it. Choosing "A single app" in the Android 14 capture dialog avoids it.
3. **Shot simulation cost.** 0.2 ms steps for up to 8 s, with many allocations, run under the session lock on the
   analysis thread. Slider drags no longer wait for it, but a button press during a simulation still can. Measure on
   a device; moving the simulation outside the lock is the next step.
4. **Detection quality is unproven.** Capture is scaled to 720 px, analysis to 480 px, so a ball is only a few pixels
   wide; the aim estimator scans 12–45 px around the cue ball. Not validated on real game frames.
5. **Stale auto aim in the panel.** The panel canvas still draws the last auto aim's simulation after detection is
   lost; the overlay hides it.
6. **Manual aim is in memory only.** It survives Activity and overlay recreation, not process death.
7. **Not handled:** Android 14 content-resize callbacks, a launcher icon (`android:icon` is missing), release
   build and minification checks, and the lint baseline.
8. **`gradlew`** is a minimal launcher, not Gradle's generated script. Run `gradle wrapper` for the stock one.
9. **Older reports** in the project root contradict each other and were not re-verified. `BUILD_REPORT.md` now
   separates them from this session.

## 11. Android Studio build instructions

1. Unzip. Open the folder `8BallProAssistant` with **File → Open**. Use Android Studio Ladybug (2024.2) or newer.
2. **Settings → Build Tools → Gradle → Gradle JDK:** JDK 17 or newer. Let Gradle sync (needs internet the first time:
   Gradle 8.9, Android Gradle Plugin 8.7.2, Kotlin 2.0.20). Install **Android SDK Platform 35** and its build tools if asked.
   `local.properties` is created by Android Studio.
3. Terminal, in the project folder (Windows `gradlew.bat`, macOS/Linux `./gradlew`):
   - `:app:assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
   - `:app:testDebugUnitTest` (new tests only: add `--tests "*AimSource*" --tests "*FrameIntake*" --tests "*ReaderSwap*" --tests "*BallCollisionContact*" --tests "*CaptureLifecycle*" --tests "*TrajectoryRendererPaths*"`)
   - `:app:lintDebug`
4. Install: `adb install -r app/build/outputs/apk/debug/app-debug.apk`, or press Run with a device attached.
5. On the device: allow **Display over other apps**, allow notifications (Android 13+), acknowledge the own-game
   notice, start capture and approve the system dialog.
6. Device checks worth doing: drag an aim slider while capture runs; set a manual aim and watch the cue stick move
   (the aim must stay); press **Use auto aim**; rotate the device while capturing; press Stop capture while the system
   dialog is open, then approve it (capture must not start); revoke capture from the status bar; open the overlay on a
   device with a camera cutout.

If the build fails, send the first compiler error; the changed files are listed in section 3.
