# 8 Ball Pro Assistant

A native Android app (Kotlin, Jetpack Compose) with a floating assistant that can analyse a pool table on
your own screen and show an estimated shot. It is for your own game or an authorised test environment.

## Status

**The latest changes were not compiled, and no tests were run for them.** They were made in an environment with
no network, so Gradle, the Android Gradle Plugin, the Kotlin compiler and the Android SDK could not be
downloaded. `BUILD_REPORT.md` has the exact attempt and what was checked instead. Older reports in this folder
describe builds on another machine and were not re-verified. Open the project in Android Studio and run the
steps in `BUILD_INSTRUCTIONS.md` (`:app:assembleDebug`, `:app:testDebugUnitTest`, `:app:lintDebug`) before you
rely on it. `FINAL_HANDOVER_REPORT.md` lists every change, the new tests, and the known risks.

## Latest changes (version 0.2.0)

- **Aim source.** The aim is either `AUTO_DETECTION` or `USER_MANUAL`. Moving an aim control, including power,
  makes it manual, and detection then never overwrites it. **Use auto aim** in the panel hands it back. The
  panel and the overlay badge say **MANUAL AIM** or **AUTO AIM**.
- **Overlay layers.** Yellow dashed line: the aim preview, cue ball to aim target. Green and orange lines and
  the red dot: the simulated shot only, drawn only while a current prediction exists. Purple: a geometric
  pocket guide for the auto-detected aim. Detected balls get rings drawn outside the ball.
- **Capture safety.** Frames are copied only after the session reserves them. Every image is closed exactly
  once. A rotation puts a new image reader in place before releasing the old one, and keeps the old one if the
  replacement fails.
- **Contact point.** Ball-ball collision events now carry the point where the two balls touch, the midpoint of
  the two centres. The red marker uses it.
- `gradlew` (macOS and Linux launcher) was added next to `gradlew.bat`.

## What it does

- **Floating bubble.** A small "8B" bubble over other apps. Drag it, tap it to open the panel. It snaps to the
  nearest screen edge and remembers its position.
- **Floating panel.** Shows analysis status, capture status, the detected table and balls, and an estimated
  shot. Start, pause, resume and stop analysis. Hide the panel back to the bubble, or close the assistant.
- **Screen capture, with your approval.** Capture starts only after you approve the system dialog. A
  notification shows while capture runs, with a Stop action. Stopping, revoking the permission, or the system
  ending capture all stop analysis and release every resource.
- **Analysis.** Each captured frame is converted, the table and balls are detected, and detections are
  shown with confidence and warnings. The app does not invent results: a failed or low-confidence frame is
  reported as such.
- **Prediction.** You choose an aim target on the table and a power. The app simulates the shot from the
  detected cue ball. It is labelled as an estimate, and it is hidden when the cue ball is not confidently
  detected or when the frame it came from is no longer current.

## What it does not do

- It does not capture the screen without your approval, and it does not capture other apps in the background.
- It does not read game memory, bypass anti-cheat, or automate shots.
- It does not upload screenshots. Frames are processed in memory and then discarded.
- It is not calibrated to any specific game. Detection uses a default blue felt colour and must be checked.
- Predictions are not validated against measured shots and must not be treated as reliable.

## Setup

1. Create the Gradle wrapper (see `BUILD_INSTRUCTIONS.md`).
2. Open the project in Android Studio and sync Gradle.
3. Run the app on an Android device with Android 8.0 (API 26) or later. Android 14 or later is the target.
4. Open **Floating Assistant** from the dashboard. Allow drawing over other apps and allow notifications.
5. Tick the authorisation checkbox, press **Start capture** and approve the system dialog.
6. Press **Show floating assistant**, then **Start** in the panel.

## Permissions

| Permission | Why |
|---|---|
| SYSTEM_ALERT_WINDOW | Draw the bubble and panel over other apps. Granted by you in system settings. |
| FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE | Keep the bubble service running while you use the bubble. |
| FOREGROUND_SERVICE_MEDIA_PROJECTION | Keep the capture service running while capture is approved. |
| POST_NOTIFICATIONS | Show the foreground-service notifications on Android 13 and later. |

The app has no INTERNET permission. Nothing leaves the device.

## Project layout

- `domain/` — pure Kotlin: physics, vision, analysis, assistant session, state machines. Tested on the JVM.
- `android/` — Android layer: overlay service and window, capture service, consent activity, controller, notifications, permissions.
- `ui/` — Compose screens, including the shared assistant panel.
- `app/src/test/` — JVM unit tests and the integration-style tests of the domain layer.
- `tools/` — Python reference models used to check the algorithms.

## Limitations

See `CHANGELOG.md` (Known issues) and `MISSING_FILES_REPORT.md`.
