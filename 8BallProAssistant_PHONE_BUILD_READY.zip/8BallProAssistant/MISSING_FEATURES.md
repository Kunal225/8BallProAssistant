# 8BallProAssistant — Missing Features & Known Limitations

## Missing Features Inventory
- **Unimplemented Modules:** 0 (All 12 destinations in `AppDestination.kt` are fully implemented and connected).
- **TODOs / FIXMEs:** 0 remaining in `app/src/main`.
- **Placeholder Screens:** 0 (All pending placeholder screens replaced with interactive domain-connected screens).

## Known Limitations & Device Verification
1. **Device MediaProjection Consent:** On Android physical devices, `ScreenCaptureService` requires interactive user consent via system dialog before screen capture begins.
2. **Overlay Drawing Permission:** `OverlayService` requires `SYSTEM_ALERT_WINDOW` permission enabled in system settings.
3. **Hardware Acceleration:** 3D table rendering operates via Compose Canvas viewport mapping; GPU-accelerated GLES shaders can be added as an optional performance enhancement for low-end hardware.
