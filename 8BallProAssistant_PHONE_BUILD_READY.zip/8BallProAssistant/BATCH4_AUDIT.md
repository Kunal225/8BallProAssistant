> Superseded by FINAL_AUDIT_REPORT.md. Describes the Batch 4 state, before the Android layer existed. Kept for history.

# Batch 4 audit

## Baseline
- Original: `8BallProAssistant-batch3.zip`, SHA-256 `b8bf07ce8d5967122ddf1b877a81fdaa99fcca942e6791cfb199a1107c43e34a`. Not modified.
- Backups: `outputs/backup/8BallProAssistant-batch3-BACKUP-20261105T115045Z.zip` and `backups/batch3-pre-batch4-20261105T115045Z/`.
- Working copy: `work-batch4/8BallProAssistant`. Batch 4 changes are additions only.

## Reuse map (existing Batch 3 code, reused without modification)

| Existing module | Used by Batch 4 | Notes |
|---|---|---|
| `domain/capture/CaptureStateMachine` | Capture consent and stop | Reused as-is. Run state wraps it, not replaces it. |
| `domain/overlay/OverlayStateMachine` | Bubble and panel state | Reused as-is. No Android window code exists yet to bind it to. |
| `domain/mode/ModePolicy` | Live capture gating | Reused as-is. |
| `domain/vision/*` (boundary, ball detection, calibration, confidence) | Frame analysis | Reused as-is through `AnalysisPipeline`. |
| `domain/analysis/AnalysisPipeline`, `DetectionToPhysics`, `ShotPrediction` | Detection to prediction | Reused as-is. |
| `domain/physics3d/*` | Simulation | Reused as-is. Not modified. |

## Components NOT found in this project (blocked)
- Floating bubble window and drag handling.
- Floating assistant panel (Compose).
- Foreground overlay service and its notification channel.
- MediaProjection consent flow, VirtualDisplay, and ImageReader.
- Manifest entries: service, overlay permission, foreground-service permissions.

These exist only in the Android Studio project described in your message, which has not been supplied. Writing new versions now would create duplicate services, which you asked me to avoid.

## Components added in Batch 4 (new files, independent of Android)
- `domain/frame/FrameAdapter.kt`: RawFrame to ArgbImage with validation, crop and rotation in one pass.
- `domain/assistant/AssistantRunMachine.kt`: Start, Pause, Resume and Stop, with frame gating against overlapping work.
- `domain/assistant/AssistantPresenter.kt`: panel text. Never shows a prediction without a confident cue, and never reports HIGH confidence.

## Gradle and manifest audit (J)
- AGP 8.7.2, Kotlin 2.0.20, Compose compiler plugin, compileSdk 35, minSdk 26, Gradle 8.9 (from the wrapper properties). Compatibility is from documented ranges, NOT checked against a live repository.
- Gradle wrapper JAR, `gradlew`, `gradlew.bat`: MISSING. Cannot be restored offline.
- `AndroidManifest.xml`: launcher activity only. No service or permission entries. No INTERNET permission (intended for the offline-first design).

## Not started / deferred
- Bitmap adapter for Android types (blocked on the Android code).
- Vision integration with live frames (depends on the adapter above).
- Floating UI fixes, service lifecycle, and MediaProjection audit (blocked on the Android code).
- Physics audit beyond the existing Python checks.
