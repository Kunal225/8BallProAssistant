# 8BallProAssistant — Fixes Summary

**Session:** Antigravity Session 2 — 2026-11-14  

---

## Fix 1 — CRITICAL: Zero-length trajectory line

**File:** [`ui/common/LiveTrajectoryCanvas.kt`](app/src/main/java/com/eightballpro/assistant/ui/common/LiveTrajectoryCanvas.kt)  
**Severity:** Critical — the core visual feature (trajectory) was invisible.

### Root Cause
```kotlin
// BEFORE — both endpoints identical (aim target used as cue ball position)
val cueCenter = toScreen(snapshot.aim.targetU * table.length, snapshot.aim.targetV * table.width)
val aimTo     = toScreen(snapshot.aim.targetU * table.length, snapshot.aim.targetV * table.width)
// cueCenter == aimTo → drawLine() produced a zero-length line, nothing was visible
```

The `AimSettings.targetU/V` fields define **where to aim** (the aim destination). They are **not** the cue ball position. The cue ball position comes from `snapshot.latestResult.balls.firstOrNull { it.cls == BallClass.CUE }.centre`.

### Fix Applied
```kotlin
// AFTER — cueCenter from detected cue ball, aimTo from aim sliders
val detectedCueBall = result?.balls?.firstOrNull { it.cls == BallClass.CUE }
val (cueU, cueV) = if (detectedCueBall != null) {
    detectedCueBall.centre.x to detectedCueBall.centre.y
} else {
    0.5 to 0.5  // fallback: table centre, visually distinct when no detection
}
val cueCenter = toScreen(cueU, cueV)
val aimTo     = toScreen(snapshot.aim.targetU, snapshot.aim.targetV)
```

### Additional Improvements in Same Fix
- Physics `ShotResult.frames` now used to draw the predicted cue-ball path.
- Object ball paths that move > 2 px are also drawn in orange.
- Zero-length guard before `drawLine` (`lineLen > 1.0f`).
- All detected balls drawn at their normalised (u,v) positions.

---

## Fix 2 — `ModifierParameter` lint violation

**File:** [`ui/assistant/AssistantPanelContent.kt`](app/src/main/java/com/eightballpro/assistant/ui/assistant/AssistantPanelContent.kt)  
**Severity:** Warning — Compose API convention.

```kotlin
// BEFORE
fun AssistantPanelContent(onHide: ..., onClose: ..., modifier: Modifier = Modifier, scrollable: ...)

// AFTER
fun AssistantPanelContent(modifier: Modifier = Modifier, onHide: ..., onClose: ..., scrollable: ...)
```

---

## Fix 3 — `AutoboxingStateCreation`

**File:** [`ui/table/TableSimulatorScreen.kt`](app/src/main/java/com/eightballpro/assistant/ui/table/TableSimulatorScreen.kt)  
**Severity:** Warning — avoidable boxing allocation in Compose state.

```kotlin
// BEFORE
var playTime by remember { mutableStateOf(0.0) }

// AFTER
var playTime by remember { mutableDoubleStateOf(0.0) }
```

---

## Fix 4 — `ObsoleteSdkInt` / unused import

**File:** [`android/notifications/AssistantNotifications.kt`](app/src/main/java/com/eightballpro/assistant/android/notifications/AssistantNotifications.kt)  
**Severity:** Warning — dead code.

```kotlin
// BEFORE
import android.os.Build
fun ensureChannels(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return  // redundant: minSdk=26=O
    ...
}

// AFTER
// (import removed, guard removed — notification channels always available on API 26+)
fun ensureChannels(context: Context) {
    val manager = context.getSystemService(NotificationManager::class.java)
    ...
}
```

---

## Modules NOT Changed (Verified Working)

The following modules were inspected and found to be **correct** — no changes were made:

- `PoolPhysicsEngine.kt` — fixed-step 3D simulation, floor/ball/cushion physics
- `ContactSolver.kt` — impulse resolution, friction
- `CueStrike.kt` — cue impulse model
- `TableGeometry3D.kt` — pocket capture, cushion planes
- `AnalysisPipeline.kt` — image analysis pipeline
- `AimEstimator.kt` — radial ray aim detection
- `AngleAnalyzer.kt` — cut/impact/rebound geometry
- `BallDetector.kt`, `GameStateClassifier.kt` — vision heuristics
- `AssistantSession.kt` — session state machine, frame gating
- `AssistantRunMachine.kt` — run/pause/stop state machine
- `OverlayStateMachine.kt` — bubble/panel overlay state
- `OverlayWindowController.kt` — WindowManager integration
- `ServiceComposeOwner.kt` — Compose lifecycle for Service
- `ScreenCaptureService.kt` — MediaProjection/VirtualDisplay
- `AssistantController.kt` — process-wide singleton, snapshot publication
- `SettingsDataStore.kt` — DataStore settings persistence
- `GameOverlayCanvas.kt` — full-screen overlay (pocket normalisation correct)

---

## Build Verification

| Command | Result |
|---------|--------|
| `gradlew.bat :app:assembleDebug` | ✅ BUILD SUCCESSFUL |
| `gradlew.bat :app:testDebugUnitTest` | ✅ 178 passed, 0 failed |
| `gradlew.bat :app:lintDebug` | ✅ 0 errors, ~30 warnings (informational only) |
