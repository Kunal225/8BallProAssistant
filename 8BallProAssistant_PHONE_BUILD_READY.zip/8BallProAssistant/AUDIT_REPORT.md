# 8BallProAssistant — Source Code Audit Report

**Session date:** 2026-11-14  
**Audited by:** Antigravity (Senior Android/Kotlin Engineer, Computer Vision & Physics)  
**Project root:** `C:\Users\anjal\Downloads\8BallProAssistant-recovery-final-v2\8BallProAssistant`

---

## 1. Files Inspected

| File | Lines | Status |
|------|-------|--------|
| `ui/common/LiveTrajectoryCanvas.kt` | 138→185 | **FIXED** |
| `ui/settings/PhysicsSettingsScreen.kt` | 130 | OK |
| `ui/settings/AppSettingsScreen.kt` | 78 | OK |
| `android/overlay/ServiceComposeOwner.kt` | 56 | OK |
| `domain/assistant/AssistantRunMachine.kt` | 47 | OK |
| `domain/settings/AppSettings.kt` | 10 | OK |
| `domain/physics3d/PoolPhysicsEngine.kt` | 204 | OK |
| `domain/physics3d/PoolBall.kt` | 32 | OK |
| `domain/physics3d/CueStrike.kt` | 48 | OK |
| `domain/physics3d/TableGeometry3D.kt` | 87 | OK |
| `domain/physics3d/Vec3.kt` | 35 | OK |
| `domain/physics3d/ContactSolver.kt` | 134 | OK |
| `domain/analysis/AnalysisPipeline.kt` | 227 | OK |
| `domain/analysis/AngleAnalyzer.kt` | 179 | OK |
| `domain/analysis/ShotPrediction.kt` | 103 | OK |
| `domain/analysis/FrameAnalysisCoordinator.kt` | 137 | OK |
| `domain/assistant/AssistantSession.kt` | 275 | OK |
| `domain/assistant/AssistantPresenter.kt` | 80 | OK |
| `domain/overlay/OverlayStateMachine.kt` | 120 | OK |
| `android/capture/ScreenCaptureService.kt` | 279 | OK |
| `android/overlay/OverlayWindowController.kt` | 234 | OK |
| `android/AssistantController.kt` | 129 | OK |
| `ui/common/GameOverlayCanvas.kt` | 191 | OK |
| `ui/assistant/AssistantPanelContent.kt` | 256 | **FIXED** |
| `ui/table/TableSimulatorScreen.kt` | 474 | **FIXED** |
| `android/notifications/AssistantNotifications.kt` | 70 | **FIXED** |
| `data/settings/SettingsDataStore.kt` | 82 | OK |
| `domain/vision/AimEstimator.kt` | 129 | OK |
| `domain/vision/BallDetector.kt` | 153 | OK |

---

## 2. Confirmed Bugs Found and Fixed

### Bug 1 — CRITICAL: Zero-length trajectory line in `LiveTrajectoryCanvas.kt`

**Root cause:**  
Both `cueCenter` and `aimTo` were computed from `snapshot.aim.targetU` and `snapshot.aim.targetV`:
```kotlin
// BEFORE (buggy):
val cueU = snapshot.aim.targetU     // aim target, NOT cue ball position
val cueV = snapshot.aim.targetV
val cueCenter = toScreen(cueU * table.length, cueV * table.width)
val aimTo = toScreen(snapshot.aim.targetU * table.length, snapshot.aim.targetV * table.width)
// cueCenter == aimTo → zero-length line, nothing drawn
```

**Fix applied:**  
`cueCenter` now reads the detected cue ball position from `snapshot.latestResult.balls` (the detected ball's normalised `u,v`). Falls back to table centre (0.5, 0.5) only when no detection exists.  
`aimTo` correctly continues to use `snapshot.aim.targetU/V` (the user's aim sliders / auto-detected target).

**Additional improvements in the same fix:**
- Physics `ShotResult.frames` are now used to draw the **actual predicted cue-ball path** (and object ball paths) through each simulation frame, converted from metres → normalised (u,v).
- Zero-length guard (`lineLen > 1.0`) prevents `drawLine` from being called when the two points are identical.
- All detected balls are drawn at their true positions.

### Bug 2 — `ModifierParameter` lint violation in `AssistantPanelContent.kt`

Compose convention: `modifier: Modifier` must be the **first** optional parameter. Reordered signature.

### Bug 3 — `AutoboxingStateCreation` in `TableSimulatorScreen.kt`

`mutableStateOf(0.0)` unnecessarily boxes `Double`. Fixed to `mutableDoubleStateOf(0.0)`.

### Bug 4 — `ObsoleteSdkInt` in `AssistantNotifications.kt`

`if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return` is redundant since `minSdk = 26 == O`. Removed the check and the unused `import android.os.Build`.

---

## 3. Coordinate System Verification

### `AimSettings` model
- `targetU` ∈ [0,1] — normalised position **along table length** (the aim destination).
- `targetV` ∈ [0,1] — normalised position **along table width** (the aim destination).
- These fields define **where to aim**, NOT where the cue ball is.

### Cue ball position
- Comes from `snapshot.latestResult.balls` (detected), field `DetectedBall.centre: Point2D` where `x,y ∈ [0,1]`.
- `AnalysisPipeline` → `PerspectiveCalibration.toNormalized()` maps image pixels → normalised (u,v).

### Physics world
- `PoolBall.position` is in metres. Origin at top-left corner of the playing surface.
- `TableGeometry3D.length` / `.width` are in metres.
- Conversion: `metres_x / table.length` → normalised u.

### Pocket coordinates
- `Pocket.x`, `Pocket.y` are in metres.
- `GameOverlayCanvas` correctly divides by `table.length` / `table.width` before calling `toScreen(u, v)`.

---

## 4. Modules Verified Working

| Module | Verdict |
|--------|---------|
| `PoolPhysicsEngine` — step, simulate, rest detection | ✅ Correct |
| `ContactSolver` — floor friction, ball-pair impulse, cushion restitution | ✅ Correct |
| `CueStrike.apply()` — impulse, angular velocity | ✅ Correct |
| `TableGeometry3D` — pocket capture, cushion crossing | ✅ Correct |
| `AnalysisPipeline` — table detection, ball detection, aim estimation | ✅ Correct |
| `AimEstimator` — radial-ray scan for aiming guidelines | ✅ Correct |
| `AngleAnalyzer` — cut angle, impact, rebound, pocket targeting | ✅ Correct |
| `AssistantRunMachine` — STOPPED/RUNNING/PAUSED state machine | ✅ Correct |
| `AssistantSession` — frame gating, single-flight analysis, prediction | ✅ Correct |
| `OverlayStateMachine` — bubble/panel transitions, drag, snap | ✅ Correct |
| `ServiceComposeOwner` — lifecycle, saved-state for service-hosted ComposeView | ✅ Correct |
| `ScreenCaptureService` — MediaProjection lifecycle, orientation change | ✅ Correct |
| `SettingsDataStore` — DataStore preferences, out-of-range fallback | ✅ Correct |
| `GameOverlayCanvas` — full-screen transparent overlay, pocket normalisation | ✅ Correct |

---

## 5. Remaining Lint Warnings (non-blocking, informational)

| Warning | Location | Explanation |
|---------|----------|-------------|
| `InlinedApi` — `POST_NOTIFICATIONS` | `AssistantPermissions.kt:26` | Requires API 33, minSdk 26. Add `@SuppressLint` or runtime guard if desired. |
| `InlinedApi` — `FOREGROUND_SERVICE_TYPE_SPECIAL_USE` | `OverlayService.kt:30` | Requires API 34. |
| `InlinedApi` — `FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION` | `ScreenCaptureService.kt:220` | Requires API 29. |
| `AndroidGradlePluginVersion` | `libs.versions.toml` | AGP 8.7.2 → 9.5.1 available. Not upgraded to avoid breaking changes. |
| `GradleDependency` | `libs.versions.toml` | Multiple library updates available. |
| `DataExtractionRules` | `AndroidManifest.xml` | Add `android:dataExtractionRules` for API 31+ backup configuration. |
| `MissingApplicationIcon` | `AndroidManifest.xml` | No default app icon declared. `ic_assistant` is used in notifications. |

**Total: 0 errors, ~30 warnings (all informational or dependency-version notices).**

---

## 6. Known Limitations

1. **Vision pipeline is heuristic-based** — `AimEstimator` uses brightness thresholding on radial rays. It works well for games with bright white aim guides but may not detect subtle or transparent aim lines.
2. **Physics model uses fixed coefficients** — Friction, restitution are tunable but not calibrated against a real 8-ball table. Results are estimates only.
3. **No app launcher icon** — `ic_assistant` exists in drawable but no launcher icon is set in the manifest. App installs without icon.
4. **Screen capture requires API 26+** — This is the stated minSdk, so no issue in production.
5. **`InlinedApi` guards** — All `InlinedApi` usages are safe because the platform already enforces API level through `startForeground` / notification channel APIs; the checks are correct at runtime.
