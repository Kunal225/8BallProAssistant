# Build instructions

## Prerequisites
- Android Studio Ladybug (2024.2.1) or newer.
- JDK 17 (the JDK bundled with Android Studio is fine).
- Android SDK Platform 35 and build tools, from SDK Manager.
- A local Gradle 8.9 install, to create the wrapper once.

## 1. Create the Gradle wrapper (required once)
This package does not include `gradle-wrapper.jar`, `gradlew` or `gradlew.bat`. They cannot be generated
without Gradle and network access. From the project root:

    gradle wrapper --gradle-version 8.9

On macOS/Linux, then run `chmod +x gradlew`.

## 2. Run the checks

    .\gradlew.bat clean testDebugUnitTest assembleDebug     (Windows)
    ./gradlew clean testDebugUnitTest assembleDebug         (macOS/Linux)

Expected outputs:
- Unit test report: `app/build/reports/tests/testDebugUnitTest/index.html`
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

Send the console output if anything fails.

## 3. Install and try the assistant

    adb install -r app/build/outputs/apk/debug/app-debug.apk

Then, on the device:
1. Open **Floating Assistant**.
2. Allow **drawing over other apps**. Return to the app.
3. Allow **notifications** (Android 13+).
4. Tick the authorisation checkbox, press **Start capture**, approve the system dialog.
5. Press **Show floating assistant**. Tap the bubble to open the panel.
6. Press **Start** in the panel. Check the status, detection and prediction cards.
7. Rotate the device: the bubble and panel must stay on screen.
8. Press **Stop capture**: the notification must disappear and analysis must stop.
9. Press **Close floating assistant**: the bubble must disappear.

Record the device model and Android version with the results.

## Release APK
`./gradlew assembleRelease` produces an unsigned APK. Signing is not configured.
