# Final test report

## A. Executed in this environment
| Check | Result |
|---|---|
| Structural check, all Kotlin files (brackets balanced, package matches folder) | 72 files, 0 issues (run after the final edits) |
| XML well-formedness: `AndroidManifest.xml`, `ic_assistant.xml` | Passed earlier (recovery build). |
| Manifest declarations vs code (4 classes, 5 permissions, no INTERNET) | Passed earlier (recovery build). |
| Placeholder and TODO scan of main sources | Passed earlier (recovery build). |
| Python reference, crop and rotation mapping | 49 of 49 passed in an earlier build (not re-run after the final edits). |

## B. Required, NOT executed
| Command | Result |
|---|---|
| `gradlew.bat clean` | NOT RUN. Wrapper missing. |
| `gradlew.bat testDebugUnitTest` | NOT RUN. Wrapper and toolchain missing. |
| `gradlew.bat assembleDebug` | NOT RUN. Wrapper and toolchain missing. |

No Kotlin compilation has happened. Any compile error will appear on the first build.

## C. JVM unit tests written (NOT executed)
- `domain/frame/RawFrameFactoryTest`: 3 tests.
- `domain/assistant/AssistantSessionTest`: 14 tests (consent, run state, frame gating and throttling, detection, prediction, rejected frames, system stop, aim validation, power mapping).
- `domain/analysis/FrameAnalysisCoordinatorTest`: 11 tests (overlap guard, run state, frame ordering, stale predictions, invalid shot settings).
- `domain/assistant/AssistantTest` (run machine and presenter), `domain/frame/FrameAdapterTest`, and the physics, vision, overlay, capture, mode and settings suites: from earlier builds.
- Total `@Test` methods in the project: 168 (counted in source). All are NOT EXECUTED.

## D. Device verification checklist
Automated tests in section C cover only the pure logic. Everything below needs a physical Android device (API 26+, ideally Android 14 or later). Each item: pass, fail, or not tested.

**Overlay**
1. Open Floating Assistant. Tap Allow drawing over other apps. Grant it. Return. The button state updates.
2. Tap Show floating assistant. The "8B" bubble appears at the right edge, one third down.
3. Drag the bubble. It follows the finger and snaps to the nearest edge on release.
4. Close and reopen the app. The bubble returns to its last position.
5. Tap the bubble. The panel opens within the screen, not behind the status bar or navigation bar.
6. Tap Hide in the panel. It returns to the bubble. Tap Close: the bubble disappears.
7. While the panel is open, tap other apps behind it. They must still respond (the window must not block them outside its bounds).

**Screen capture consent**
8. Tick the authorisation checkbox. Tap Start capture. The system consent dialog appears.
9. Deny the dialog. The panel shows "Screen capture permission was denied." Retry works.
10. Approve. A notification "Screen capture active" appears with a Stop capture action. Capture state shows "capturing".
11. Tap the notification's Stop capture action. Capture stops, the notification disappears, and analysis stops.
12. Tap Stop capture in the panel. Same result.

**Permission revocation**
13. While the overlay is shown, revoke "Draw over other apps" in system settings. The bubble must disappear and the service must stop without crashing.
14. While capturing, use the system's screen-sharing stop control. Capture must end, analysis must stop, and the panel must show "ended by the system".

**Rotation**
15. Rotate the device with the bubble visible. It stays on screen. Rotate with the panel open: it clamps to the new size.
16. Rotate during capture. The frames must continue. Check the frame count keeps increasing and nothing crashes.

**Service lifecycle**
17. Kill the app from recent apps while the bubble is shown. The bubble must not reappear on its own (not sticky).
18. Start the overlay twice from the screen. Only one bubble appears.

**Analysis**
19. Start, then pause, then resume, then stop. Each button enables only when valid. "Frames analysed" increases only while running.
20. Point the capture at a real pool table. Record whether the table is detected. Do not record success unless the table and balls are shown.
21. Check the warnings and confidence wording on a poor frame (for example, a dark or partly covered table). The app must say the result is uncertain.

**Prediction**
22. With a detected cue ball, move the aim and power sliders. A prediction appears and is labelled as an estimate with limitations.
23. With no cue ball detected, the prediction must say it is unavailable. It must not show a shot.
24. After a new frame arrives, an old prediction must not be shown as current.

**Resources (observational, using Android Studio Profiler)**
25. Run analysis for 5 minutes. Memory must stay roughly flat after the first minute. Record the figures.
26. After Stop capture, the MediaProjection and the VirtualDisplay must be released. Check with the profiler or logcat.

## E. Result summary
Automated: 0 of 168 executed. Device: 0 of 26 executed. Blocked by missing wrapper, toolchain, and device.
