# Reference model for FrameAdapter crop and rotation mapping. Run: python3 tools/frame_adapter_reference_model.py
import itertools, sys

ROT = ["R0", "R90", "R180", "R270"]

def make_frame(w, h, pad):
    stride = w * 4 + pad
    buf = bytearray([1]) * (stride * h)
    for y in range(h):
        for x in range(w):
            i = y * stride + x * 4
            buf[i] = x; buf[i+1] = y; buf[i+2] = 7; buf[i+3] = 255
    return buf, stride

def adapter(buf, stride, w, h, crop, rot):
    l, t, r, b = crop
    cw, ch = r - l, b - t
    if cw <= 0 or ch <= 0 or l < 0 or t < 0 or r > w or b > h:
        return None
    swapped = rot in ("R90", "R270")
    ow, oh = (ch, cw) if swapped else (cw, ch)
    out = [0] * (ow * oh)
    for oy in range(oh):
        for ox in range(ow):
            if rot == "R0": sx, sy = ox, oy
            elif rot == "R90": sx, sy = oy, ch - 1 - ox
            elif rot == "R180": sx, sy = cw - 1 - ox, ch - 1 - oy
            else: sx, sy = cw - 1 - oy, ox
            i = (t + sy) * stride + (l + sx) * 4
            out[oy * ow + ox] = (buf[i+3] << 24) | (buf[i] << 16) | (buf[i+1] << 8) | buf[i+2]
    return ow, oh, out

def reference(buf, stride, crop, rot):
    l, t, r, b = crop
    cw, ch = r - l, b - t
    base = [[0]*cw for _ in range(ch)]
    for y in range(ch):
        for x in range(cw):
            i = (t+y)*stride + (l+x)*4
            base[y][x] = (buf[i+3] << 24) | (buf[i] << 16) | (buf[i+1] << 8) | buf[i+2]
    if rot == "R0": g = base
    elif rot == "R90":  # clockwise: row y becomes column (ch-1-y)
        g = [[base[ch-1-x][y] for x in range(ch)] for y in range(cw)]
    elif rot == "R180": g = [row[::-1] for row in base[::-1]]
    else:  # counter-clockwise
        g = [[base[y][cw-1-x] for y in range(ch)] for x in range(cw)]
    oh, ow = len(g), len(g[0])
    return ow, oh, [v for row in g for v in row]

results = []
for (w, h, pad) in [(4, 3, 0), (5, 4, 3), (7, 6, 5)]:
    buf, stride = make_frame(w, h, pad)
    crops = [(0, 0, w, h), (1, 1, w-1, h-1), (0, 0, 1, 1), (w-2, h-2, w, h)]
    for crop, rot in itertools.product(crops, ROT):
        got = adapter(buf, stride, w, h, crop, rot)
        exp = reference(buf, stride, crop, rot)
        results.append((f"frame {w}x{h} pad{pad} crop{crop} {rot}", got == exp))
# Clockwise sanity: 2x1 row [a,b] rotated R90 gives column a (top), b (bottom).
buf, stride = make_frame(2, 1, 0)
ow, oh, px = adapter(buf, stride, 2, 1, (0,0,2,1), "R90")
results.append(("R90 of 2x1 row: width1 height2 top=(0,0) bottom=(1,0)",
                (ow, oh) == (1, 2) and px[0] == ((255<<24)|(0<<16)|(0<<8)|7) and px[1] == ((255<<24)|(1<<16)|(0<<8)|7)))
fails = [n for n, ok in results if not ok]
for n in fails: print("FAIL", n)
print(f"{len(results)-len(fails)}/{len(results)} checks passed")
sys.exit(1 if fails else 0)
