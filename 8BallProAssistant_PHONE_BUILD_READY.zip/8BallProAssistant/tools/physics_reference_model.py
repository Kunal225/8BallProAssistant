# Reference model for the 3D engine. Run: python3 tools/physics_reference_model.py
# Independent numerical check of the analytic expectations used by the Kotlin unit tests.
# Independent numerical model of the planned Kotlin engine. Used to check the
# analytic expectations before they are written as Kotlin unit tests.
import math
M = 0.17; R = 0.028575; I = 0.4 * M * R * R; G = 9.81
EPS_CONTACT = 1e-9

def add(a,b): return [a[0]+b[0],a[1]+b[1],a[2]+b[2]]
def sub(a,b): return [a[0]-b[0],a[1]-b[1],a[2]-b[2]]
def mul(a,s): return [a[0]*s,a[1]*s,a[2]*s]
def dot(a,b): return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
def cross(a,b): return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def norm(a): return math.sqrt(dot(a,a))
def unit(a):
    n = norm(a); return [0,0,0] if n == 0 else mul(a, 1/n)

class Ball:
    def __init__(self, p, v=(0,0,0), w=(0,0,0)):
        self.p=list(p); self.v=list(v); self.w=list(w)

def contact_impulse_tangent(ball, r, ni, mu, normal_impulse):
    """Friction at a single-ball contact (wall or floor). Limit by mu*normal impulse."""
    vc = add(ball.v, cross(ball.w, r))
    ut = sub(vc, mul(ni, dot(vc, ni)))
    u = norm(ut)
    if u < 1e-12: return
    f = min(u * M * 2.0 / 7.0, mu * normal_impulse)
    P = mul(unit(ut), -f)
    ball.v = add(ball.v, mul(P, 1/M))
    ball.w = add(ball.w, mul(cross(r, P), 1/I))

def resolve_pair(a, b, e, mu):
    d = sub(b.p, a.p); dist = norm(d); n = mul(d, 1/dist)
    closing = dot(sub(a.v, b.v), n)
    if closing <= 0: return
    J = (1+e) * closing * M / 2.0
    a.v = sub(a.v, mul(n, J/M)); b.v = add(b.v, mul(n, J/M))
    ra = mul(n, R); rb = mul(n, -R)
    uc = sub(add(a.v, cross(a.w, ra)), add(b.v, cross(b.w, rb)))
    ut = sub(uc, mul(n, dot(uc, n)))
    u = norm(ut)
    if u < 1e-12: return
    f = min(u * M / 7.0, mu * J)
    P = mul(unit(ut), -f)
    a.v = add(a.v, mul(P, 1/M)); a.w = add(a.w, mul(cross(ra, P), 1/I))
    b.v = sub(b.v, mul(P, 1/M)); b.w = add(b.w, mul(cross(rb, mul(P,-1)), 1/I))

def wall(ball, ni, e, mu):
    r = mul(ni, -R)
    if dot(ball.v, ni) >= 0: return
    J = (1+e) * (-dot(ball.v, ni)) * M
    ball.v = add(ball.v, mul(ni, J/M))
    contact_impulse_tangent(ball, r, ni, mu, J)

def step_single(ball, dt, mu_s, mu_r, e_floor):
    on_floor = ball.p[2] <= R + EPS_CONTACT
    if on_floor:
        r = [0,0,-R]
        vc = add(ball.v, cross(ball.w, r))
        s = [vc[0], vc[1], 0.0]; sl = norm(s)
        if sl > 1e-9:
            j = min(mu_s*M*G*dt, M*sl*2.0/7.0)
            F = mul(unit(s), -j)
            ball.v = add(ball.v, mul(F, 1/M)); ball.w = add(ball.w, mul(cross(r, F), 1/I))
        hv = [ball.v[0], ball.v[1], 0.0]; hs = norm(hv)
        if hs > 0:
            dv = min(mu_r*G*dt, hs)
            ball.v = sub(ball.v, mul(unit(hv), dv))
    ball.v[2] -= G*dt
    ball.p = add(ball.p, mul(ball.v, dt))
    if ball.p[2] < R:
        ball.p[2] = R
        if ball.v[2] < 0:
            ball.v[2] = -e_floor*ball.v[2] if -ball.v[2] > 0.01 else 0.0

# ---------------- tests ----------------
results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond), detail)); print(("PASS " if cond else "FAIL ")+name, detail)

# T1 sliding -> rolling (no spin start): v_roll = 5/7 v0 and t = 2 v0 /(7 mu g)
mu=0.2; v0=2.0; dt=2e-5
b = Ball([0.5,0.5,R], [v0,0,0], [0,0,0]); t=0.0
while True:
    vc = add(b.v, cross(b.w,[0,0,-R]))
    if norm([vc[0],vc[1],0]) < 1e-5 and t>0.01: break
    step_single(b, dt, mu, 0.0, 0.5); t+=dt
    if t>5: break
t_exp = 2*v0/(7*mu*G); v_exp = 5*v0/7
check("T1 slide->roll time", abs(t-t_exp)/t_exp < 0.02, f"t={t:.5f} exp={t_exp:.5f}")
check("T1 slide->roll speed", abs(b.v[0]-v_exp)/v_exp < 0.02, f"v={b.v[0]:.4f} exp={v_exp:.4f}")
check("T1 omega matches rolling", abs(b.w[1]*R - b.v[0])/v_exp < 0.02, f"wR={b.w[1]*R:.4f}")

# T2 rolling without resistance keeps speed (no slip)
b = Ball([0.5,0.5,R],[2.0,0,0],[0,2.0/R,0])
for _ in range(5000): step_single(b, 2e-5, 0.2, 0.0, 0.5)
check("T2 pure roll preserved", abs(b.v[0]-2.0) < 1e-3, f"v={b.v[0]:.5f}")

# T3 rolling resistance deceleration mu_r*g
b = Ball([0.5,0.5,R],[2.0,0,0],[0,2.0/R,0])
for _ in range(int(1.0/2e-5)): step_single(b, 2e-5, 0.2, 0.01, 0.5)
dec = (2.0 - b.v[0]) / 1.0
exp3 = 0.01*G/(1+I/(M*R*R))
check("T3 rolling resistance decel = mu_r g/1.4", abs(dec-exp3)/exp3 < 0.02, f"decel={dec:.5f} exp={exp3:.5f}")

# T4 head-on equal masses, e=1 -> full transfer; e=0.5 -> 0.25v / 0.75v
for e,exp_a,exp_b in [(1.0,0.0,1.0),(0.5,0.25,0.75)]:
    a=Ball([0.0,0,R],[1.0,0,0]); bb=Ball([2*R*0.999,0,R],[0,0,0])
    resolve_pair(a,bb,e,0.0)
    check(f"T4 head-on e={e}", abs(a.v[0]-exp_a)<1e-9 and abs(bb.v[0]-exp_b)<1e-9, f"va={a.v[0]:.6f} vb={bb.v[0]:.6f}")

# T5 pair collision conserves linear momentum with friction and spin
a=Ball([0,0,R],[1.5,0.4,0],[0.3,-20,5]); bb=Ball([2*R*0.98,0.02,R],[0,0,0],[0,0,0])
p0 = add(mul(a.v,M), mul(bb.v,M))
resolve_pair(a,bb,0.9,0.2)
p1 = add(mul(a.v,M), mul(bb.v,M))
check("T5 momentum conserved", norm(sub(p1,p0))<1e-12, f"dp={norm(sub(p1,p0)):.2e}")

# T6 full friction kills tangential contact slip after a collision
a=Ball([0,0,R],[2.0,0.5,0],[0,0,30]); bb=Ball([2*R*0.99,0,R],[0,0,0],[0,0,0])
resolve_pair(a,bb,0.8,5.0)
ra=[R,0,0]; rb=[-R,0,0]
uc = sub(add(a.v,cross(a.w,ra)), add(bb.v,cross(bb.w,rb)))
ut = sub(uc, mul([1,0,0], dot(uc,[1,0,0])))
check("T6 tangential slip zeroed", norm(ut) < 1e-9, f"ut={norm(ut):.2e}")

# T7 wall: normal reversed by e, tangential unchanged with zero friction
b=Ball([R,0.5,R],[-1.0,0.5,0],[0,0,0])
wall(b,[1,0,0],0.8,0.0)
check("T7 wall normal rebound e", abs(b.v[0]-0.8)<1e-9 and abs(b.v[1]-0.5)<1e-9, f"v={b.v}")

# T8 wall friction with topspin reduces ball spin-induced slip, no momentum leak check
b=Ball([R,0.5,R],[-1.0,0.0,0],[0,-50.0,0])  # bottom contact slip from spin
vc0=add(b.v,cross(b.w,[-R,0,0]))
wall(b,[1,0,0],0.8,0.2)
vc1=add(b.v,cross(b.w,[-R,0,0]))
check("T8 wall friction reduces slip", norm([vc1[1],vc1[2],0]) < norm([vc0[1],vc0[2],0]), f"{norm([vc0[1],vc0[2],0]):.3f}->{norm([vc1[1],vc1[2],0]):.3f}")

# T9 floor bounce: vz after impact = e * impact speed; rebound height ~ e^2 h (no friction)
h=0.1; e=0.5
b=Ball([0.5,0.5,R+h],[0,0,0]); imp=None; apex=0; prev_vz=0
for _ in range(200000):
    before=b.v[2]
    step_single(b,1e-5,0.0,0.0,e)
    if before<0 and b.v[2]>0 and imp is None:
        imp=-before
    if imp is not None: apex=max(apex,b.p[2]-R)
    if imp is not None and b.v[2]<0 and apex>0: break
check("T9 bounce impact speed", abs(imp-math.sqrt(2*G*h))/math.sqrt(2*G*h)<0.01, f"imp={imp:.4f}")
check("T9 rebound height e^2 h", abs(apex/h - e*e)<0.02, f"ratio={apex/h:.4f} exp={e*e}")


# T10 top spin: invariant v + 0.4*R*w_y. Top-spin strike (w_y = 2.5 v0/R) rolls out at 10/7 v0.
v0=2.0; b = Ball([0.5,0.5,R],[v0,0,0],[0,2.5*v0/R,0])
for _ in range(int(3.0/2e-5)):
    step_single(b, 2e-5, 0.2, 0.0, 0.5)
    vc = add(b.v, cross(b.w,[0,0,-R]))
    if norm([vc[0],vc[1],0]) < 1e-5 and _ > 100: break
check("T10 top-spin rolls out at 10/7 v0", abs(b.v[0]-10*v0/7)/(10*v0/7) < 0.02, f"v={b.v[0]:.4f} exp={10*v0/7:.4f}")

failed=[r for r in results if not r[1]]
print(f"\n{len(results)-len(failed)}/{len(results)} checks passed")
