# Reference model for Batch 3 vision math. Run: python3 tools/vision_reference_model.py
# Reference model for the Batch 3 vision math. Mirrors the planned Kotlin code.
import math

def hsv(r,g,b):
    mx,mn=max(r,g,b),min(r,g,b); d=mx-mn
    if d==0: h=0.0
    elif mx==r: h=60*(((g-b)/d)%6)
    elif mx==g: h=60*((b-r)/d+2)
    else: h=60*((r-g)/d+4)
    s=0.0 if mx==0 else d/mx
    return h,s,mx

def is_felt(px, prof):
    r,g,b=(px>>16)&255,(px>>8)&255,px&255
    h,s,v=hsv(r/255,g/255,b/255)
    return prof['hmin']<=h<=prof['hmax'] and s>=prof['smin'] and v>=prof['vmin']

def felt_bbox(img, w, h, prof):
    rows=[sum(1 for x in range(w) if is_felt(img[y*w+x],prof)) for y in range(h)]
    cols=[sum(1 for y in range(h) if is_felt(img[y*w+x],prof)) for x in range(w)]
    rthr,cthr=0.3*w,0.3*h
    ys=[y for y in range(h) if rows[y]>rthr]; xs=[x for x in range(w) if cols[x]>cthr]
    if not ys or not xs: return None
    return (min(xs),min(ys),max(xs),max(ys))

def components(mask, w, h, x0,y0,x1,y1):
    seen=set(); out=[]
    for y in range(y0,y1+1):
        for x in range(x0,x1+1):
            i=y*w+x
            if not mask[i] or i in seen: continue
            stack=[i]; seen.add(i); pts=[]
            while stack:
                c=stack.pop(); pts.append(c); cx,cy=c%w,c//w
                for nx,ny in ((cx+1,cy),(cx-1,cy),(cx,cy+1),(cx,cy-1)):
                    if x0<=nx<=x1 and y0<=ny<=y1:
                        j=ny*w+nx
                        if mask[j] and j not in seen:
                            seen.add(j); stack.append(j)
            out.append(pts)
    return out

def blob_stats(pts, w):
    n=len(pts); xs=[p%w for p in pts]; ys=[p//w for p in pts]
    bw=max(xs)-min(xs)+1; bh=max(ys)-min(ys)+1
    return dict(area=n, cx=sum(xs)/n, cy=sum(ys)/n, bw=bw, bh=bh,
                fill=n/(bw*bh), radius=math.sqrt(n/math.pi))

def inverse_bilinear(p, c):
    # c = [TL, TR, BR, BL] as (x,y). Solve p = (1-u)(1-v)TL + u(1-v)TR + uv BR + (1-u)v BL
    def f(u,v):
        x=(1-u)*(1-v)*c[0][0]+u*(1-v)*c[1][0]+u*v*c[2][0]+(1-u)*v*c[3][0]
        y=(1-u)*(1-v)*c[0][1]+u*(1-v)*c[1][1]+u*v*c[2][1]+(1-u)*v*c[3][1]
        return x,y
    u,v=0.5,0.5
    for _ in range(50):
        x,y=f(u,v); ex,ey=x-p[0],y-p[1]
        if abs(ex)+abs(ey)<1e-12: break
        h=1e-6
        xu,yu=f(u+h,v); xv,yv=f(u,v+h)
        a,b=(xu-x)/h,(xv-x)/h; cc,d=(yu-y)/h,(yv-y)/h
        det=a*d-b*cc
        if abs(det)<1e-15: break
        du=( d*ex-b*ey)/det; dv=(-cc*ex+a*ey)/det
        u-=du; v-=dv
    return u,v

checks=[]
def check(name,ok,detail=""):
    checks.append(ok); print(("PASS " if ok else "FAIL ")+name, detail)

# Synthetic table: 2:1 felt rectangle 200x100 px with 10 px rail border, one white cue ball and one red ball.
W,H=240,140
FELT=0xFF1F6FB2; RAIL=0xFF5A3A1A; WHITE=0xFFFFFFFF; RED=0xFFE5484D; BG=0xFF101010
img=[BG]*(W*H)
for y in range(20,120):
    for x in range(20,220):
        img[y*W+x]=FELT
def disc(cx,cy,r,col):
    for y in range(int(cy-r-1),int(cy+r+2)):
        for x in range(int(cx-r-1),int(cx+r+2)):
            if (x-cx)**2+(y-cy)**2<=r*r: img[y*W+x]=col
disc(60,70,8,WHITE); disc(150,60,8,RED)
prof=dict(hmin=190,hmax=230,smin=0.35,vmin=0.2)
bb=felt_bbox(img,W,H,prof)
check("table bbox found", bb==(20,20,219,119), str(bb))
x0,y0,x1,y1=bb
ix0,iy0,ix1,iy1=x0+2,y0+2,x1-2,y1-2
mask=[False]*(W*H)
for y in range(iy0,iy1+1):
    for x in range(ix0,ix1+1):
        p=img[y*W+x]
        if not is_felt(p,prof): mask[y*W+x]=True
comps=[blob_stats(c,W) for c in components(mask,W,H,ix0,iy0,ix1,iy1)]
comps=[c for c in comps if c['area']>=20]
check("two ball blobs found", len(comps)==2, f"found {len(comps)}")
for c in comps:
    check(f"blob near ({c['cx']:.0f},{c['cy']:.0f}) is round", 0.6<c["fill"]<0.85 and abs(c['bw']-c['bh'])<=1, f"fill={c['fill']:.2f} bw={c['bw']} bh={c['bh']}")
    check(f"radius estimate ~8px", abs(c['radius']-8)<1.2, f"r={c['radius']:.2f}")
cue=[c for c in comps if abs(c['cx']-60)<2][0]
check("cue centre estimate", abs(cue['cx']-60)<0.5 and abs(cue['cy']-70)<0.5, f"({cue['cx']:.2f},{cue['cy']:.2f})")

corners=[(20,20),(220,20),(220,120),(20,120)]
u,v=inverse_bilinear((150,60),corners)
check("identity calibration maps to normalised coords", abs(u-130/200)<1e-6 and abs(v-40/100)<1e-6, f"u={u:.6f} v={v:.6f}")
# Trapezoid perspective: round trip
tz=[(30,22),(212,26),(220,118),(18,116)]
def fwd(u,v,c):
    return ((1-u)*(1-v)*c[0][0]+u*(1-v)*c[1][0]+u*v*c[2][0]+(1-u)*v*c[3][0],
            (1-u)*(1-v)*c[0][1]+u*(1-v)*c[1][1]+u*v*c[2][1]+(1-u)*v*c[3][1])
worst=0
for uu in [0.1,0.3,0.5,0.8,0.95]:
    for vv in [0.05,0.4,0.7,0.9]:
        px=fwd(uu,vv,tz); a,b=inverse_bilinear(px,tz); worst=max(worst,abs(a-uu),abs(b-vv))
check("trapezoid round-trip error < 1e-6", worst<1e-6, f"worst={worst:.2e}")

print(f"\n{sum(checks)}/{len(checks)} checks passed")
