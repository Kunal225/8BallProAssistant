#!/usr/bin/env python3
"""
Project completeness audit for 8 Ball Pro Assistant.

Usage:
    python3 tools/audit_project.py <project_root> [<previous_batch_root>]

Writes FILE_INVENTORY.md, MISSING_FILES_REPORT.md and BATCH_COMPLETION_REPORT.md into
<project_root>. Exits with status 1 if any required file is missing.

These are STATIC checks only. This script does not compile Kotlin, run Gradle, or run tests.
"""
import hashlib
import os
import re
import sys
from datetime import datetime, timezone

ROOT = os.path.abspath(sys.argv[1])
PREV = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else None
PKG_ROOT = "app/src/main/java"
TEST_ROOT = "app/src/test/java"
GENERATED = {"FILE_INVENTORY.md", "MISSING_FILES_REPORT.md", "BATCH_COMPLETION_REPORT.md"}
SKIP_DIRS = {".gradle", "build", ".idea", ".git", ".cxx", "captures"}
ASSET_EXT = (".obj", ".gltf", ".glb", ".fbx", ".png", ".jpg", ".jpeg", ".webp",
             ".glsl", ".frag", ".vert", ".ttf", ".otf", ".mp3", ".ogg")

REQUIRED = [
    "settings.gradle.kts", "build.gradle.kts", "gradle.properties", ".gitignore",
    "gradle/libs.versions.toml", "gradle/wrapper/gradle-wrapper.properties",
    "gradle/wrapper/gradle-wrapper.jar", "gradlew", "gradlew.bat",
    "app/build.gradle.kts", "app/proguard-rules.pro",
    "app/src/main/AndroidManifest.xml", "app/src/main/res/values/strings.xml",
    "app/src/main/res/values/themes.xml",
    "app/src/main/java/com/eightballpro/assistant/MainActivity.kt",
    "README.md", "CHANGELOG.md", "BUILD_INSTRUCTIONS.md",
]

PENDING_ISSUES = [
    "Nothing has been compiled. Gradle sync, Kotlin compilation and all JVM unit tests are NOT RUN.",
    "The Gradle wrapper JAR and launcher scripts are missing. Create them with: gradle wrapper --gradle-version 8.9",
    "No device has been tested. Overlay drawing, foreground services, MediaProjection consent, capture, and rotation are DEVICE TEST REQUIRED.",
    "Manual table calibration (corner dragging and saving) is not implemented. The domain calibration exists, but no UI feeds it.",
    "Mode B screenshot import is not implemented in the Android layer. The domain analysis exists.",
    "Strings are English only. Hindi resources are not added.",
    "Felt colour thresholds are a default (blue). They must be calibrated per game before detection is reliable.",
    "Predictions are estimates from a single frame and are not validated against measured shots.",
]


def walk(root):
    out = {}
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(files):
            full = os.path.join(d, f)
            out[os.path.relpath(full, root).replace(os.sep, "/")] = full
    return out


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def strip_code(src):
    t = re.sub(r'"""[\s\S]*?"""', '""', src)
    t = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', t)
    t = re.sub(r"/\*[\s\S]*?\*/", "", t)
    t = re.sub(r"//[^\n]*", "", t)
    t = re.sub(r"'(?:\\.|[^'\\\n])'", "'x'", t)
    return t


DECL = re.compile(
    r"^(?:(?:private|internal|public)\s+)?(?:(?:data|enum|sealed|abstract|open|inline|const|annotation)\s+)*"
    r"(?:class|object|interface|fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?:[\w.]+\.)?([A-Za-z_]\w*)",
    re.M,
)
IMPORT = re.compile(r"^import\s+([\w.]+)(?:\s+as\s+\w+)?\s*$", re.M)
PACKAGE = re.compile(r"^package\s+([\w.]+)", re.M)


def main():
    inv = {k: v for k, v in walk(ROOT).items() if k not in GENERATED}
    sizes = {k: os.path.getsize(v) for k, v in inv.items()}
    hashes = {k: sha256(v) for k, v in inv.items()}

    missing_required = [p for p in REQUIRED if p not in inv]
    empty = [k for k, s in sizes.items() if s == 0]

    prev_added = prev_removed = prev_modified = []
    prev_label = "none (no baseline supplied)"
    if PREV:
        prev_label = os.path.basename(PREV.rstrip("/"))
        prev_inv = {k: v for k, v in walk(PREV).items() if k not in GENERATED}
        prev_hash = {k: sha256(v) for k, v in prev_inv.items()}
        prev_added = sorted(set(inv) - set(prev_inv))
        prev_removed = sorted(set(prev_inv) - set(inv))
        prev_modified = sorted(k for k in set(inv) & set(prev_inv) if hashes[k] != prev_hash[k])

    kt = {k: v for k, v in inv.items() if k.endswith(".kt")}
    unbalanced = []
    pkg_decls, file_pkg = {}, {}
    for rel, full in kt.items():
        src = read(full)
        code = strip_code(src)
        for o, c in (("{", "}"), ("(", ")"), ("[", "]")):
            if code.count(o) != code.count(c):
                unbalanced.append(f"{rel}: '{o}' {code.count(o)} vs '{c}' {code.count(c)}")
        if not src.endswith("\n"):
            unbalanced.append(f"{rel}: does not end with a newline (possible truncation)")
        m = PACKAGE.search(src)
        pkg = m.group(1) if m else ""
        file_pkg[rel] = pkg
        pkg_decls.setdefault(pkg, set()).update(DECL.findall(src))
        if rel.startswith(PKG_ROOT + "/"):
            expected = os.path.dirname(rel[len(PKG_ROOT) + 1:]).replace("/", ".")
            if pkg != expected:
                unbalanced.append(f"{rel}: package '{pkg}' does not match folder '{expected}'")

    # Project-internal imports must resolve to a declaration in the project.
    unresolved_imports = []
    external_prefixes = set()
    for rel, full in kt.items():
        for imp in IMPORT.findall(read(full)):
            if imp.startswith("com.eightballpro.assistant."):
                pkg, name = imp.rsplit(".", 1)
                if name not in pkg_decls.get(pkg, set()):
                    unresolved_imports.append(f"{rel}: {imp}")
            else:
                external_prefixes.add(".".join(imp.split(".")[:2]))

    # Gradle catalog references.
    toml = read(os.path.join(ROOT, "gradle/libs.versions.toml"))
    sections, cur = {}, None
    for line in toml.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        sm = re.match(r"^\[(\w+)\]$", s)
        if sm:
            cur = sm.group(1)
            sections.setdefault(cur, {})
            continue
        if cur and "=" in s:
            key = s.split("=", 1)[0].strip()
            sections[cur][key] = s
    gradle_issues = []
    for rel in ("settings.gradle.kts", "build.gradle.kts", "app/build.gradle.kts"):
        if rel not in inv:
            continue
        for token in set(re.findall(r"libs\.([\w.]+)", read(os.path.join(ROOT, rel)))):
            if token.startswith("plugins."):
                key = token[len("plugins."):].replace(".", "-")
                if key not in sections.get("plugins", {}):
                    gradle_issues.append(f"{rel}: plugin alias '{key}' not in [plugins]")
            else:
                key = token.replace(".", "-")
                if key not in sections.get("libraries", {}):
                    gradle_issues.append(f"{rel}: library alias '{key}' not in [libraries]")
    for section in ("libraries", "plugins"):
        for key, line in sections.get(section, {}).items():
            ref = re.search(r'version\.ref\s*=\s*"([^"]+)"', line)
            if ref and ref.group(1) not in sections.get("versions", {}):
                gradle_issues.append(f"[{section}] {key}: version ref '{ref.group(1)}' not defined")

    # Resource references (strings, styles, colors, dimens, mipmap/drawable files).
    defined = {"string": set(), "style": set(), "color": set(), "dimen": set(), "mipmap": set(), "drawable": set()}
    for rel in inv:
        if rel.startswith("app/src/main/res/values") and rel.endswith(".xml"):
            for typ, name in re.findall(r'<(string|style|color|dimen)\s+name="([^"]+)"', read(inv[rel])):
                defined[typ].add(name)
        m = re.match(r"app/src/main/res/(mipmap|drawable)[^/]*/([^/]+)\.\w+$", rel)
        if m:
            defined[m.group(1)].add(m.group(2))
    resource_issues = []
    for rel in inv:
        if rel.endswith(".xml") and rel.startswith("app/src/main"):
            for typ, name in re.findall(r"@(\w+)/([\w.]+)", read(inv[rel])):
                if typ in defined and name not in defined[typ]:
                    resource_issues.append(f"{rel}: @{typ}/{name} not defined")
        if rel.endswith(".kt") and rel.startswith("app/src/main"):
            for typ, name in re.findall(r"\bR\.(\w+)\.(\w+)", strip_code(read(inv[rel]))):
                if typ in defined and name not in defined[typ]:
                    resource_issues.append(f"{rel}: R.{typ}.{name} not defined")

    # Manifest activity classes must exist.
    manifest_issues = []
    if "app/src/main/AndroidManifest.xml" in inv:
        for cls in re.findall(r'android:name="\.(\w+)"', read(inv["app/src/main/AndroidManifest.xml"])):
            if f"{PKG_ROOT}/com/eightballpro/assistant/{cls}.kt" not in inv:
                manifest_issues.append(f"manifest references .{cls} but no {cls}.kt exists")

    # Test coverage of domain and data classes (UI is covered by compile + manual review only).
    test_names = {os.path.basename(k)[:-len(".kt")] for k in inv if k.startswith(TEST_ROOT + "/") and k.endswith(".kt")}
    uncovered = []
    for k in kt:
        if k.startswith(PKG_ROOT + "/") and ("/domain/" in k or "/data/" in k):
            stem = os.path.basename(k)[:-len(".kt")]
            if stem + "Test" not in test_names:
                uncovered.append(k)
    test_files = sorted(k for k in inv if k.startswith(TEST_ROOT + "/") and k.endswith(".kt"))
    test_annotations = sum(len(re.findall(r"@Test\b", read(inv[k]))) for k in test_files)
    integration_tests = [k for k in test_files if "Integration" in os.path.basename(k)]
    ui_or_app_untested = sorted(k for k in kt if k.startswith(PKG_ROOT + "/") and k not in
                                [p for p in kt if "/domain/" in p or "/data/" in p])

    # Placeholder / TODO scan.
    todo_hits = []
    for k in kt:
        for i, line in enumerate(read(inv[k]).splitlines(), 1):
            if re.search(r"\bTODO\b|\bFIXME\b|placeholder", line, re.I):
                todo_hits.append(f"{k}:{i}: {line.strip()[:100]}")

    assets = sorted(k for k in inv if k.lower().endswith(ASSET_EXT))

    blocking = []
    if missing_required:
        blocking.append(f"{len(missing_required)} required file(s) missing")
    if empty:
        blocking.append(f"{len(empty)} empty file(s)")
    if unbalanced:
        blocking.append(f"{len(unbalanced)} source structure issue(s)")
    if unresolved_imports:
        blocking.append(f"{len(unresolved_imports)} unresolved project import(s)")
    if gradle_issues or resource_issues or manifest_issues:
        blocking.append("Gradle, resource or manifest reference issues")
    status = "INCOMPLETE" if blocking else "STATIC CHECKS PASSED - BUILD AND TESTS NOT RUN"
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # ---- FILE_INVENTORY.md ----
    lines = [
        "# File inventory", "",
        f"Generated: {now}  ", f"Project root: `{os.path.basename(ROOT)}`  ",
        f"Baseline for comparison: `{prev_label}`  ",
        f"Files listed: {len(inv)} (generated audit reports are excluded from this list)", "",
        "| Path | Bytes | SHA-256 (first 12) | vs baseline |", "|---|---:|---|---|",
    ]
    for k in sorted(inv):
        if PREV:
            if k in prev_added:
                tag = "added"
            elif k in prev_modified:
                tag = "modified"
            else:
                tag = "unchanged"
        else:
            tag = "n/a"
        lines.append(f"| `{k}` | {sizes[k]} | `{hashes[k][:12]}` | {tag} |")
    if PREV and prev_removed:
        lines += ["", "Removed since baseline: " + ", ".join(f"`{k}`" for k in prev_removed)]
    with open(os.path.join(ROOT, "FILE_INVENTORY.md"), "w") as fh:
        fh.write("\n".join(lines) + "\n")

    # ---- MISSING_FILES_REPORT.md ----
    def section(title, items, none_text="None found."):
        out = [f"## {title}", ""]
        out += [f"- {i}" for i in items] if items else [none_text]
        return out + [""]

    rep = ["# Missing files and integrity report", "", f"Generated: {now}", ""]
    rep += section("Required files missing", missing_required, "None. All required files are present.")
    rep += section("Empty files", empty)
    rep += section("Files added since baseline", prev_added if PREV else [], "No baseline supplied or nothing added.")
    rep += section("Files removed since baseline", prev_removed if PREV else [], "No baseline supplied or nothing removed.")
    rep += section("Files modified since baseline", prev_modified if PREV else [], "No baseline supplied or nothing modified.")
    rep += section("Kotlin structure (braces, package, truncation)", unbalanced)
    rep += section("Unresolved project imports", unresolved_imports)
    rep += section("Gradle catalog references", gradle_issues)
    rep += section("Resource references", resource_issues)
    rep += section("Manifest class references", manifest_issues)
    rep += section("Domain/data classes without a matching *Test.kt", uncovered)
    rep += section("Placeholder or TODO markers in source (review: pending screens say so intentionally)", todo_hits)
    rep += section("Binary assets (3D models, textures, shaders, fonts, audio)",
                   assets, "None. Batch 1 needs no 3D, texture, shader or audio assets, and none are referenced.")
    rep += ["## Not verifiable here", ""]
    rep += [f"- External library imports ({len(external_prefixes)} package prefixes) were not resolved against "
            "dependency artifacts, because no dependency cache or network is available.",
            "- Compose, DataStore and Navigation API signatures were not type-checked by a compiler.", ""]
    with open(os.path.join(ROOT, "MISSING_FILES_REPORT.md"), "w") as fh:
        fh.write("\n".join(rep))

    # ---- BATCH_COMPLETION_REPORT.md ----
    def row(item, result):
        return f"| {item} | {result} |"

    br = [
        "# Batch completion report", "",
        f"Generated: {now}", "",
        "**Recovery build. Status: " + ("INCOMPLETE" if blocking else "NOT VERIFIED") + "**", "",
        "Blocking issues: " + ("; ".join(blocking) if blocking else "none from static checks") + ".",
        "The build and tests have never run, so this batch cannot be labelled complete.", "",
        "| Check | Result |", "|---|---|",
        row("Backup of previous batch preserved", "Yes, outside the project in `backup/`"),
        row("Required files present", "FAIL: " + ", ".join(missing_required) if missing_required else "PASS"),
        row("No empty files", "PASS" if not empty else "FAIL: " + ", ".join(empty)),
        row("Kotlin braces balanced, packages match folders", "PASS" if not any(
            "unbalanced" in u or "package" in u or "newline" in u for u in unbalanced) else "FAIL"),
        row("Project-internal imports resolve", "PASS" if not unresolved_imports else f"FAIL ({len(unresolved_imports)})"),
        row("Gradle catalog references resolve", "PASS" if not gradle_issues else f"FAIL ({len(gradle_issues)})"),
        row("Resource references resolve", "PASS" if not resource_issues else f"FAIL ({len(resource_issues)})"),
        row("Manifest class references exist", "PASS" if not manifest_issues else f"FAIL ({len(manifest_issues)})"),
        row("Kotlin compilation", "NOT RUN (no Kotlin compiler / SDK available)"),
        row("Unit tests", f"NOT RUN ({len(test_files)} test files, {test_annotations} @Test methods)"),
        row("Integration tests", f"NOT RUN ({len(integration_tests)} integration test file(s))"),
        row("Compose UI / instrumented tests", "NONE WRITTEN"),
        row("Debug APK built", "NOT RUN"),
        row("APK installed and launched", "NOT RUN"),
        row("3D models, textures, shaders required", "No (none referenced)"),
        row("Gradle wrapper JAR and scripts", "MISSING" if "gradle/wrapper/gradle-wrapper.jar" in missing_required else "present"),
        "",
        "## Pending issues", "",
    ]
    br += [f"- {p}" for p in PENDING_ISSUES]
    br += ["", "## Build instructions", "", "See `BUILD_INSTRUCTIONS.md`.", "",
           f"Audit status: **{status}**", ""]
    with open(os.path.join(ROOT, "BATCH_COMPLETION_REPORT.md"), "w") as fh:
        fh.write("\n".join(br))

    print("status:", status)
    print("files listed:", len(inv), "| required missing:", len(missing_required), "| empty:", len(empty))
    print("unbalanced/structure:", len(unbalanced), "| unresolved imports:", len(unresolved_imports))
    print("gradle issues:", len(gradle_issues), "| resource issues:", len(resource_issues), "| manifest issues:", len(manifest_issues))
    print("test files:", len(test_files), "| @Test methods:", test_annotations, "| integration files:", len(integration_tests))
    print("domain/data classes without tests:", len(uncovered))
    return 1 if missing_required else 0


if __name__ == "__main__":
    sys.exit(main())
