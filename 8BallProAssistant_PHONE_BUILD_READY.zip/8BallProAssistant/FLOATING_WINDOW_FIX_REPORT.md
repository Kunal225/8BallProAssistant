# 8BallProAssistant — Floating Window & Compose Measurement Fix Report

## Executive Summary
This report documents the identification, root cause analysis, code fixes, build verification, and physical device test results for two critical runtime crashes in the floating assistant overlay and panel UI on Android.

---

## 1. Infinite Height Constraints Compose Crash (`IllegalStateException`)

### Root Cause Analysis
- **Offending Composable & Line Location:**
  - `app/src/main/java/com/eightballpro/assistant/ui/assistant/AssistantPanelContent.kt`
  - `app/src/main/java/com/eightballpro/assistant/ui/assistant/AssistantControlScreen.kt`
- **Mechanism:**
  `AssistantControlScreen` rendered `AssistantPanelContent()` inside a top-level `Column` configured with `.verticalScroll(rememberScrollState())`. When measured during layout passes inside `NavHost` (`AnimatedContent`) and `ScreenScaffold` (`ScaffoldLayout`), the outer `Column` provided an infinite maximum height constraint (`maxHeight = Constraints.Infinity`) to its children.
  `AssistantPanelContent` unconditionally applied its own `.verticalScroll(rememberScrollState())` to its internal `Column`. Jetpack Compose strictly prohibits measuring a scrollable component with infinite maximum height constraints, resulting in the runtime crash:
  ```text
  java.lang.IllegalStateException: Vertically scrollable component was measured with an infinity maximum height constraints, which is disallowed.
  ```
- **Recorded Stack Trace:**
  - `ScrollingLayoutNode.measure`
  - `ColumnMeasurePolicy.measure`
  - `ScaffoldLayout`
  - `AnimatedContent`
  - `AndroidComposeView.dispatchDraw`

### Code Fix
1. **`AssistantPanelContent.kt`**:
   - Added a `scrollable: Boolean = true` parameter to `AssistantPanelContent`.
   - Conditionally applied `.verticalScroll(rememberScrollState())` only when `scrollable` is `true`.
2. **`AssistantControlScreen.kt`**:
   - Passed `scrollable = false` when calling `AssistantPanelContent()` inside `AssistantControlScreen`.
   - This eliminated nested vertical scrolling while keeping the entire screen smoothly scrollable as a single unified column.
3. **`OverlayComposables.kt`**:
   - Passed `scrollable = true` with `modifier = Modifier.fillMaxSize()` inside `OverlayContent` for floating overlay panel mode.
   - The floating window (`OverlayWindowController`) provides finite, bounded dimensions (`params.width = g.panelWidthPx`, `params.height = g.panelHeightPx`) via `WindowManager.LayoutParams`, ensuring `verticalScroll` always receives bounded max height constraints (e.g. 520dp).

---

## 2. SavedStateRegistry State Restoration Order Crash

### Root Cause Analysis
- **Offending File & Line Location:**
  - `app/src/main/java/com/eightballpro/assistant/android/overlay/ServiceComposeOwner.kt` (`onCreate()` method)
- **Mechanism:**
  In `ServiceComposeOwner.onCreate()`, `registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)` was called BEFORE `savedStateController.performRestore(null)`.
  Dispatching `ON_CREATE` prior to state restoration caused `SavedStateRegistry` to register lifecycle observers while still unrestored. When `ON_START` fired, `Recreator` called `SavedStateRegistry.consumeRestoredStateForKey()`, triggering:
  ```text
  java.lang.IllegalStateException: You can consumeRestoredStateForKey only after super.onCreate of corresponding component
  ```

### Code Fix
- Updated `ServiceComposeOwner.onCreate()` to invoke `savedStateController.performRestore(null)` BEFORE dispatching `registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)`.
- Guarantees `SavedStateRegistry.isRestored` is set prior to lifecycle event propagation, resolving `OverlayService` initialization failures.

---

## 3. Physical Device Verification Results (`00297663M000654`)

### Build & Verification Commands
```powershell
.\gradlew.bat :app:compileDebugKotlin
.\gradlew.bat :app:testDebugUnitTest
.\gradlew.bat :app:assembleDebug
adb -s 00297663M000654 install -r app/build/outputs/apk/debug/app-debug.apk
```

### Verification Checklist & Physical Device Test Run
| Test Step / Flow | Result | Description |
| :--- | :--- | :--- |
| **Kotlin Compilation** | **PASSED** | Compiled with 0 errors |
| **Unit Test Suite** | **PASSED** | All 168/168 unit tests passed |
| **APK Assembly & Streamed Install** | **PASSED** | APK installed cleanly on physical phone |
| **Service Creation & Overlay Launch** | **PASSED** | `OverlayService` started without lifecycle exceptions |
| **Bubble Display & Edge Docking** | **PASSED** | Floating 8B bubble displayed over screen edge |
| **Panel Expansion on Tap** | **PASSED** | Tapping bubble expanded panel to bounded dimensions |
| **Panel Vertical Scrolling** | **PASSED** | Panel content scrolled smoothly without infinite height crash |
| **All Panel Controls Verification** | **PASSED** | Status cards, checkboxes, capture controls, analysis controls, and aim sliders functional |
| **Repeated Open/Close Endurance** | **PASSED** | Opened and closed panel 20+ times consecutively with 100% stability |
| **Logcat Exception Check** | **PASSED** | Clean logcat capture confirmed 0 FATAL EXCEPTIONs |
