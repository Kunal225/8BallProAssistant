# 8BallProAssistant — Live Game Overlay & Screen Analysis Integration Report

## Architecture Overview

The **8BallProAssistant** live game integration operates as a non-intrusive floating overlay service designed to run on top of any active 8-ball pool application:

```
[ Active 8-Ball Pool Game ]
         │
         ├── Overlay Window (`OverlayWindowController` + `ComposeView`)
         │     ├── Floating Bubble (56dp, draggable, edge-snapping)
         │     └── Floating Assistant Panel (320dp x 520dp, expandable/collapsible)
         │
         └── Screen Analysis Pipeline (`ScreenCaptureService` + `MediaProjection`)
               ├── User Explicit Consent (`CaptureConsentActivity`)
               ├── Scaled Image Sampling (720px max width, throttling via `beginFrame`)
               ├── Computer Vision Pipeline (`AnalysisPipeline`, `BallDetector`, `TableBoundaryDetector`)
               └── Real-time 3D Physics Shot Estimates (`ShotPrediction`, `PoolPhysicsEngine`)
```

## Functional Capabilities

1. **System Alert Window (`TYPE_APPLICATION_OVERLAY`)**:
   - Displays a 56dp floating bubble over third-party applications.
   - Draggable across the screen; automatically snaps to the left or right screen edge upon release.
   - Non-blocking layout flags (`FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL`) allow full touch pass-through to the game behind the overlay.

2. **Expandable Floating Assistant Panel**:
   - Single-tap on bubble expands the panel showing live analysis status, capture controls, detection summary, and aim/power sliders.
   - Minimize button collapses panel back to floating bubble without interrupting game state.
   - Close button stops overlay service and releases all background resources.

3. **Live MediaProjection Screen Analysis**:
   - `CaptureConsentActivity` launches system permission dialog for user consent before capture begins.
   - `ScreenCaptureService` manages `VirtualDisplay` and `ImageReader` in a background `HandlerThread`.
   - Frame sampling is throttled to preserve device CPU/GPU and battery life.
   - `AnalysisPipeline` detects table felt boundary, calculates perspective calibration, extracts ball blobs, classifies cue/object balls, and computes 3D shot predictions.

4. **Resource Management & Safety**:
   - All projection resources (`VirtualDisplay`, `ImageReader`, `MediaProjection`) are released immediately when capture stops or service is destroyed.
   - Foreground notifications (`CHANNEL_OVERLAY` and `CHANNEL_CAPTURE`) comply with Android 14+ foreground service requirements (`mediaProjection` & `specialUse`).
