package com.eightballpro.assistant.android.capture

/**
 * Replaces a resource (the capture service's ImageReader) with a new one without ever being left with
 * nothing. Pure Kotlin: [T] is the resource type, so the same logic runs in the service with real readers
 * and in unit tests with fakes.
 *
 * The new resource is created and attached first. The previous one is released only after the new one is
 * attached. If creating or attaching fails, whatever was created is released, the previous resource is
 * attached again, and the caller keeps what it had.
 */
object ReaderSwap {

    sealed interface Outcome<out T : Any> {
        /** The new resource is active and the previous one has been released. */
        data class Replaced<T : Any>(val active: T) : Outcome<T>

        /** The replacement failed, and the previous resource is active again. Nothing new is left behind. */
        data class KeptPrevious<T : Any>(val active: T) : Outcome<T>

        /** The replacement failed and the previous resource could not be put back. The caller must stop. */
        data object Failed : Outcome<Nothing>
    }

    /**
     * @param previous the working resource, or null if there is none.
     * @param create builds the new resource. It must release anything it half-built before it throws.
     * @param attach makes the new resource the active one.
     * @param restore makes [previous] the active one again after a failed [attach].
     * @param release frees a resource. Failures here are swallowed, because there is nothing left to try.
     */
    fun <T : Any> swap(
        previous: T?,
        create: () -> T,
        attach: (T) -> Unit,
        restore: (T) -> Unit,
        release: (T) -> Unit,
    ): Outcome<T> {
        val fresh = try {
            create()
        } catch (e: Exception) {
            return fallBack(previous, restore)
        }
        try {
            attach(fresh)
        } catch (e: Exception) {
            releaseQuietly(fresh, release)
            return fallBack(previous, restore)
        }
        if (previous != null) releaseQuietly(previous, release)
        return Outcome.Replaced(fresh)
    }

    private fun <T : Any> fallBack(previous: T?, restore: (T) -> Unit): Outcome<T> {
        if (previous == null) return Outcome.Failed
        return try {
            restore(previous)
            Outcome.KeptPrevious(previous)
        } catch (e: Exception) {
            Outcome.Failed
        }
    }

    private fun <T : Any> releaseQuietly(resource: T, release: (T) -> Unit) {
        try {
            release(resource)
        } catch (ignored: Exception) {
        }
    }
}
