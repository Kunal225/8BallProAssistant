package com.eightballpro.assistant.domain.assistant

enum class RunState { STOPPED, RUNNING, PAUSED }

sealed interface RunEvent {
    data object Start : RunEvent
    data object Pause : RunEvent
    data object Resume : RunEvent
    data object Stop : RunEvent
    /** The capture ended for any reason: user stop, system termination, or permission revoked. */
    data object CaptureEnded : RunEvent
}

data class RunStep(val state: RunState, val message: String?)

/**
 * Start, Pause, Resume and Stop for the assistant. Analysis runs only in RUNNING. Pause and Resume do not
 * touch the capture. Stop and CaptureEnded always leave the session STOPPED, so the assistant can never
 * analyse frames without an active capture.
 */
object AssistantRunMachine {

    fun reduce(state: RunState, event: RunEvent, captureActive: Boolean): RunStep = when (event) {
        RunEvent.Start -> when {
            state != RunState.STOPPED -> RunStep(state, "Analysis is already active.")
            !captureActive -> RunStep(state, "Start screen capture before starting analysis.")
            else -> RunStep(RunState.RUNNING, null)
        }
        RunEvent.Pause -> if (state == RunState.RUNNING) RunStep(RunState.PAUSED, null)
            else RunStep(state, "Nothing to pause.")
        RunEvent.Resume -> when {
            state != RunState.PAUSED -> RunStep(state, "Analysis is not paused.")
            !captureActive -> RunStep(RunState.STOPPED, "Capture is no longer active. Start capture again.")
            else -> RunStep(RunState.RUNNING, null)
        }
        RunEvent.Stop -> RunStep(RunState.STOPPED, null)
        RunEvent.CaptureEnded -> RunStep(
            RunState.STOPPED,
            if (state == RunState.STOPPED) null else "Screen capture ended. Analysis stopped.",
        )
    }

    /** A frame is analysed only while running and only if the previous frame has finished. */
    fun mayProcessFrame(state: RunState, previousFrameInFlight: Boolean): Boolean =
        state == RunState.RUNNING && !previousFrameInFlight
}
