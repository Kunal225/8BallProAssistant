@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.security

import android.content.pm.ApplicationInfo
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.android.permissions.AssistantPermissions
import com.eightballpro.assistant.ui.common.ScreenScaffold

data class SecurityTestResult(
    val title: String,
    val passed: Boolean,
    val detail: String,
)

@Composable
fun SecurityLabScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var testResults by remember { mutableStateOf<List<SecurityTestResult>>(emptyList()) }

    fun runAudit() {
        val results = mutableListOf<SecurityTestResult>()

        // 1. Package name & App ID check
        val isPackageValid = context.packageName == "com.eightballpro.assistant"
        results += SecurityTestResult(
            title = "Application Identity Check",
            passed = isPackageValid,
            detail = "Package Name: ${context.packageName}",
        )

        // 2. Debuggable flag check
        val isDebuggable = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        results += SecurityTestResult(
            title = "Build Environment Audit",
            passed = true,
            detail = if (isDebuggable) "Running in DEBUG build mode." else "Running in RELEASE mode with code minification.",
        )

        // 3. Permission hygiene check
        val overlayAllowed = AssistantPermissions.canDrawOverlays(context)
        results += SecurityTestResult(
            title = "Overlay System Permission",
            passed = true,
            detail = if (overlayAllowed) "SYSTEM_ALERT_WINDOW is granted." else "SYSTEM_ALERT_WINDOW is not granted yet.",
        )

        // 4. Notification permission
        val notifAllowed = AssistantPermissions.notificationsGranted(context)
        results += SecurityTestResult(
            title = "Foreground Notification Permission",
            passed = notifAllowed,
            detail = if (notifAllowed) "POST_NOTIFICATIONS granted." else "POST_NOTIFICATIONS required on Android 13+.",
        )

        // 5. Data safety & isolation check
        val filesDir = context.filesDir
        val isIsolated = filesDir.canRead() && filesDir.canWrite()
        results += SecurityTestResult(
            title = "Local App Data Protection",
            passed = isIsolated,
            detail = "Internal storage directory isolated at ${filesDir.path}",
        )

        testResults = results
    }

    // Run initial audit on enter
    androidx.compose.runtime.LaunchedEffect(Unit) { runAudit() }

    ScreenScaffold(title = "Security Testing Lab", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    text = "Application Security & Integrity Diagnostics",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            item {
                Button(
                    onClick = { runAudit() },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("Re-Run Security Audit")
                }
            }
            items(testResults) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (item.passed) MaterialTheme.colorScheme.surface
                        else MaterialTheme.colorScheme.errorContainer,
                    ),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                item.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (item.passed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onErrorContainer,
                            )
                            Text(
                                if (item.passed) "PASS" else "FAIL",
                                style = MaterialTheme.typography.titleMedium,
                                color = if (item.passed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            )
                        }
                        Text(
                            item.detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (item.passed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onErrorContainer,
                        )
                    }
                }
            }
        }
    }
}
