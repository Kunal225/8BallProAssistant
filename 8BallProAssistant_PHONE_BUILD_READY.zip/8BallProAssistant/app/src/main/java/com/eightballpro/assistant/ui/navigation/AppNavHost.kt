package com.eightballpro.assistant.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.eightballpro.assistant.ui.accuracy.AccuracyReportsScreen
import com.eightballpro.assistant.ui.aim.AimCalculatorScreen
import com.eightballpro.assistant.ui.assistant.AssistantControlScreen
import com.eightballpro.assistant.ui.dashboard.DashboardScreen
import com.eightballpro.assistant.ui.distance.DistancePredictorScreen
import com.eightballpro.assistant.ui.power.PowerCalculatorScreen
import com.eightballpro.assistant.ui.security.SecurityLabScreen
import com.eightballpro.assistant.ui.settings.AppSettingsScreen
import com.eightballpro.assistant.ui.settings.PhysicsSettingsScreen
import com.eightballpro.assistant.ui.spin.SpinControlScreen
import com.eightballpro.assistant.ui.table.TableSimulatorScreen
import com.eightballpro.assistant.ui.vision.ImageAnalyzerScreen

@Composable
fun AppNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = AppDestination.DASHBOARD.route) {
        AppDestination.entries.forEach { destination ->
            composable(destination.route) {
                val onBack: () -> Unit = { navController.popBackStack() }
                when (destination) {
                    AppDestination.DASHBOARD -> DashboardScreen(
                        destinations = AppDestination.entries.filter { it != AppDestination.DASHBOARD },
                        onNavigate = { navController.navigate(it.route) },
                    )
                    AppDestination.TABLE_SIMULATOR -> TableSimulatorScreen(onBack = onBack)
                    AppDestination.SPIN_CONTROL -> SpinControlScreen(onBack = onBack)
                    AppDestination.AIM_CALCULATOR -> AimCalculatorScreen(onBack = onBack)
                    AppDestination.DISTANCE_PREDICTOR -> DistancePredictorScreen(onBack = onBack)
                    AppDestination.POWER_CALCULATOR -> PowerCalculatorScreen(onBack = onBack)
                    AppDestination.PHYSICS_SETTINGS -> PhysicsSettingsScreen(onBack = onBack)
                    AppDestination.IMAGE_ANALYZER -> ImageAnalyzerScreen(onBack = onBack)
                    AppDestination.SECURITY_LAB -> SecurityLabScreen(onBack = onBack)
                    AppDestination.ACCURACY_REPORTS -> AccuracyReportsScreen(onBack = onBack)
                    AppDestination.ASSISTANT -> AssistantControlScreen(onBack = onBack)
                    AppDestination.APP_SETTINGS -> AppSettingsScreen(onBack = onBack)
                }
            }
        }
    }
}
