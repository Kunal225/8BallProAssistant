package com.eightballpro.assistant.domain.overlay

data class ScreenBounds(val width: Int, val height: Int) {
    init {
        require(width > 0 && height > 0) { "screen size must be positive" }
    }
}

data class OverlayPosition(val x: Int, val y: Int)

data class OverlayGeometry(
    val bubbleSizePx: Int = 56,
    val panelWidthPx: Int = 320,
    val panelHeightPx: Int = 520,
    val marginPx: Int = 8,
)

sealed interface OverlayState {
    data object Hidden : OverlayState
    data object NeedsPermission : OverlayState
    data class Bubble(val position: OverlayPosition) : OverlayState
    data class Panel(val position: OverlayPosition) : OverlayState
}

sealed interface OverlayEvent {
    data object PermissionMissing : OverlayEvent
    data class PermissionGranted(val savedPosition: OverlayPosition?) : OverlayEvent
    data class ShowBubble(val savedPosition: OverlayPosition?) : OverlayEvent
    data object TapBubble : OverlayEvent
    data object Minimize : OverlayEvent
    data object Close : OverlayEvent
    data class Drag(val dx: Int, val dy: Int) : OverlayEvent
    data object SnapToNearestEdge : OverlayEvent
}

/**
 * Pure state machine for the floating bubble and panel. The Android service maps window
 * events onto these transitions and applies the resulting position to the overlay window.
 * Invalid events leave the state unchanged.
 */
object OverlayStateMachine {

    fun reduce(
        state: OverlayState,
        event: OverlayEvent,
        screen: ScreenBounds,
        geometry: OverlayGeometry = OverlayGeometry(),
    ): OverlayState = when (event) {
        OverlayEvent.PermissionMissing ->
            if (state == OverlayState.Hidden) OverlayState.NeedsPermission else state

        is OverlayEvent.PermissionGranted ->
            if (state == OverlayState.NeedsPermission) {
                OverlayState.Bubble(clamp(event.savedPosition ?: defaultBubble(screen, geometry), geometry.bubbleSizePx, screen, geometry))
            } else state

        is OverlayEvent.ShowBubble ->
            if (state == OverlayState.Hidden) {
                OverlayState.Bubble(clamp(event.savedPosition ?: defaultBubble(screen, geometry), geometry.bubbleSizePx, screen, geometry))
            } else state

        OverlayEvent.TapBubble -> when (state) {
            is OverlayState.Bubble -> OverlayState.Panel(clamp(state.position, geometry.panelWidthPx, screen, geometry, geometry.panelHeightPx))
            else -> state
        }

        OverlayEvent.Minimize -> when (state) {
            is OverlayState.Panel -> OverlayState.Bubble(clamp(state.position, geometry.bubbleSizePx, screen, geometry))
            else -> state
        }

        OverlayEvent.Close -> OverlayState.Hidden

        is OverlayEvent.Drag -> when (state) {
            is OverlayState.Bubble -> OverlayState.Bubble(
                clamp(moved(state.position, event), geometry.bubbleSizePx, screen, geometry)
            )
            is OverlayState.Panel -> OverlayState.Panel(
                clamp(moved(state.position, event), geometry.panelWidthPx, screen, geometry, geometry.panelHeightPx)
            )
            else -> state
        }

        OverlayEvent.SnapToNearestEdge -> when (state) {
            is OverlayState.Bubble -> OverlayState.Bubble(snapX(state.position, geometry.bubbleSizePx, screen, geometry))
            is OverlayState.Panel -> OverlayState.Panel(
                snapX(state.position, geometry.panelWidthPx, screen, geometry, geometry.panelHeightPx)
            )
            else -> state
        }
    }

    /** Width of a panel is [widthPx]; height defaults to the bubble square. */
    private fun clamp(
        p: OverlayPosition,
        widthPx: Int,
        screen: ScreenBounds,
        geometry: OverlayGeometry,
        heightPx: Int = widthPx,
    ): OverlayPosition {
        val maxX = (screen.width - widthPx - geometry.marginPx).coerceAtLeast(geometry.marginPx)
        val maxY = (screen.height - heightPx - geometry.marginPx).coerceAtLeast(geometry.marginPx)
        return OverlayPosition(
            x = p.x.coerceIn(geometry.marginPx, maxX),
            y = p.y.coerceIn(geometry.marginPx, maxY),
        )
    }

    private fun moved(p: OverlayPosition, drag: OverlayEvent.Drag) = OverlayPosition(p.x + drag.dx, p.y + drag.dy)

    private fun snapX(p: OverlayPosition, widthPx: Int, screen: ScreenBounds, geometry: OverlayGeometry, heightPx: Int = widthPx): OverlayPosition {
        val centreX = p.x + widthPx / 2
        val x = if (centreX < screen.width / 2) geometry.marginPx else screen.width - widthPx - geometry.marginPx
        return clamp(OverlayPosition(x, p.y), widthPx, screen, geometry, heightPx)
    }

    private fun defaultBubble(screen: ScreenBounds, geometry: OverlayGeometry) =
        OverlayPosition(x = screen.width - geometry.bubbleSizePx - geometry.marginPx, y = screen.height / 3)
}
