package com.eightballpro.assistant.domain.assistant

import com.eightballpro.assistant.domain.analysis.AnalysisResult
import com.eightballpro.assistant.domain.analysis.PhysicsInput
import com.eightballpro.assistant.domain.physics3d.ShotResult
import com.eightballpro.assistant.domain.vision.BallClass
import com.eightballpro.assistant.domain.vision.Confidence

data class DetectionView(
    val tableStatus: String,
    val ballCount: Int,
    val cueFound: Boolean,
    val warnings: List<String>,
)

enum class PredictionConfidence { NONE, LOW, MEDIUM }

data class PredictionView(
    val available: Boolean,
    val headline: String,
    val confidence: PredictionConfidence,
    val limitations: List<String>,
)

/**
 * Turns analysis and physics results into text for the panel. It never shows a prediction unless a
 * cue ball was detected with enough confidence and a shot has been simulated. Confidence is never HIGH,
 * because the model is not validated against measured shots.
 */
object AssistantPresenter {

    private val STANDARD_LIMITATIONS = listOf(
        "Estimate from a single frame. Not measured against the real table.",
        "Spin, friction and cushion behaviour are model values, not calibrated.",
        "Table corners must be correct; check the calibration before trusting the result.",
    )

    fun detection(result: AnalysisResult?): DetectionView {
        if (result == null) return DetectionView("No frame analysed yet", 0, false, emptyList())
        val status = when {
            result.table == null -> "Table not detected"
            result.tableAssessment?.level in setOf(Confidence.HIGH, Confidence.MEDIUM, Confidence.USER_CONFIRMED) -> "Table detected"
            else -> "Table detected (uncertain)"
        }
        val confidentCue = result.balls.any {
            it.cls == BallClass.CUE && it.assessment.level in setOf(Confidence.HIGH, Confidence.MEDIUM, Confidence.USER_CONFIRMED)
        }
        return DetectionView(
            tableStatus = status,
            ballCount = result.balls.size,
            cueFound = confidentCue,
            warnings = result.warnings,
        )
    }

    fun prediction(physics: PhysicsInput?, shot: ShotResult?): PredictionView {
        if (physics == null || physics.balls.none { it.isCue }) {
            return PredictionView(false, "Prediction unavailable: no confident cue ball.", PredictionConfidence.NONE, emptyList())
        }
        if (shot == null) {
            return PredictionView(false, "Set aim and power to preview a shot.", PredictionConfidence.NONE, emptyList())
        }
        val confidence = if (physics.excluded.isEmpty()) PredictionConfidence.MEDIUM else PredictionConfidence.LOW
        val limitations = if (physics.excluded.isEmpty()) STANDARD_LIMITATIONS
            else STANDARD_LIMITATIONS + "${physics.excluded.size} uncertain ball(s) were left out of the simulation."

        val pocketedText = if (shot.pocketed.isNotEmpty()) {
            "Pocket predicted: " + shot.pocketed.joinToString(", ") {
                "ball ${it.ballId} in ${it.pocket.name.lowercase().replace('_', ' ')}"
            }
        } else {
            "No pocket entry predicted"
        }
        val headline = "Estimated: cue travels %.2f m, %d collision(s), %d cushion hit(s). %s.".format(
            shot.cueDistance, shot.collisionCount, shot.cushionCount, pocketedText,
        )
        return PredictionView(true, headline, confidence, limitations)
    }
}
