package com.eightballpro.assistant.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.domain.assistant.AssistantSnapshot
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.table.TableSpec
import com.eightballpro.assistant.domain.vision.BallClass

// ─────────────────────────── Palette ───────────────────────────────────────
private val FrameColor      = Color(0xFF1B2A44)
private val FeltColor       = Color(0xFF1F6FB2)
private val PocketColor     = Color(0xFF05080F)
private val PocketZoneColor = Color(0x33FFFFFF)
private val AimDashColor    = Color(0xFFF2C14E)   // golden dashed aim line
private val CuePathColor    = Color(0xFF3DDC97)   // green predicted cue path
private val ObjectPathColor = Color(0xFFFF8A3D)   // orange object ball path
private val CueCircleColor  = Color(0xFFFFFFFF)   // white cue ball fill
private val CueRingDetected = Color(0xFF42A5F5)   // blue ring = detected
private val CueRingFallback = Color(0xFF9E9E9E)   // grey ring = placeholder
private val ImpactColor     = Color(0xFFE53935)   // red contact point dot

/**
 * Coordinate convention (single source of truth):
 *
 *   Normalised (u, v) ∈ [0, 1] × [0, 1]
 *     u = 0 → left rail (top-left of cloth)   u = 1 → right rail
 *     v = 0 → top  rail                       v = 1 → bottom rail
 *
 *   Metres (x, y):  physics world.
 *     x = u × tableLength,  y = v × tableWidth
 *
 *   Screen pixels (px, py):
 *     Computed by [TrajectoryRenderer.normalisedToScreen] with a uniform
 *     scale factor that fits the table into the canvas while preserving the
 *     table's aspect ratio and leaving an [inset]-pixel border on all sides.
 *
 * All coordinate conversions go through [TrajectoryRenderer]. No ad-hoc
 * multiplication by tableLength/tableWidth is done inside the Canvas block.
 *
 * Visual elements:
 *   1. Table cloth rectangle.
 *   2. Six pocket zones.
 *   3. All detected balls (small circles, 8 px radius).
 *   4. Cue ball marker (12 px radius, white fill).
 *      – Blue ring  : position from live detection.
 *      – Grey ring  : placeholder at break position (u=0.25, v=0.5).
 *   5. Dashed aim line from cue ball to aim target.
 *   6. Physics predicted cue path (green), when prediction.available.
 *   7. Physics predicted object ball paths (orange), for balls that move.
 *   8. Contact-point dot on the first object ball hit.
 *   9. Status badge (bottom-left).
 *
 * When the aim line would be zero-length the canvas still shows the table,
 * the cue ball, and a status message — it is never completely blank.
 */
@Composable
fun LiveTrajectoryCanvas(
    snapshot: AssistantSnapshot,
    modifier: Modifier = Modifier,
) {
    val table = remember { TableGeometry3D.from(TableSpec.NINE_FOOT) }
    val prediction = snapshot.prediction
    val result     = snapshot.latestResult
    val shot       = snapshot.latestShot

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(FrameColor),
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height
            val inset   = 16f
            val tLen    = table.length
            val tWid    = table.width

            // ── Convenience wrappers that delegate to TrajectoryRenderer ──────
            fun uv2Screen(u: Double, v: Double): Offset {
                val (x, y) = TrajectoryRenderer.normalisedToScreen(
                    u, v, canvasW, canvasH, tLen, tWid, inset
                )
                return Offset(x, y)
            }

            // ── 1. Table cloth ────────────────────────────────────────────────
            val origin    = uv2Screen(0.0, 0.0)
            val farCorner = uv2Screen(1.0, 1.0)
            drawRect(
                color   = FeltColor,
                topLeft = origin,
                size    = Size(farCorner.x - origin.x, farCorner.y - origin.y),
            )

            // ── 2. Pockets ─────────────────────────────────────────────────────
            // Pocket.x and Pocket.y are in METRES. Convert to normalised first.
            table.pockets.forEach { pocket ->
                val pocketU = pocket.x / tLen
                val pocketV = pocket.y / tWid
                val center  = uv2Screen(pocketU, pocketV)
                // captureRadius in metres → scale to pixels using the same uniform scale
                val scaleX = (canvasW - 2 * inset) / tLen.toFloat()
                val scaleY = (canvasH - 2 * inset) / tWid.toFloat()
                val scale  = minOf(scaleX, scaleY)
                drawCircle(PocketZoneColor, (pocket.captureRadius * scale).toFloat(), center)
                drawCircle(PocketColor, 8f, center)
            }

            // ── 3. Detected balls (small background dots) ─────────────────────
            result?.balls?.forEach { ball ->
                val pos   = uv2Screen(ball.centre.x, ball.centre.y)
                val color = when (ball.cls) {
                    BallClass.CUE    -> Color.White
                    BallClass.BLACK  -> Color(0xFF212121)
                    else             -> Color(0xFFF2C14E)
                }
                drawCircle(color, 7f, pos)
            }

            // ── 4 + 5. Derive rendering state and draw cue ball + aim line ────
            val rs = TrajectoryRenderer.deriveState(
                latestResult  = result,
                aim           = snapshot.aim,
                predAvailable = prediction.available,
                physicsFrames = shot?.frames ?: emptyList(),
                tableLengthM  = tLen,
                tableWidthM   = tWid,
                canvasW       = canvasW,
                canvasH       = canvasH,
                inset         = inset,
            )

            // Cue ball marker
            val cuePos = uv2Screen(rs.cueBall.u, rs.cueBall.v)
            drawCircle(CueCircleColor, 12f, cuePos)
            drawCircle(
                color  = if (rs.cueBall.isDetected) CueRingDetected else CueRingFallback,
                radius = 12f,
                center = cuePos,
                style  = Stroke(width = 2.5f),
            )

            // Dashed aim line (always drawn when non-trivial)
            if (rs.aimLine.isNonTrivial) {
                val aimFrom = uv2Screen(rs.aimLine.fromU, rs.aimLine.fromV)
                val aimTo   = uv2Screen(rs.aimLine.toU,   rs.aimLine.toV)
                val dash    = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
                drawLine(
                    color       = AimDashColor,
                    start       = aimFrom,
                    end         = aimTo,
                    strokeWidth = 3f,
                    pathEffect  = dash,
                )
                // Arrowhead tip at aimTo
                drawArrow(aimFrom, aimTo, AimDashColor, 18f)
            }

            // ── 6. Physics cue path (green) ───────────────────────────────────
            if (rs.cuePath.size >= 2) {
                val path = Path()
                rs.cuePath.forEachIndexed { i, pt ->
                    val sp = uv2Screen(pt.u, pt.v)
                    if (i == 0) path.moveTo(sp.x, sp.y) else path.lineTo(sp.x, sp.y)
                }
                drawPath(path, color = CuePathColor, style = Stroke(width = 4f))
            }

            // ── 7. Physics object paths (orange) ─────────────────────────────
            rs.objectPaths.forEach { (_, pts) ->
                if (pts.size < 2) return@forEach
                val path = Path()
                pts.forEachIndexed { i, pt ->
                    val sp = uv2Screen(pt.u, pt.v)
                    if (i == 0) path.moveTo(sp.x, sp.y) else path.lineTo(sp.x, sp.y)
                }
                drawPath(path, color = ObjectPathColor, style = Stroke(width = 3f))
            }

            // ── 8. Contact-point dot: where the physics says the cue ball first touches another ball.
            // It comes from the collision event. The end of the cue path is where the ball stops, not a contact.
            val contact = if (prediction.available) {
                shot?.let { TrajectoryRenderer.firstCueContact(it.events, tLen, tWid) }
            } else {
                null
            }
            if (contact != null) {
                val impactPt = uv2Screen(contact.u, contact.v)
                drawCircle(ImpactColor, 8f, impactPt)
                drawCircle(Color.White, 4f, impactPt)
            }
        }

        // ── 9. Status badge (top-start) ───────────────────────────────────────
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp),
        ) {
            val rs = TrajectoryRenderer.deriveState(
                latestResult  = snapshot.latestResult,
                aim           = snapshot.aim,
                predAvailable = snapshot.prediction.available,
                physicsFrames = snapshot.latestShot?.frames ?: emptyList(),
                // Canvas size unknown here — pass dummy values; only statusLabel is used
                tableLengthM  = TableGeometry3D.from(TableSpec.NINE_FOOT).length,
                tableWidthM   = TableGeometry3D.from(TableSpec.NINE_FOOT).width,
                canvasW       = 800f,
                canvasH       = 400f,
            )
            Surface(
                shape = RoundedCornerShape(50),
                color = when (rs.status) {
                    TrajectoryRenderer.CanvasStatus.LIVE_PREDICTION        ->
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.90f)
                    TrajectoryRenderer.CanvasStatus.CUE_DETECTED_MANUAL_AIM ->
                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.85f)
                    else ->
                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.70f)
                },
            ) {
                Text(
                    text     = rs.statusLabel,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style    = MaterialTheme.typography.labelSmall,
                    color    = Color.White,
                )
            }
        }
    }
}

// ─────────────────────────── Helpers ─────────────────────────────────────────

/** Draws a filled arrowhead pointing from [from] toward [to]. */
private fun DrawScope.drawArrow(from: Offset, to: Offset, color: Color, size: Float) {
    val dx  = to.x - from.x
    val dy  = to.y - from.y
    val len = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    if (len < 1f) return
    
    // Prevent the arrowhead from covering the entire short line
    val actualSize = minOf(size, len * 0.3f)
    
    val nx  = dx / len
    val ny  = dy / len
    // Two wing points perpendicular to the direction
    val lx  = to.x - actualSize * nx + actualSize * 0.45f * ny
    val ly  = to.y - actualSize * ny - actualSize * 0.45f * nx
    val rx  = to.x - actualSize * nx - actualSize * 0.45f * ny
    val ry  = to.y - actualSize * ny + actualSize * 0.45f * nx
    val arrowPath = Path().apply {
        moveTo(to.x, to.y)
        lineTo(lx, ly)
        lineTo(rx, ry)
        close()
    }
    drawPath(arrowPath, color = color)
}
