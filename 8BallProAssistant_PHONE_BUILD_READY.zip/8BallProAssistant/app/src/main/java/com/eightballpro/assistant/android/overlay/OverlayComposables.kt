package com.eightballpro.assistant.android.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.ui.assistant.AssistantPanelContent

enum class OverlayMode { BUBBLE, PANEL }

@Composable
fun OverlayContent(
    mode: OverlayMode,
    onBubbleTap: () -> Unit,
    onBubbleDrag: (Float, Float) -> Unit,
    onBubbleDragEnd: () -> Unit,
    onHide: () -> Unit,
    onClose: () -> Unit,
) {
    when (mode) {
        OverlayMode.BUBBLE -> FloatingBubble(onBubbleTap, onBubbleDrag, onBubbleDragEnd)
        OverlayMode.PANEL -> AssistantPanelContent(
            onHide = onHide,
            onClose = onClose,
            modifier = Modifier.fillMaxSize(),
            scrollable = true,
        )
    }
}

/**
 * 56 dp bubble. Uses low-level Compose pointer input (`awaitEachGesture`, `awaitFirstDown`,
 * `awaitTouchSlopOrCancellation`, `waitForUpOrCancellation`) for 100% deterministic tap vs. drag detection.
 */
@Composable
fun FloatingBubble(onTap: () -> Unit, onDrag: (Float, Float) -> Unit, onDragEnd: () -> Unit) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var dragChange = awaitTouchSlopOrCancellation(down.id) { change, overSlop ->
                        change.consume()
                        onDrag(overSlop.x, overSlop.y)
                    }

                    if (dragChange != null) {
                        // Pointer crossed touch slop: this is a DRAG gesture.
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == dragChange!!.id } ?: break
                            if (!change.pressed) {
                                onDragEnd()
                                break
                            }
                            val amount = change.positionChange()
                            if (amount != Offset.Zero) {
                                change.consume()
                                onDrag(amount.x, amount.y)
                            }
                        }
                    } else {
                        // Pointer released before crossing touch slop: check for TAP up event.
                        val up = waitForUpOrCancellation()
                        if (up != null) {
                            up.consume()
                            onTap()
                        }
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(text = "8B", color = Color.White, fontWeight = FontWeight.Bold)
    }
}
