package com.eightballpro.assistant.android.overlay

import android.app.Service
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.eightballpro.assistant.android.AssistantController
import com.eightballpro.assistant.android.permissions.AssistantPermissions
import com.eightballpro.assistant.domain.overlay.OverlayEvent
import com.eightballpro.assistant.domain.overlay.OverlayGeometry
import com.eightballpro.assistant.domain.overlay.OverlayPosition
import com.eightballpro.assistant.domain.overlay.OverlayState
import com.eightballpro.assistant.domain.overlay.OverlayStateMachine
import com.eightballpro.assistant.domain.overlay.ScreenBounds
import com.eightballpro.assistant.ui.common.GameOverlayCanvas
import kotlin.math.roundToInt

/**
 * Adds the floating bubble or panel to the WindowManager. Layout changes come from [OverlayStateMachine],
 * so this class only applies positions and sizes. The window is not focusable and does not capture touches
 * outside its bounds, so other apps keep receiving their input.
 */
class OverlayWindowController(
    private val service: Service,
    private val onCloseRequested: () -> Unit,
) {
    private val windowManager: WindowManager = service.getSystemService(WindowManager::class.java)
    private val prefs = service.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private var density = service.resources.displayMetrics.density
    private val owner = ServiceComposeOwner()
    private val view = ComposeView(service)
    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private val gameOverlayView = ComposeView(service)
    private val gameOverlayParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        // Without this, a landscape display with a camera cutout insets the window, and everything drawn on
        // it is shifted away from the same point in the captured frame.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private var mode by mutableStateOf(OverlayMode.BUBBLE)
    private var state: OverlayState = OverlayState.Hidden
    private var attached = false
    private var residualX = 0f
    private var residualY = 0f

    /** Adds the window. Returns false if the overlay permission is missing or the window cannot be added. */
    fun show(): Boolean {
        if (!AssistantPermissions.canDrawOverlays(service)) return false
        owner.onCreate()

        gameOverlayView.setViewTreeLifecycleOwner(owner)
        gameOverlayView.setViewTreeViewModelStoreOwner(owner)
        gameOverlayView.setViewTreeSavedStateRegistryOwner(owner)
        gameOverlayView.setContent {
            val snapshot by AssistantController.snapshot.collectAsState()
            MaterialTheme {
                GameOverlayCanvas(snapshot = snapshot)
            }
        }

        view.setViewTreeLifecycleOwner(owner)
        view.setViewTreeViewModelStoreOwner(owner)
        view.setViewTreeSavedStateRegistryOwner(owner)
        view.setContent {
            MaterialTheme {
                OverlayContent(
                    mode = mode,
                    onBubbleTap = { dispatch(OverlayEvent.TapBubble) },
                    onBubbleDrag = { dx, dy -> onDrag(dx, dy) },
                    onBubbleDragEnd = { onDragEnd() },
                    onHide = { dispatch(OverlayEvent.Minimize) },
                    onClose = { onCloseRequested() },
                )
            }
        }
        state = OverlayState.Hidden
        applyLayout(OverlayStateMachine.reduce(state, OverlayEvent.ShowBubble(savedPosition()), screen(), geometry()))
        var gameOverlayAdded = false
        try {
            windowManager.addView(gameOverlayView, gameOverlayParams)
            gameOverlayAdded = true
        } catch (e: RuntimeException) {
            // The panel still works without the drawing layer, but the user would get no lines on the game.
            Log.w(TAG, "Could not add the game overlay window.", e)
        }
        return try {
            windowManager.addView(view, params)
            attached = true
            true
        } catch (e: RuntimeException) {
            // The drawing layer covers the whole screen, so it must not stay behind without a panel to close it.
            if (gameOverlayAdded) {
                try {
                    windowManager.removeView(gameOverlayView)
                } catch (ignored: RuntimeException) {
                }
            }
            owner.onDestroy()
            false
        }
    }

    fun onDrag(dx: Float, dy: Float) {
        val tx = dx + residualX
        val ty = dy + residualY
        val ix = tx.roundToInt()
        val iy = ty.roundToInt()
        residualX = tx - ix
        residualY = ty - iy
        dispatch(OverlayEvent.Drag(ix, iy))
    }

    fun onDragEnd() {
        residualX = 0f
        residualY = 0f
        dispatch(OverlayEvent.SnapToNearestEdge)
        savePosition()
    }

    /** Re-clamps the window after a rotation or other screen-size change. */
    fun onConfigurationChanged() {
        density = service.resources.displayMetrics.density
        dispatch(OverlayEvent.Drag(0, 0))
    }

    /** Removes the window and releases the Compose owner. Safe to call more than once. */
    fun destroy() {
        if (attached) {
            try {
                gameOverlayView.disposeComposition()
                view.disposeComposition()
            } catch (ignored: RuntimeException) {
            }
            try {
                windowManager.removeView(gameOverlayView)
            } catch (ignored: RuntimeException) {
            }
            try {
                windowManager.removeView(view)
            } catch (e: RuntimeException) {
                try {
                    windowManager.removeViewImmediate(view)
                } catch (ignored: RuntimeException) {
                }
            }
            attached = false
        }
        owner.onDestroy()
        state = OverlayState.Hidden
    }

    private fun dispatch(event: OverlayEvent) {
        applyLayout(OverlayStateMachine.reduce(state, event, screen(), geometry()))
    }

    private fun applyLayout(newState: OverlayState) {
        state = newState
        val g = geometry()
        when (val s = newState) {
            is OverlayState.Bubble -> {
                params.x = s.position.x
                params.y = s.position.y
                params.width = g.bubbleSizePx
                params.height = g.bubbleSizePx
            }
            is OverlayState.Panel -> {
                params.x = s.position.x
                params.y = s.position.y
                params.width = g.panelWidthPx
                params.height = g.panelHeightPx
            }
            OverlayState.Hidden, OverlayState.NeedsPermission -> Unit
        }
        mode = if (newState is OverlayState.Panel) OverlayMode.PANEL else OverlayMode.BUBBLE
        if (attached) {
            try {
                windowManager.updateViewLayout(view, params)
            } catch (e: RuntimeException) {
                // The permission was revoked or the window was removed by the system.
                onCloseRequested()
            }
        }
    }

    private fun screen(): ScreenBounds {
        val m = service.resources.displayMetrics
        return ScreenBounds(m.widthPixels.coerceAtLeast(1), m.heightPixels.coerceAtLeast(1))
    }

    private fun geometry(): OverlayGeometry {
        val s = screen()
        val margin = px(8)
        val panelHeight = minOf(px(520), (s.height - 2 * margin).coerceAtLeast(px(160)))
        val panelWidth = minOf(px(320), (s.width - 2 * margin).coerceAtLeast(px(200)))
        return OverlayGeometry(
            bubbleSizePx = px(56),
            panelWidthPx = panelWidth,
            panelHeightPx = panelHeight,
            marginPx = margin,
        )
    }

    private fun px(dp: Int): Int = (dp * density).roundToInt()

    private fun savedPosition(): OverlayPosition? =
        if (prefs.contains(KEY_X) && prefs.contains(KEY_Y)) {
            OverlayPosition(prefs.getInt(KEY_X, 0), prefs.getInt(KEY_Y, 0))
        } else {
            null
        }

    private fun savePosition() {
        val p = (state as? OverlayState.Bubble)?.position ?: return
        prefs.edit().putInt(KEY_X, p.x).putInt(KEY_Y, p.y).apply()
    }

    private companion object {
        const val TAG = "OverlayWindowController"
        const val PREFS = "assistant_overlay"
        const val KEY_X = "bubble_x"
        const val KEY_Y = "bubble_y"
    }
}
