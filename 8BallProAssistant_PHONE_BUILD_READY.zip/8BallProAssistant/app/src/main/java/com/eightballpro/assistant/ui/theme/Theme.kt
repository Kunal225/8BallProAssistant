package com.eightballpro.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PoolBlue = Color(0xFF2F7DD1)
private val PoolCyan = Color(0xFF5BC0EB)
private val PoolGold = Color(0xFFF2C14E)
private val Night = Color(0xFF0B1220)
private val Panel = Color(0xFF121C2E)
private val PanelVariant = Color(0xFF1B2A44)
private val TextPrimary = Color(0xFFE8EEF8)
private val TextSecondary = Color(0xFF9AA8BF)
private val Outline = Color(0xFF4A5A75)

private val DarkColors = darkColorScheme(
    primary = PoolBlue,
    onPrimary = Color.White,
    secondary = PoolCyan,
    onSecondary = Night,
    tertiary = PoolGold,
    onTertiary = Night,
    background = Night,
    onBackground = TextPrimary,
    surface = Panel,
    onSurface = TextPrimary,
    surfaceVariant = PanelVariant,
    onSurfaceVariant = TextSecondary,
    outline = Outline,
)

/** Dark-only theme. The pool-table palette is intentionally fixed for Batch 1. */
@Composable
fun EightBallProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = Typography(),
        content = content,
    )
}
