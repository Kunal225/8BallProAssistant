package com.eightballpro.assistant.ui.navigation

enum class ModuleState { READY, PARTIAL, PENDING }

/**
 * Every screen in the app. All 7 Batches are fully implemented and verified.
 * [state] represents module completion state.
 * [batch] is the batch that defines the module.
 */
enum class AppDestination(
    val route: String,
    val title: String,
    val state: ModuleState,
    val batch: Int,
    val summary: String,
) {
    DASHBOARD("dashboard", "Dashboard", ModuleState.READY, 1,
        "Module overview and application dashboard"),
    TABLE_SIMULATOR("table_simulator", "Pool Table Simulator", ModuleState.READY, 2,
        "3D practice table: place balls, shoot, view trajectories, spin & power controls"),
    SPIN_CONTROL("spin_control", "Spin Control", ModuleState.READY, 3,
        "Cue-ball contact selector and spin dynamics"),
    AIM_CALCULATOR("aim_calculator", "Aim Calculator", ModuleState.READY, 4,
        "Ghost-ball aiming and collision prediction"),
    DISTANCE_PREDICTOR("distance_predictor", "Distance Predictor", ModuleState.READY, 4,
        "Travel distance and stopping-position estimates"),
    POWER_CALCULATOR("power_calculator", "Power Calculator", ModuleState.READY, 4,
        "Shot power and collision speed"),
    PHYSICS_SETTINGS("physics_settings", "Physics Settings", ModuleState.READY, 2,
        "Friction and restitution parameters drive the 3D physics engine"),
    IMAGE_ANALYZER("image_analyzer", "Image Analyzer", ModuleState.READY, 5,
        "Offline table and ball recognition"),
    SECURITY_LAB("security_lab", "Security Testing Lab", ModuleState.READY, 6,
        "Integrity, network and authentication tests for authorised targets"),
    ACCURACY_REPORTS("accuracy_reports", "Accuracy Reports", ModuleState.READY, 7,
        "Measured prediction accuracy reports"),
    ASSISTANT("assistant", "Floating Assistant", ModuleState.READY, 4,
        "Floating bubble, panel and screen capture"),
    APP_SETTINGS("app_settings", "Application Settings", ModuleState.READY, 1,
        "Display and behaviour preferences"),
}
