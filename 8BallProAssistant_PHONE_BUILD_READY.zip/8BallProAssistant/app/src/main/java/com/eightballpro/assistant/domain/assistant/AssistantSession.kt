package com.eightballpro.assistant.domain.assistant

import com.eightballpro.assistant.domain.analysis.AnalysisResult
import com.eightballpro.assistant.domain.analysis.FrameAnalysisCoordinator
import com.eightballpro.assistant.domain.analysis.FrameOutcome
import com.eightballpro.assistant.domain.analysis.PredictionTicket
import com.eightballpro.assistant.domain.capture.CaptureEvent
import com.eightballpro.assistant.domain.capture.CaptureState
import com.eightballpro.assistant.domain.capture.CaptureStateMachine
import com.eightballpro.assistant.domain.capture.StopReason
import com.eightballpro.assistant.domain.frame.RawFrame
import com.eightballpro.assistant.domain.mode.Authorization
import com.eightballpro.assistant.domain.mode.GameMode
import com.eightballpro.assistant.domain.physics3d.ShotResult
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.table.TableSpec

/** Aim and power chosen by the user, as fractions of the table and of the power range. */
data class AimSettings(val targetU: Double = 0.5, val targetV: Double = 0.5, val power: Double = 0.5) {
    init {
        require(targetU in 0.0..1.0 && targetV in 0.0..1.0 && power in 0.0..1.0) { "aim values must be within [0, 1]" }
    }

    fun speedMetersPerSecond(): Double = MIN_SPEED + power * (MAX_SPEED - MIN_SPEED)

    companion object {
        const val MIN_SPEED = 0.2
        const val MAX_SPEED = 6.0
    }
}

/** Immutable view of the assistant for the UI. */
data class AssistantSnapshot(
    val runState: RunState,
    val captureState: CaptureState,
    val captureError: String?,
    val ownGameAcknowledged: Boolean,
    val aim: AimSettings,
    val detection: DetectionView,
    val prediction: PredictionView,
    val framesAnalysed: Long,
    val analysing: Boolean,
    val message: String?,
    val latestResult: AnalysisResult? = null,
    val latestShot: ShotResult? = null,
    /** Who set [aim]: the user, or automatic detection. */
    val aimSource: AimSource = AimSource.AUTO_DETECTION,
    /** True when the latest analysed frame contains a detected aim that the user could follow. */
    val autoAimAvailable: Boolean = false,
)

/**
 * Single source of truth for the assistant session: run state, capture consent, frame gating, latest
 * detections and the current prediction. Pure Kotlin. The Android layer forwards events here and
 * publishes [snapshot] to the UI.
 *
 * Rules enforced here:
 * - Capture requires the Mode A acknowledgement and an explicit consent result.
 * - Analysis requires an active capture.
 * - At most one frame is analysed at a time, and frames are throttled.
 * - Results from frames that finish after pause or stop are discarded.
 * - A rejected frame clears the previous detections and prediction.
 * - A prediction is shown only while its source frame is still the latest analysed frame.
 */
class AssistantSession(
    private val coordinator: FrameAnalysisCoordinator = FrameAnalysisCoordinator(),
    private val table: TableGeometry3D = TableGeometry3D.from(TableSpec.NINE_FOOT),
    private val minFrameIntervalMs: Long = DEFAULT_FRAME_INTERVAL_MS,
) {
    private var runState = RunState.STOPPED
    private var captureState: CaptureState = CaptureState.Idle
    private var captureError: String? = null
    private var message: String? = null
    private var acknowledged = false
    private var aimState = AimState()
    private var nextFrameId = 1L
    private var analysing = false
    private var lastStartMs: Long? = null
    private var framesAnalysed = 0L
    private var latest: FrameOutcome? = null
    private var prediction: PredictionTicket? = null
    private var detection: DetectionView = AssistantPresenter.detection(null)

    @Synchronized
    fun setAcknowledged(value: Boolean) {
        acknowledged = value
    }

    @Synchronized
    fun isAwaitingConsent(): Boolean = captureState is CaptureState.AwaitingConsent

    /** Null when a consent request was started; otherwise the reason it was refused. */
    @Synchronized
    fun requestCapture(): String? {
        val step = CaptureStateMachine.reduce(
            captureState,
            CaptureEvent.RequestCapture(GameMode.OWN_GAME_AUTHORIZED, Authorization(acknowledged)),
        )
        captureState = step.state
        captureError = step.error
        return if (captureState is CaptureState.AwaitingConsent) null else step.error
    }

    /** The user answered the system consent dialog. Returns a message if the answer was not accepted. */
    @Synchronized
    fun onConsentResult(granted: Boolean): String? {
        val step = CaptureStateMachine.reduce(
            captureState,
            if (granted) CaptureEvent.ConsentGranted else CaptureEvent.ConsentDenied,
        )
        captureState = step.state
        captureError = step.error
        if (granted) {
            applyRun(RunEvent.Start)
        }
        return step.error
    }

    /** Capture ended for a reason outside the user's stop action: system stop, revoked permission, or failure. */
    @Synchronized
    fun onCaptureEnded(reason: String) {
        captureState = CaptureState.Stopped(StopReason.PROJECTION_ENDED)
        captureError = reason
        applyRun(RunEvent.CaptureEnded)
    }

    @Synchronized
    fun onCaptureFailed(reason: String) = onCaptureEnded(reason)

    /** The capture service was destroyed. Only changes state if capture was still running. */
    @Synchronized
    fun onServiceDestroyed() {
        if (captureState is CaptureState.Capturing) {
            onCaptureEnded("Screen capture service stopped.")
        }
    }

    /** The user pressed Stop capture. */
    @Synchronized
    fun stopCapture() {
        captureState = CaptureStateMachine.reduce(captureState, CaptureEvent.Stop).state
        captureError = null
        applyRun(RunEvent.CaptureEnded)
    }

    @Synchronized
    fun startAnalysis() = applyRun(RunEvent.Start)

    @Synchronized
    fun pauseAnalysis() = applyRun(RunEvent.Pause)

    @Synchronized
    fun resumeAnalysis() = applyRun(RunEvent.Resume)

    @Synchronized
    fun stopAnalysis() = applyRun(RunEvent.Stop)

    /**
     * Reserves the right to analyse one frame. Returns the frame id, or null when the frame should be
     * dropped. Every non-null result must be followed by [analyseFrame] or [abandonFrame].
     */
    @Synchronized
    fun beginFrame(nowMs: Long): Long? {
        if (!AssistantRunMachine.mayProcessFrame(runState, analysing)) return null
        val last = lastStartMs
        if (last != null && nowMs - last < minFrameIntervalMs) return null
        analysing = true
        lastStartMs = nowMs
        return nextFrameId++
    }

    /** Releases a reserved frame without analysing it (for example, when conversion failed). */
    @Synchronized
    fun abandonFrame(reason: String) {
        analysing = false
        message = reason
    }

    /** Runs analysis for a reserved frame. Call outside the session lock; the analysis can take time. */
    fun analyseFrame(frameId: Long, frame: RawFrame?): FrameOutcome {
        val runAtStart = synchronized(this) { runState }
        val outcome = try {
            coordinator.submit(frameId, runAtStart, frame)
        } finally {
            synchronized(this) { analysing = false }
        }
        return synchronized(this) { storeOutcome(outcome) }
    }

    /** Sets the aim chosen by the user. From now on automatic detection does not overwrite it. */
    @Synchronized
    fun setAim(settings: AimSettings) {
        aimState = AimSourceMachine.reduce(aimState, AimEvent.UserSet(settings))
        recomputePredictionLocked()
    }

    /**
     * Hands the aim back to automatic detection. A target found in the latest analysed frame is applied at
     * once; otherwise the current aim stays until the next detection replaces it.
     */
    @Synchronized
    fun resumeAutoAim() {
        aimState = AimSourceMachine.reduce(aimState, AimEvent.ResumeAuto(detectedAimLocked()))
        recomputePredictionLocked()
    }

    /** Target (u, v) of the aim detected in the latest analysed frame, or null. */
    private fun detectedAimLocked(): Pair<Double, Double>? {
        val estimate = (latest as? FrameOutcome.Analysed)?.result?.aimEstimate ?: return null
        val u = estimate.targetU
        val v = estimate.targetV
        if (!estimate.detected || u == null || v == null) return null
        if (!(u in 0.0..1.0 && v in 0.0..1.0)) return null
        return u to v
    }

    @Synchronized
    fun snapshot(): AssistantSnapshot {
        val currentAnalysed = latest as? FrameOutcome.Analysed
        return AssistantSnapshot(
            runState = runState,
            captureState = captureState,
            captureError = captureError,
            ownGameAcknowledged = acknowledged,
            aim = aimState.aim ?: AimSettings(),
            detection = detection,
            prediction = predictionViewLocked(),
            framesAnalysed = framesAnalysed,
            analysing = analysing,
            message = message,
            latestResult = currentAnalysed?.result,
            latestShot = prediction?.shot,
            aimSource = aimState.source,
            autoAimAvailable = detectedAimLocked() != null,
        )
    }

    /** Test hook: stores an outcome as if [analyseFrame] had produced it, so tests can feed exact detections. */
    @Synchronized
    internal fun storeOutcomeForTest(outcome: FrameOutcome): FrameOutcome = storeOutcome(outcome)

    private fun applyRun(event: RunEvent) {
        val step = AssistantRunMachine.reduce(runState, event, captureState is CaptureState.Capturing)
        runState = step.state
        message = step.message
    }

    private fun storeOutcome(outcome: FrameOutcome): FrameOutcome {
        when (outcome) {
            is FrameOutcome.Analysed -> if (runState == RunState.RUNNING) {
                latest = outcome
                framesAnalysed++
                detection = AssistantPresenter.detection(outcome.result)
                message = null
                // The machine ignores a detection while the user's aim is in place.
                detectedAimLocked()?.let { aimState = AimSourceMachine.reduce(aimState, AimEvent.Detected(it.first, it.second)) }
                recomputePredictionLocked()
            } else {
                // Paused or stopped while this frame was analysing: discard it, and drop any prediction from it.
                coordinator.invalidate()
                latest = null
                prediction = null
                detection = AssistantPresenter.detection(null)
            }
            is FrameOutcome.Rejected -> {
                latest = outcome
                prediction = null
                detection = AssistantPresenter.detection(null)
                message = outcome.reason
            }
            is FrameOutcome.Skipped -> message = outcome.reason
        }
        return outcome
    }

    private fun recomputePredictionLocked() {
        val current = latest as? FrameOutcome.Analysed
        val cue = current?.physics?.balls?.firstOrNull { it.isCue }
        val currentAim = aimState.aim
        if (current == null || cue == null || currentAim == null) {
            prediction = null
            return
        }
        val target = Vec3(currentAim.targetU * table.length, currentAim.targetV * table.width, cue.position.z)
        val direction = Vec3(target.x - cue.position.x, target.y - cue.position.y, 0.0)
        prediction = coordinator.predict(direction, currentAim.speedMetersPerSecond(), 0.0, 0.0, 0.0)
    }

    private fun predictionViewLocked(): PredictionView {
        val ticket = prediction
            ?: return AssistantPresenter.prediction((latest as? FrameOutcome.Analysed)?.physics, null)
        return if (coordinator.isCurrent(ticket)) {
            ticket.view
        } else {
            PredictionView(false, "Waiting for the next analysed frame.", PredictionConfidence.NONE, emptyList())
        }
    }

    companion object {
        const val DEFAULT_FRAME_INTERVAL_MS = 400L
    }
}
