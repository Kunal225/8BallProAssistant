package com.eightballpro.assistant.domain.settings

import com.eightballpro.assistant.domain.physics.PhysicsConfig

data class AppSettings(
    val physics: PhysicsConfig = PhysicsConfig.DEFAULT,
    val showGuideLines: Boolean = true,
    val keepScreenOn: Boolean = false,
)
