package com.eightballpro.assistant.domain.vision

import kotlin.math.PI
import kotlin.math.sqrt

enum class BallClass { CUE, OBJECT, BLACK, UNCERTAIN }

/** A connected non-felt region inside the table, with its geometry and mean colour. */
data class RawBlob(
    val centreX: Double,
    val centreY: Double,
    val radiusPx: Double,
    val area: Int,
    val fillRatio: Double,
    val boxWidth: Int,
    val boxHeight: Int,
    val meanR: Int,
    val meanG: Int,
    val meanB: Int,
)

data class BallDetectorConfig(val insetPx: Int = 2, val minArea: Int = 20)

object BallDetector {

    private val DX = intArrayOf(1, -1, 0, 0)
    private val DY = intArrayOf(0, 0, 1, -1)

    /**
     * Connected components of non-felt pixels inside the table, shrunk by [BallDetectorConfig.insetPx]
     * so the rails are excluded. Balls, shadows and highlights all appear here, so the classifier and
     * confidence score decide what each blob is.
     */
    fun detect(
        image: ArgbImage,
        bounds: TableBounds,
        felt: ColorProfile,
        config: BallDetectorConfig = BallDetectorConfig(),
    ): List<RawBlob> {
        val w = image.width
        val x0 = bounds.left + config.insetPx
        val y0 = bounds.top + config.insetPx
        val x1 = bounds.right - config.insetPx
        val y1 = bounds.bottom - config.insetPx
        if (x1 <= x0 || y1 <= y0) return emptyList()

        val mask = BooleanArray(w * image.height)
        for (y in y0..y1) {
            for (x in x0..x1) {
                mask[y * w + x] = !felt.matches(image.pixels[y * w + x])
            }
        }

        val visited = BooleanArray(mask.size)
        val blobs = mutableListOf<RawBlob>()
        for (y in y0..y1) {
            for (x in x0..x1) {
                val start = y * w + x
                if (!mask[start] || visited[start]) continue
                val blob = floodFill(image, mask, visited, start, x0, y0, x1, y1, config.minArea)
                if (blob != null) blobs += blob
            }
        }
        return blobs
    }

    private fun floodFill(
        image: ArgbImage,
        mask: BooleanArray,
        visited: BooleanArray,
        start: Int,
        x0: Int, y0: Int, x1: Int, y1: Int,
        minArea: Int,
    ): RawBlob? {
        val w = image.width
        val queue = ArrayDeque<Int>()
        queue.add(start)
        visited[start] = true
        var n = 0
        var sumX = 0L
        var sumY = 0L
        var minX = Int.MAX_VALUE
        var maxX = Int.MIN_VALUE
        var minY = Int.MAX_VALUE
        var maxY = Int.MIN_VALUE
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        while (queue.isNotEmpty()) {
            val i = queue.removeLast()
            val cx = i % w
            val cy = i / w
            n++
            sumX += cx
            sumY += cy
            minX = minOf(minX, cx); maxX = maxOf(maxX, cx)
            minY = minOf(minY, cy); maxY = maxOf(maxY, cy)
            val p = image.pixels[i]
            sumR += (p shr 16) and 0xFF
            sumG += (p shr 8) and 0xFF
            sumB += p and 0xFF
            for (k in 0 until 4) {
                val nx = cx + DX[k]
                val ny = cy + DY[k]
                if (nx < x0 || nx > x1 || ny < y0 || ny > y1) continue
                val j = ny * w + nx
                if (mask[j] && !visited[j]) {
                    visited[j] = true
                    queue.add(j)
                }
            }
        }
        if (n < minArea) return null
        val boxW = maxX - minX + 1
        val boxH = maxY - minY + 1
        return RawBlob(
            centreX = sumX.toDouble() / n,
            centreY = sumY.toDouble() / n,
            radiusPx = sqrt(n / PI),
            area = n,
            fillRatio = n.toDouble() / (boxW * boxH),
            boxWidth = boxW,
            boxHeight = boxH,
            meanR = (sumR / n).toInt(),
            meanG = (sumG / n).toInt(),
            meanB = (sumB / n).toInt(),
        )
    }
}

/** Colour-based classification. Returns UNCERTAIN when the colour is ambiguous (for example, a striped ball). */
data class ClassifiedBall(val cls: BallClass, val confidence: Double)

object BallClassifier {

    fun classify(blob: RawBlob): ClassifiedBall {
        val max = maxOf(blob.meanR, maxOf(blob.meanG, blob.meanB))
        val min = minOf(blob.meanR, minOf(blob.meanG, blob.meanB))
        val spread = max - min
        val meanBrightness = (blob.meanR + blob.meanG + blob.meanB) / 3.0

        return when {
            max < 75 -> ClassifiedBall(BallClass.BLACK, 0.9)
            min >= 150 && spread <= 55 && meanBrightness >= 160 -> {
                val whitenessPurity = (meanBrightness / 255.0).coerceIn(0.6, 1.0) * (1.0 - (spread / 120.0).coerceAtMost(0.4))
                ClassifiedBall(BallClass.CUE, whitenessPurity)
            }
            spread >= 40 -> ClassifiedBall(BallClass.OBJECT, (spread / 120.0).coerceAtMost(1.0))
            else -> ClassifiedBall(BallClass.UNCERTAIN, 0.3)
        }
    }
}
