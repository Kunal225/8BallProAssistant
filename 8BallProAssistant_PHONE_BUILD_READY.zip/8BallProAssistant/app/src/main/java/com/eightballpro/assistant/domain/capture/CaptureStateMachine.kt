package com.eightballpro.assistant.domain.capture

import com.eightballpro.assistant.domain.mode.Authorization
import com.eightballpro.assistant.domain.mode.GameMode
import com.eightballpro.assistant.domain.mode.ModePolicy
import com.eightballpro.assistant.domain.mode.PolicyDecision

enum class StopReason { USER_REQUESTED, PROJECTION_ENDED }

sealed interface CaptureState {
    data object Idle : CaptureState
    data class AwaitingConsent(val mode: GameMode) : CaptureState
    data class Capturing(val mode: GameMode, val rotations: Int) : CaptureState
    data class Stopped(val reason: StopReason) : CaptureState
    data class Denied(val attempts: Int) : CaptureState
}

sealed interface CaptureEvent {
    data class RequestCapture(val mode: GameMode, val authorization: Authorization) : CaptureEvent
    data object ConsentGranted : CaptureEvent
    data object ConsentDenied : CaptureEvent
    data object Stop : CaptureEvent
    data object ProjectionEnded : CaptureEvent
    data object Rotated : CaptureEvent
}

data class CaptureStep(val state: CaptureState, val error: String?)

/**
 * Pure state machine for screen capture. The invariant: the Capturing state can only be reached
 * from AwaitingConsent through ConsentGranted, and AwaitingConsent can only be reached through a
 * RequestCapture that passes the mode policy. Any other event leaves the state unchanged and reports an error.
 */
object CaptureStateMachine {

    fun reduce(state: CaptureState, event: CaptureEvent): CaptureStep = when (event) {
        is CaptureEvent.RequestCapture -> request(state, event)

        CaptureEvent.ConsentGranted -> if (state is CaptureState.AwaitingConsent) {
            CaptureStep(CaptureState.Capturing(state.mode, rotations = 0), null)
        } else {
            refused(state, "No consent request is pending, so capture was not started.")
        }

        CaptureEvent.ConsentDenied -> if (state is CaptureState.AwaitingConsent) {
            CaptureStep(CaptureState.Denied(attempts = 1), "Screen capture permission was denied.")
        } else {
            refused(state, "No consent request is pending.")
        }

        CaptureEvent.Stop -> when (state) {
            is CaptureState.Capturing, is CaptureState.AwaitingConsent ->
                CaptureStep(CaptureState.Stopped(StopReason.USER_REQUESTED), null)
            else -> CaptureStep(state, null)
        }

        CaptureEvent.ProjectionEnded -> if (state is CaptureState.Capturing) {
            CaptureStep(CaptureState.Stopped(StopReason.PROJECTION_ENDED), "Screen capture ended by the system.")
        } else {
            CaptureStep(state, null)
        }

        CaptureEvent.Rotated -> if (state is CaptureState.Capturing) {
            CaptureStep(state.copy(rotations = state.rotations + 1), null)
        } else {
            CaptureStep(state, null)
        }
    }

    private fun request(state: CaptureState, event: CaptureEvent.RequestCapture): CaptureStep {
        if (state is CaptureState.Capturing || state is CaptureState.AwaitingConsent) {
            return refused(state, "Capture is already running or waiting for permission.")
        }
        return when (val decision = ModePolicy.decideLiveCapture(event.mode, event.authorization)) {
            PolicyDecision.Allowed -> CaptureStep(CaptureState.AwaitingConsent(event.mode), null)
            is PolicyDecision.Denied -> CaptureStep(state, decision.reason)
        }
    }

    private fun refused(state: CaptureState, message: String) = CaptureStep(state, message)
}
