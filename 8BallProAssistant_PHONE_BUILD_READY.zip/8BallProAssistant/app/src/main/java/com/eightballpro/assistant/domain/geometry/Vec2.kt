package com.eightballpro.assistant.domain.geometry

import kotlin.math.sqrt

/** Immutable 2D vector in the table's coordinate system (millimetres unless stated). */
data class Vec2(val x: Double, val y: Double) {

    operator fun plus(other: Vec2) = Vec2(x + other.x, y + other.y)
    operator fun minus(other: Vec2) = Vec2(x - other.x, y - other.y)
    operator fun times(scalar: Double) = Vec2(x * scalar, y * scalar)
    operator fun unaryMinus() = Vec2(-x, -y)

    infix fun dot(other: Vec2): Double = x * other.x + y * other.y

    fun lengthSquared(): Double = x * x + y * y

    fun length(): Double = sqrt(lengthSquared())

    fun distanceTo(other: Vec2): Double = (this - other).length()

    /** Unit vector in the same direction, or [ZERO] when this vector has no length. */
    fun normalizedOrZero(): Vec2 {
        val len = length()
        return if (len == 0.0) ZERO else this * (1.0 / len)
    }

    /** Vector rotated 90 degrees counter-clockwise in the mathematical sense. */
    fun perpendicular(): Vec2 = Vec2(-y, x)

    companion object {
        val ZERO = Vec2(0.0, 0.0)
    }
}
