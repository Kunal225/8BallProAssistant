@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.spin

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.CueStrike
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.spin.SpinContactPoint
import com.eightballpro.assistant.ui.common.ScreenScaffold

@Composable
fun SpinControlScreen(onBack: () -> Unit) {
    var selectedPoint by remember { mutableStateOf(SpinContactPoint.CENTER) }
    var intensity by remember { mutableDoubleStateOf(0.5) }
    var speed by remember { mutableDoubleStateOf(2.5) }
    var elevationDeg by remember { mutableDoubleStateOf(0.0) }

    val cueBall = PoolBall(0, Vec3(1.0, 0.6, BallPhysics.RADIUS_M))
    val offset = selectedPoint.normalizedOffset()
    val sideNorm = offset.x * intensity
    val heightNorm = offset.y * intensity
    val strike = CueStrike.apply(
        ball = cueBall,
        direction = Vec3(1.0, 0.0, 0.0),
        speed = speed,
        sideOffset = sideNorm,
        heightOffset = heightNorm,
        elevationRad = Math.toRadians(elevationDeg),
    )

    ScreenScaffold(title = "Spin Control & Dynamics", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    text = "Interactive Cue-Ball Contact Point & English Dynamics",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            item {
                CueBallContactSelector(
                    selectedPoint = selectedPoint,
                    intensity = intensity,
                    onSelectPoint = { selectedPoint = it },
                )
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Spin Parameters", style = MaterialTheme.typography.titleMedium)

                        Text("Spin Intensity: %.2f".format(intensity), style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = intensity.toFloat(),
                            onValueChange = { intensity = it.toDouble() },
                            valueRange = 0f..1f,
                        )

                        Text("Cue Speed: %.2f m/s".format(speed), style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = speed.toFloat(),
                            onValueChange = { speed = it.toDouble() },
                            valueRange = 0.5f..6.0f,
                        )

                        Text("Elevation: %.1f°".format(elevationDeg), style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = elevationDeg.toFloat(),
                            onValueChange = { elevationDeg = it.toDouble() },
                            valueRange = -15f..15f,
                        )
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Resulting Dynamics Output", style = MaterialTheme.typography.titleMedium)
                        Text("Linear Velocity: (%.2f, %.2f, %.2f) m/s".format(strike.velocity.x, strike.velocity.y, strike.velocity.z), style = MaterialTheme.typography.bodyMedium)
                        Text("Angular Velocity: (%.2f, %.2f, %.2f) rad/s".format(strike.angularVelocity.x, strike.angularVelocity.y, strike.angularVelocity.z), style = MaterialTheme.typography.bodyMedium)
                        Text("Side Offset: %.2f mm".format(sideNorm * BallPhysics.RADIUS_M * 1000.0), style = MaterialTheme.typography.bodySmall)
                        Text("Height Offset: %.2f mm".format(heightNorm * BallPhysics.RADIUS_M * 1000.0), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun CueBallContactSelector(
    selectedPoint: SpinContactPoint,
    intensity: Double,
    onSelectPoint: (SpinContactPoint) -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1.4f)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(180.dp)
                .clip(CircleShape)
                .background(Color.White)
                .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f
                drawLine(Color.LightGray, Offset(0f, center.y), Offset(size.width, center.y), strokeWidth = 1f)
                drawLine(Color.LightGray, Offset(center.x, 0f), Offset(center.x, size.height), strokeWidth = 1f)

                val offset = selectedPoint.normalizedOffset()
                val targetX = center.x + (offset.x * intensity * radius * 0.8).toFloat()
                val targetY = center.y - (offset.y * intensity * radius * 0.8).toFloat()
                drawCircle(Color.Red, radius = 8f, center = Offset(targetX, targetY))
            }
        }
    }
}
