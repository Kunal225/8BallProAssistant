package com.eightballpro.assistant.domain.physics3d

import kotlin.math.sqrt

/** Immutable 3D vector. Positions in metres, velocities in metres per second. */
data class Vec3(val x: Double, val y: Double, val z: Double) {

    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Double) = Vec3(x * s, y * s, z * s)
    operator fun unaryMinus() = Vec3(-x, -y, -z)

    fun dot(o: Vec3): Double = x * o.x + y * o.y + z * o.z

    fun cross(o: Vec3): Vec3 = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)

    fun length(): Double = sqrt(dot(this))

    fun distanceTo(o: Vec3): Double = (this - o).length()

    /** Same vector with z set to zero. */
    fun horizontal(): Vec3 = Vec3(x, y, 0.0)

    /** Unit vector in the same direction, or [ZERO] when the length is zero. */
    fun normalizedOrZero(): Vec3 {
        val len = length()
        return if (len == 0.0) ZERO else this * (1.0 / len)
    }

    companion object {
        val ZERO = Vec3(0.0, 0.0, 0.0)
        val UP = Vec3(0.0, 0.0, 1.0)
    }
}
