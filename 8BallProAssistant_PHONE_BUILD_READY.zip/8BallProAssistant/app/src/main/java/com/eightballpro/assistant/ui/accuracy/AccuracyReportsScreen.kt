@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.accuracy

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.eightballpro.assistant.data.accuracy.AccuracyRepository
import com.eightballpro.assistant.data.accuracy.ShotAccuracyRecord
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.ui.common.ScreenScaffold

@Composable
fun AccuracyReportsScreen(onBack: () -> Unit) {
    val history by AccuracyRepository.history.collectAsStateWithLifecycle()
    val summary = AccuracyRepository.getSummary()

    fun addSampleShot() {
        AccuracyRepository.addRecord(
            ShotAccuracyRecord(
                timestampMs = System.currentTimeMillis(),
                predictedCuePos = Vec3(1.2, 0.6, 0.0285),
                actualCuePos = Vec3(1.208, 0.603, 0.0285),
                predictedObjectPocketed = true,
                actualObjectPocketed = true,
                confidenceLevel = "HIGH",
            )
        )
    }

    ScreenScaffold(title = "Accuracy & Verification Reports", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    text = "Measured Shot Prediction Accuracy Metrics",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Accuracy Summary", style = MaterialTheme.typography.titleMedium)
                        Text("Total Measured Shots: ${summary.totalShots}", style = MaterialTheme.typography.bodyMedium)
                        Text("Average Cue Stopping Error: %.1f mm".format(summary.avgErrorMm), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        Text("Pocket Prediction Accuracy: %.1f%%".format(summary.pocketAccuracyPct), style = MaterialTheme.typography.bodyMedium)
                        Text("Calibration Quality Score: %.2f / 1.00".format(summary.calibrationQualityScore), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { addSampleShot() }, modifier = Modifier.weight(1f)) {
                        Text("Record Measured Shot")
                    }
                    OutlinedButton(onClick = { AccuracyRepository.clearHistory() }, modifier = Modifier.weight(1f)) {
                        Text("Clear History")
                    }
                }
            }
            item {
                Text("Shot History (${history.size})", style = MaterialTheme.typography.titleMedium)
            }
            items(history) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Cue Pos Error: %.1f mm".format(record.positionErrorMm), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                            Text("Confidence: ${record.confidenceLevel}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            "Predicted Pocket: ${if (record.predictedObjectPocketed) "YES" else "NO"} | Actual: ${if (record.actualObjectPocketed) "YES" else "NO"}",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}
