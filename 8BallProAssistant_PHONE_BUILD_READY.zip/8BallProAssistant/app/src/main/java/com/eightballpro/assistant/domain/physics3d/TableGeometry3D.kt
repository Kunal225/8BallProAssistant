package com.eightballpro.assistant.domain.physics3d

import com.eightballpro.assistant.domain.table.PocketPosition
import com.eightballpro.assistant.domain.table.TableSpec
import kotlin.math.sqrt

/** Nominal playing length of the 9-foot table in metres, used for normalisation and ratios. */
const val TABLE_LENGTH_M_NINE_FOOT = 2.54

private val CORNER_POCKETS = setOf(
    PocketPosition.TOP_LEFT,
    PocketPosition.TOP_RIGHT,
    PocketPosition.BOTTOM_LEFT,
    PocketPosition.BOTTOM_RIGHT,
)

/**
 * A pocket as a circular capture zone on the cloth. A ball whose centre enters the zone is pocketed.
 * This is a simplified pocket model: it does not model jaws, pocket depth or rail rebound inside the mouth.
 */
data class Pocket(
    val name: PocketPosition,
    val x: Double,
    val y: Double,
    val captureRadius: Double,
) {
    val isCorner: Boolean get() = name in CORNER_POCKETS

    fun captures(p: Vec3): Boolean = distanceToXY(p) < captureRadius

    fun distanceTo(p: Vec3): Double = distanceToXY(p)

    private fun distanceToXY(p: Vec3): Double {
        val dx = p.x - x
        val dy = p.y - y
        return sqrt(dx * dx + dy * dy)
    }
}

/**
 * A rail as a plane. [inwardNormal] points into the playing area. A ball centre is allowed where
 * dot(position, inwardNormal) >= limit. [crossing] is positive when the centre has passed the rail line.
 */
data class Cushion(val inwardNormal: Vec3, val limit: Double) {
    fun crossing(p: Vec3): Double = limit - p.dot(inwardNormal)
}

/** Table geometry in metres. Origin is the top-left corner of the playing surface. */
class TableGeometry3D private constructor(
    val length: Double,
    val width: Double,
    val pockets: List<Pocket>,
    val cushions: List<Cushion>,
) {
    /** True when a ball centre at [p] is inside the rails. */
    fun isInsidePlayArea(p: Vec3): Boolean = cushions.all { it.crossing(p) <= 0.0 }

    fun capturingPocket(p: Vec3): Pocket? = pockets.firstOrNull { it.captures(p) }

    companion object {
        const val CORNER_CAPTURE_M = 0.06
        const val SIDE_CAPTURE_M = 0.065

        fun from(spec: TableSpec): TableGeometry3D {
            val length = spec.playingLengthMm / 1000.0
            val width = spec.playingWidthMm / 1000.0
            val r = BallPhysics.RADIUS_M
            val pockets = spec.pocketCenters().map { (name, c) ->
                val isCorner = name in CORNER_POCKETS
                Pocket(
                    name = name,
                    x = c.x / 1000.0,
                    y = c.y / 1000.0,
                    captureRadius = if (isCorner) CORNER_CAPTURE_M else SIDE_CAPTURE_M,
                )
            }
            val cushions = listOf(
                Cushion(Vec3(1.0, 0.0, 0.0), r),
                Cushion(Vec3(-1.0, 0.0, 0.0), -(length - r)),
                Cushion(Vec3(0.0, 1.0, 0.0), r),
                Cushion(Vec3(0.0, -1.0, 0.0), -(width - r)),
            )
            return TableGeometry3D(length, width, pockets, cushions)
        }
    }
}
