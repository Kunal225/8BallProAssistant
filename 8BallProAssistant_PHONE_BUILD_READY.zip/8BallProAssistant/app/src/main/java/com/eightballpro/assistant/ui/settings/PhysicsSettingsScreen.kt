@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.ui.common.ScreenScaffold

@Composable
fun PhysicsSettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = viewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val cfg = settings.physics

    val parameters = listOf(
        Parameter(
            label = "Sliding friction",
            value = cfg.slidingFriction,
            range = PhysicsConfig.SLIDING_FRICTION_RANGE,
            onChange = { v -> viewModel.updatePhysics { it.copy(slidingFriction = v) } },
        ),
        Parameter(
            label = "Rolling friction",
            value = cfg.rollingFriction,
            range = PhysicsConfig.ROLLING_FRICTION_RANGE,
            onChange = { v -> viewModel.updatePhysics { it.copy(rollingFriction = v) } },
        ),
        Parameter(
            label = "Cushion restitution",
            value = cfg.cushionRestitution,
            range = PhysicsConfig.CUSHION_RESTITUTION_RANGE,
            onChange = { v -> viewModel.updatePhysics { it.copy(cushionRestitution = v) } },
        ),
        Parameter(
            label = "Ball restitution",
            value = cfg.ballRestitution,
            range = PhysicsConfig.BALL_RESTITUTION_RANGE,
            onChange = { v -> viewModel.updatePhysics { it.copy(ballRestitution = v) } },
        ),
        Parameter(
            label = "Ball-to-ball friction",
            value = cfg.ballFriction,
            range = PhysicsConfig.BALL_FRICTION_RANGE,
            onChange = { v -> viewModel.updatePhysics { it.copy(ballFriction = v) } },
        ),
        Parameter(
            label = "Cloth restitution (vertical bounce)",
            value = cfg.clothRestitution,
            range = PhysicsConfig.CLOTH_RESTITUTION_RANGE,
            onChange = { v -> viewModel.updatePhysics { it.copy(clothRestitution = v) } },
        ),
    )

    ScreenScaffold(title = "Physics Settings", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    "These values drive the 3D physics engine used by the Pool Table Simulator. Changes apply to the next shot.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            items(parameters, key = { it.label }) { parameter ->
                ParameterSlider(parameter)
            }
            item {
                OutlinedButton(onClick = { viewModel.updatePhysics { PhysicsConfig.DEFAULT } }) {
                    Text("Restore defaults")
                }
            }
        }
    }
}

private data class Parameter(
    val label: String,
    val value: Double,
    val range: ClosedFloatingPointRange<Double>,
    val onChange: (Double) -> Unit,
)

@Composable
private fun ParameterSlider(parameter: Parameter) {
    // While the thumb is dragged it follows the finger from local state. The value is saved once, when the drag
    // ends. Binding the thumb to the saved value made it lag behind the finger and jump back to older values while
    // earlier writes were still being stored, and it wrote to disk on every drag event.
    var dragValue by remember { mutableStateOf<Float?>(null) }
    // The saved value has arrived (or was reset, for example by restoring the defaults): show it again.
    LaunchedEffect(parameter.value) { dragValue = null }
    val shown = dragValue ?: parameter.value.toFloat()

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(parameter.label, style = MaterialTheme.typography.bodyLarge)
            Text(
                "%.3f".format(shown.toDouble()),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.tertiary,
            )
        }
        Slider(
            value = shown,
            onValueChange = { dragValue = it },
            onValueChangeFinished = { dragValue?.let { parameter.onChange(it.toDouble()) } },
            valueRange = parameter.range.start.toFloat()..parameter.range.endInclusive.toFloat(),
        )
    }
}
