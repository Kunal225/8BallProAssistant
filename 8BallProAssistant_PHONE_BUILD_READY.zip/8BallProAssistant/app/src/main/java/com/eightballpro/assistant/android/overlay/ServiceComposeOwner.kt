package com.eightballpro.assistant.android.overlay

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner

/**
 * Lifecycle, saved-state and view-model owner for a ComposeView hosted in a Service. Services are not
 * activities, so Compose needs these owners supplied by hand.
 */
class ServiceComposeOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val registry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    private var destroyed = false

    init {
        savedStateController.performAttach()
    }

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    fun onCreate() {
        if (registry.currentState == Lifecycle.State.INITIALIZED) {
            savedStateController.performRestore(null)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }
        destroyed = false
    }

    /** Walks the lifecycle down from its current state, so it is safe to call after a failed start. */
    fun onDestroy() {
        if (destroyed) return
        destroyed = true
        while (true) {
            when (registry.currentState) {
                Lifecycle.State.RESUMED -> registry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
                Lifecycle.State.STARTED -> registry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
                Lifecycle.State.CREATED -> registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
                else -> break
            }
        }
        store.clear()
    }
}
