@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.distance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.ui.common.ScreenScaffold
import kotlin.math.sqrt

@Composable
fun DistancePredictorScreen(onBack: () -> Unit) {
    var strikeSpeed by remember { mutableDoubleStateOf(3.0) }
    var slidingFriction by remember { mutableDoubleStateOf(PhysicsConfig.DEFAULT.slidingFriction) }
    var rollingFriction by remember { mutableDoubleStateOf(PhysicsConfig.DEFAULT.rollingFriction) }

    // Distance calculation based on sliding to rolling transition
    val g = 9.81
    val v0 = strikeSpeed
    // Sliding distance = (2 * v0^2) / (49 * mu_s * g)
    val slidingDist = (2.0 * v0 * v0) / (49.0 * slidingFriction * g)
    val vRoll = (5.0 / 7.0) * v0
    val rollingDist = (vRoll * vRoll) / (2.0 * rollingFriction * g)
    val totalDist = slidingDist + rollingDist
    val travelTime = (2.0 * v0) / (7.0 * slidingFriction * g) + vRoll / (rollingFriction * g)

    ScreenScaffold(title = "Distance Predictor", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    text = "Cue-Ball Travel Distance & Stopping Model",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Input Parameters", style = MaterialTheme.typography.titleMedium)

                        Text("Strike Speed: %.2f m/s".format(strikeSpeed), style = MaterialTheme.typography.bodyMedium)
                        Slider(value = strikeSpeed.toFloat(), onValueChange = { strikeSpeed = it.toDouble() }, valueRange = 0.5f..6.0f)

                        Text("Sliding Friction (µs): %.3f".format(slidingFriction), style = MaterialTheme.typography.bodyMedium)
                        Slider(value = slidingFriction.toFloat(), onValueChange = { slidingFriction = it.toDouble() }, valueRange = 0.1f..0.4f)

                        Text("Rolling Friction (µr): %.4f".format(rollingFriction), style = MaterialTheme.typography.bodyMedium)
                        Slider(value = rollingFriction.toFloat(), onValueChange = { rollingFriction = it.toDouble() }, valueRange = 0.005f..0.03f)
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Predicted Motion Breakdown", style = MaterialTheme.typography.titleMedium)
                        Text("Total Unobstructed Travel: %.2f m".format(totalDist), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text("Sliding Phase Distance: %.2f m".format(slidingDist), style = MaterialTheme.typography.bodyMedium)
                        Text("Rolling Phase Distance: %.2f m".format(rollingDist), style = MaterialTheme.typography.bodyMedium)
                        Text("Roll Transition Velocity: %.2f m/s".format(vRoll), style = MaterialTheme.typography.bodyMedium)
                        Text("Estimated Duration: %.2f seconds".format(travelTime), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
