@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.assistant

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.eightballpro.assistant.android.overlay.OverlayService
import com.eightballpro.assistant.android.permissions.AssistantPermissions
import com.eightballpro.assistant.ui.common.ScreenScaffold
import kotlinx.coroutines.delay

/** Settings-style screen that starts and stops the floating assistant and shows its permission status. */
@Composable
fun AssistantControlScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var overlayGranted by remember { mutableStateOf(AssistantPermissions.canDrawOverlays(context)) }
    var notificationsGranted by remember { mutableStateOf(AssistantPermissions.notificationsGranted(context)) }
    var overlayRunning by remember { mutableStateOf(OverlayService.isRunning) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                overlayGranted = AssistantPermissions.canDrawOverlays(context)
                notificationsGranted = AssistantPermissions.notificationsGranted(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // The service starts asynchronously, so poll its running flag while this screen is visible.
    LaunchedEffect(Unit) {
        while (true) {
            overlayRunning = OverlayService.isRunning
            delay(500)
        }
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> notificationsGranted = granted }

    ScreenScaffold(title = "Floating Assistant", onBack = onBack) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Permissions", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Draw over other apps: ${if (overlayGranted) "allowed" else "not allowed"}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text(
                        "Notifications: ${if (notificationsGranted) "allowed" else "not allowed"}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text(
                        "Screen capture needs your approval each time you start it. The app never records the screen without it.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (!overlayGranted) {
                        Button(onClick = { context.startActivity(AssistantPermissions.overlaySettingsIntent(context)) }) {
                            Text("Allow drawing over other apps")
                        }
                    }
                    if (!notificationsGranted && android.os.Build.VERSION.SDK_INT >= 33) {
                        Button(onClick = { notificationLauncher.launch(AssistantPermissions.NOTIFICATION_PERMISSION) }) {
                            Text("Allow notifications")
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { OverlayService.start(context) },
                    enabled = overlayGranted && !overlayRunning,
                    modifier = Modifier.weight(1f),
                ) { Text("Show floating assistant") }
                OutlinedButton(
                    onClick = { OverlayService.stop(context) },
                    enabled = overlayRunning,
                    modifier = Modifier.weight(1f),
                ) { Text("Close floating assistant") }
            }
            Text(
                if (overlayRunning) "The floating assistant is running." else "The floating assistant is not running.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(4.dp))
            AssistantPanelContent(scrollable = false)
        }
    }
}
