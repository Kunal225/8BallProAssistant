package com.eightballpro.assistant.android.capture

import android.app.Activity
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.util.Log
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.content.pm.ServiceInfo
import android.hardware.display.VirtualDisplay
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.eightballpro.assistant.android.AssistantController
import com.eightballpro.assistant.android.notifications.AssistantNotifications
import com.eightballpro.assistant.domain.frame.FrameIntake

/**
 * Foreground service that holds the MediaProjection, VirtualDisplay and ImageReader while the user's
 * approved capture is running. Frames are offered to [AssistantController] only when analysis wants them.
 * Every resource is released on stop, on system termination, and when the service is destroyed.
 *
 * Lifecycle in short:
 * - start: foreground first, then projection, callback, display and reader, in that order. Any failure ends
 *   the capture and releases everything that was created.
 * - frames: [FrameIntake] reserves before it copies, drops repeated images and closes every image.
 * - rotation: [ReaderSwap] puts a new reader in place and releases the old one only afterwards. If that fails,
 *   the old reader is kept and capture goes on.
 * - stop, system stop, revoked permission, destroy: [releaseCapture], which can safely run more than once.
 */
class ScreenCaptureService : Service() {

    /**
     * Guards the projection, display and reader. They are touched from the main thread (start, orientation
     * change, destroy) and from the capture thread (the projection's stop callback), so reads and changes of
     * all three go through this lock. Nothing that calls into [AssistantController] runs while it is held.
     */
    private val captureLock = Any()

    @Volatile private var projection: MediaProjection? = null
    @Volatile private var display: VirtualDisplay? = null
    @Volatile private var reader: ImageReader? = null
    @Volatile private var capturing = false
    private var captureThread: HandlerThread? = null
    private var handler: Handler? = null
    private var orientation = Configuration.ORIENTATION_UNDEFINED
    private var displayDensityDpi = 0

    /** Reserve, convert, release and submit for each image. See [FrameIntake] for the rules it enforces. */
    private val intake = FrameIntake<Image>(
        reserve = { nowMs -> AssistantController.reserveFrame(nowMs) },
        convert = { image -> ImageConverter.toRawFrame(image) },
        release = { image -> image.close() },
        submit = { id, frame -> AssistantController.submitReservedFrame(id, frame) },
    )

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            AssistantController.onCaptureEnded("Screen capture ended. It was stopped by the system or permission was revoked.")
            releaseCapture(stopProjection = false)
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> AssistantController.stopCapture(applicationContext)
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        // Must be called promptly after startForegroundService, so it comes first, before any early return.
        try {
            startAsForeground()
        } catch (e: RuntimeException) {
            AssistantController.onCaptureEnded("Could not start the capture service in the foreground.")
            stopSelf()
            return
        }
        // Only one capture session can exist. A start that arrives while one is running replaces it: everything
        // the old session held is released first, so there is never more than one projection, display and reader.
        // The capture state machine already refuses a second request while capture runs; this also covers a stop
        // followed at once by a restart, before the old service instance has finished shutting down.
        if (capturing) Log.w(TAG, "A capture start arrived while capturing. Replacing the running session.")
        releaseCapture(stopProjection = true)
        intake.reset()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = intent.dataExtra()
        if (resultCode != Activity.RESULT_OK || data == null) {
            failCapture("Screen capture permission was not granted.")
            return
        }
        try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            val mp = manager.getMediaProjection(resultCode, data)
            if (mp == null) {
                failCapture("Could not start screen capture.")
                return
            }
            projection = mp
            // Android 14+ requires the callback to be registered before the display is created.
            mp.registerCallback(projectionCallback, ensureHandler())
            if (!createDisplay()) {
                failCapture("Could not create the capture display.")
                return
            }
            capturing = true
            orientation = resources.configuration.orientation
        } catch (e: SecurityException) {
            failCapture("Screen capture was refused by the system.")
        } catch (e: IllegalStateException) {
            failCapture("Screen capture could not start.")
        } catch (e: RuntimeException) {
            // Anything else the system throws while the projection is set up ends the capture cleanly, instead
            // of taking the service, and with it the whole app, down.
            failCapture("Screen capture could not start.")
        }
    }

    private fun createDisplay(): Boolean = synchronized(captureLock) {
        val mp = projection ?: return@synchronized false
        val metrics = resources.displayMetrics
        val (width, height) = scaledSize(metrics.widthPixels, metrics.heightPixels)
        val newReader = try {
            newReader(width, height)
        } catch (e: Exception) {
            return@synchronized false
        }
        val newDisplay = try {
            mp.createVirtualDisplay(
                VIRTUAL_DISPLAY_NAME,
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface,
                null,
                ensureHandler(),
            )
        } catch (e: Exception) {
            null
        }
        if (newDisplay == null) {
            closeReader(newReader)
            return@synchronized false
        }
        reader = newReader
        display = newDisplay
        displayDensityDpi = metrics.densityDpi
        true
    }

    /** A reader that delivers to [onImageAvailable]. If it cannot be set up, nothing is left open. */
    private fun newReader(width: Int, height: Int): ImageReader {
        val fresh = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, MAX_IMAGES)
        try {
            fresh.setOnImageAvailableListener({ r -> onImageAvailable(r) }, ensureHandler())
        } catch (e: Exception) {
            fresh.close()
            throw e
        }
        return fresh
    }

    private fun closeReader(target: ImageReader) {
        try {
            target.setOnImageAvailableListener(null, null)
            target.close()
        } catch (ignored: Exception) {
            // Closing an already closed or broken reader cannot be fixed further.
        }
    }

    private fun onImageAvailable(r: ImageReader) {
        val image = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            // The reader was closed while this callback was queued, for example during a replacement.
            null
        }
        if (image == null) return

        val stamp = try {
            image.timestamp
        } catch (e: Exception) {
            closeQuietly(image)
            return
        }
        // The intake reserves a frame before it copies anything, drops repeated images, and closes the image
        // on every path. An image left open would make the reader run out of buffers and stop delivering.
        intake.accept(image, stamp, SystemClock.elapsedRealtime())
    }

    private fun closeQuietly(image: Image) {
        try {
            image.close()
        } catch (ignored: Exception) {
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!capturing) return
        val newOrientation = newConfig.orientation
        if (newOrientation == orientation) return

        when (val outcome = resizeCapture()) {
            is ReaderSwap.Outcome.Replaced -> orientation = newOrientation
            is ReaderSwap.Outcome.KeptPrevious -> {
                // Capture goes on with the reader it had. The orientation is left as it was, so the next
                // configuration change tries the replacement again.
                Log.w(TAG, "Could not resize the capture for the new orientation. Keeping the previous reader.")
            }
            ReaderSwap.Outcome.Failed -> failCapture("Screen capture could not adapt to orientation change.")
        }
    }

    /**
     * Gives the virtual display a reader of the new size. The new reader is created and attached first, and the
     * old one is released only after that worked. If it did not, the new reader is released and the display is
     * pointed back at the old one, so a failed resize never costs the working capture.
     */
    private fun resizeCapture(): ReaderSwap.Outcome<ImageReader> {
        val metrics = resources.displayMetrics
        val (width, height) = scaledSize(metrics.widthPixels, metrics.heightPixels)
        val dpi = metrics.densityDpi
        return synchronized(captureLock) {
            val activeDisplay = display
            val previous = reader
            if (activeDisplay == null || previous == null) {
                // No display yet (for example, the first display could not be created). Build it from scratch,
                // after releasing whatever half of a previous setup is left, so nothing is overwritten and leaked.
                releaseDisplay()
                val created = createDisplay()
                val current = reader
                return@synchronized if (created && current != null) {
                    ReaderSwap.Outcome.Replaced(current)
                } else {
                    ReaderSwap.Outcome.Failed
                }
            }
            val previousDpi = displayDensityDpi
            val outcome = ReaderSwap.swap(
                previous = previous,
                create = { newReader(width, height) },
                attach = { fresh ->
                    activeDisplay.resize(width, height, dpi)
                    activeDisplay.surface = fresh.surface
                },
                restore = { old ->
                    activeDisplay.resize(old.width, old.height, previousDpi)
                    activeDisplay.surface = old.surface
                },
                release = { closeReader(it) },
            )
            when (outcome) {
                is ReaderSwap.Outcome.Replaced -> {
                    reader = outcome.active
                    displayDensityDpi = dpi
                }
                is ReaderSwap.Outcome.KeptPrevious -> reader = outcome.active
                ReaderSwap.Outcome.Failed -> Unit
            }
            outcome
        }
    }

    private fun failCapture(reason: String) {
        AssistantController.onCaptureEnded(reason)
        releaseCapture(stopProjection = true)
        stopSelf()
    }

    private fun releaseDisplay() = synchronized(captureLock) {
        display?.release()
        display = null
        reader?.let { closeReader(it) }
        reader = null
    }

    private fun releaseCapture(stopProjection: Boolean) = synchronized(captureLock) {
        capturing = false
        releaseDisplay()
        projection?.let { p ->
            try {
                p.unregisterCallback(projectionCallback)
            } catch (e: IllegalArgumentException) {
                // The callback was never registered; nothing to undo.
            }
            if (stopProjection) p.stop()
        }
        projection = null
    }

    private fun startAsForeground() {
        AssistantNotifications.ensureChannels(this)
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            AssistantNotifications.capture(this),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
        )
    }

    private fun ensureHandler(): Handler {
        handler?.let { return it }
        val thread = HandlerThread("assistant-capture").apply { start() }
        captureThread = thread
        return Handler(thread.looper).also { handler = it }
    }

    override fun onDestroy() {
        releaseCapture(stopProjection = true)
        captureThread?.quitSafely()
        captureThread = null
        handler = null
        AssistantController.onServiceDestroyed()
        super.onDestroy()
    }

    /** Longest side at most [MAX_WIDTH], keeping the aspect ratio, to limit memory and CPU. */
    private fun scaledSize(width: Int, height: Int): Pair<Int, Int> {
        if (width <= MAX_WIDTH) return width to height.coerceAtLeast(1)
        val scale = MAX_WIDTH.toFloat() / width
        return MAX_WIDTH to (height * scale).toInt().coerceAtLeast(1)
    }

    @Suppress("DEPRECATION")
    private fun Intent.dataExtra(): Intent? =
        if (Build.VERSION.SDK_INT >= 33) {
            getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            getParcelableExtra(EXTRA_DATA) as? Intent
        }

    companion object {
        const val ACTION_START = "com.eightballpro.assistant.capture.START"
        const val ACTION_STOP = "com.eightballpro.assistant.capture.STOP"
        const val EXTRA_RESULT_CODE = "com.eightballpro.assistant.capture.RESULT_CODE"
        const val EXTRA_DATA = "com.eightballpro.assistant.capture.DATA"
        private const val TAG = "ScreenCaptureService"
        private const val NOTIFICATION_ID = 2001
        private const val VIRTUAL_DISPLAY_NAME = "8BallProAssistantCapture"
        private const val MAX_WIDTH = 720
        private const val MAX_IMAGES = 2

        /** Only called from [CaptureConsentActivity], after the user approved the consent dialog. */
        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, ScreenCaptureService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ScreenCaptureService::class.java))
        }
    }
}
