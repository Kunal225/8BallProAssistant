package com.eightballpro.assistant.domain.physics3d

/**
 * Impulse-based contact resolution for solid spheres.
 *
 * Normal impulses use the coefficient of restitution. Tangential (friction) impulses oppose the
 * relative slip at the contact point and are capped by the Coulomb limit mu * normal impulse. The
 * spin enters through the contact-point velocity v + w x r, so spin changes the friction result.
 */
object ContactSolver {

    /**
     * Resolves a collision between two balls. The normal points from [a] to [b].
     * Returns the balls unchanged if they are separating.
     */
    fun resolveBallPair(
        a: PoolBall,
        b: PoolBall,
        restitution: Double,
        friction: Double,
    ): Pair<PoolBall, PoolBall> {
        val m = BallPhysics.MASS_KG
        val radius = BallPhysics.RADIUS_M
        val inertia = BallPhysics.INERTIA

        val d = b.position - a.position
        val dist = d.length()
        if (dist <= 0.0) return a to b
        val n = d * (1.0 / dist)
        val closing = (a.velocity - b.velocity).dot(n)
        if (closing <= 0.0) return a to b

        // Normal impulse: equal masses, so each ball changes by jn/m along the normal.
        val jn = (1.0 + restitution) * closing * m / 2.0
        var av = a.velocity - n * (jn / m)
        var bv = b.velocity + n * (jn / m)

        // Tangential impulse from relative contact-point slip.
        val ra = n * radius
        val rb = n * (-radius)
        val contactRelative = (av + a.angularVelocity.cross(ra)) - (bv + b.angularVelocity.cross(rb))
        val slip = contactRelative - n * contactRelative.dot(n)
        val slipSpeed = slip.length()

        var aw = a.angularVelocity
        var bw = b.angularVelocity
        if (slipSpeed > SLIP_EPSILON) {
            val f = minOf(slipSpeed * m * BallPhysics.PAIR_SLIP_IMPULSE_FACTOR, friction * jn)
            val p = slip * (-f / slipSpeed)
            av = av + p * (1.0 / m)
            aw = aw + ra.cross(p) * (1.0 / inertia)
            bv = bv - p * (1.0 / m)
            bw = bw + rb.cross(p * (-1.0)) * (1.0 / inertia)
        }
        return a.copy(velocity = av, angularVelocity = aw) to b.copy(velocity = bv, angularVelocity = bw)
    }

    /**
     * Resolves a ball hitting a rail. [inwardNormal] points from the rail into the table.
     * Returns the ball unchanged if it is moving away from the rail.
     */
    fun resolveCushion(
        ball: PoolBall,
        inwardNormal: Vec3,
        restitution: Double,
        friction: Double,
    ): PoolBall {
        val m = BallPhysics.MASS_KG
        val radius = BallPhysics.RADIUS_M
        val inertia = BallPhysics.INERTIA

        val normalSpeed = ball.velocity.dot(inwardNormal)
        if (normalSpeed >= 0.0) return ball

        val jn = (1.0 + restitution) * (-normalSpeed) * m
        var v = ball.velocity + inwardNormal * (jn / m)
        var w = ball.angularVelocity

        // Contact point lies on the rail face, opposite the inward normal.
        val r = inwardNormal * (-radius)
        val contact = v + w.cross(r)
        val slip = contact - inwardNormal * contact.dot(inwardNormal)
        val slipSpeed = slip.length()
        if (slipSpeed > SLIP_EPSILON) {
            val f = minOf(slipSpeed * m * BallPhysics.SINGLE_SLIP_IMPULSE_FACTOR, friction * jn)
            val p = slip * (-f / slipSpeed)
            v = v + p * (1.0 / m)
            w = w + r.cross(p) * (1.0 / inertia)
        }
        return ball.copy(velocity = v, angularVelocity = w)
    }

    /**
     * Friction and rolling resistance for a ball on the cloth, applied for one time step.
     * Sliding friction is an impulse capped at mu * m * g * dt, and it stops the slip exactly when the
     * slip is smaller than the cap, so it does not overshoot into chatter. Rolling resistance is a
     * deceleration opposing horizontal motion.
     */
    fun applyFloorFriction(
        ball: PoolBall,
        dt: Double,
        slidingFriction: Double,
        rollingFriction: Double,
    ): PoolBall {
        val m = BallPhysics.MASS_KG
        val inertia = BallPhysics.INERTIA
        val g = BallPhysics.GRAVITY

        val contactOffset = Vec3(0.0, 0.0, -BallPhysics.RADIUS_M)
        val contact = ball.velocity + ball.angularVelocity.cross(contactOffset)
        val slip = Vec3(contact.x, contact.y, 0.0)
        val slipSpeed = slip.length()

        var v = ball.velocity
        var w = ball.angularVelocity
        if (slipSpeed > SLIP_EPSILON) {
            val j = minOf(slidingFriction * m * g * dt, slipSpeed * m * BallPhysics.SINGLE_SLIP_IMPULSE_FACTOR)
            val impulse = slip * (-j / slipSpeed)
            v = v + impulse * (1.0 / m)
            w = w + contactOffset.cross(impulse) * (1.0 / inertia)
        }

        val horizontal = Vec3(v.x, v.y, 0.0)
        val horizontalSpeed = horizontal.length()
        if (horizontalSpeed > 0.0) {
            val dv = minOf(rollingFriction * g * dt, horizontalSpeed)
            v = v - horizontal * (dv / horizontalSpeed)
        }
        return ball.copy(velocity = v, angularVelocity = w)
    }

    private const val SLIP_EPSILON = 1e-12
}
