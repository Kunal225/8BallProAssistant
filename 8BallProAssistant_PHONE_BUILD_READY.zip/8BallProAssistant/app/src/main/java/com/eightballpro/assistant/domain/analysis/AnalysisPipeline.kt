package com.eightballpro.assistant.domain.analysis

import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.TABLE_LENGTH_M_NINE_FOOT
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.table.TableSpec
import com.eightballpro.assistant.domain.vision.Assessment
import com.eightballpro.assistant.domain.vision.BallClass
import com.eightballpro.assistant.domain.vision.BallClassifier
import com.eightballpro.assistant.domain.vision.BallDetector
import com.eightballpro.assistant.domain.vision.BallDetectorConfig
import com.eightballpro.assistant.domain.vision.ColorProfile
import com.eightballpro.assistant.domain.vision.Confidence
import com.eightballpro.assistant.domain.vision.ConfidenceEvaluator
import com.eightballpro.assistant.domain.vision.Downsampler
import com.eightballpro.assistant.domain.vision.ArgbImage
import com.eightballpro.assistant.domain.vision.PerspectiveCalibration
import com.eightballpro.assistant.domain.vision.Point2D
import com.eightballpro.assistant.domain.vision.AimEstimator
import com.eightballpro.assistant.domain.vision.AimResult
import com.eightballpro.assistant.domain.vision.CueStickDetector
import com.eightballpro.assistant.domain.vision.CueStickResult
import com.eightballpro.assistant.domain.vision.GameState
import com.eightballpro.assistant.domain.vision.GameStateClassifier
import com.eightballpro.assistant.domain.vision.GameStateResult
import com.eightballpro.assistant.domain.vision.TableBoundaryDetector
import com.eightballpro.assistant.domain.vision.TableBounds

enum class DetectionSource { AUTO, MANUAL }

/**
 * A ball found in the image. [centre] is in table-normalised coordinates: u along the table length and v
 * along the width, both in [0, 1] for balls on the cloth. Normalised values do not depend on image resolution.
 */
data class DetectedBall(
    val id: Int?,
    val cls: BallClass,
    val centre: Point2D,
    val assessment: Assessment,
    val source: DetectionSource,
)

data class AnalysisConfig(
    val felt: ColorProfile = ColorProfile.BLUE_FELT,
    val maxWidth: Int = 480,
    /** Ball radius divided by table length. Physical constant, independent of screen resolution. */
    val ballRadiusToTableLength: Double = BallPhysics.RADIUS_M / TABLE_LENGTH_M_NINE_FOOT,
    val ballDetector: BallDetectorConfig = BallDetectorConfig(),
)

data class AnalysisResult(
    val analysedWidth: Int,
    val analysedHeight: Int,
    val table: TableBounds?,
    val tableAssessment: Assessment?,
    val calibration: PerspectiveCalibration?,
    val balls: List<DetectedBall>,
    val unmappedBlobs: Int,
    val warnings: List<String>,
    val aimEstimate: AimResult? = null,
    val cueStickResult: CueStickResult? = null,
    val angleAnalysis: AngleAnalysis? = null,
    val gameStateResult: GameStateResult? = null,
)

/**
 * Screenshot or frame analysis. Used by both modes: Mode A on captured frames of the developer's own
 * game, and Mode B on screenshots the user imports. It only reads pixels and returns results; it does
 * not store or upload images.
 */
class AnalysisPipeline(private val config: AnalysisConfig = AnalysisConfig()) {

    fun analyze(source: ArgbImage, calibrationOverride: PerspectiveCalibration? = null): AnalysisResult {
        val image = Downsampler.toMaxWidth(source, config.maxWidth)
        val bounds = TableBoundaryDetector.detect(image, config.felt)
        if (bounds == null) {
            return AnalysisResult(
                analysedWidth = image.width,
                analysedHeight = image.height,
                table = null,
                tableAssessment = null,
                calibration = null,
                balls = emptyList(),
                unmappedBlobs = 0,
                warnings = listOf("No table detected. Calibrate the corners manually or import a clearer screenshot."),
            )
        }

        val tableAssessment = ConfidenceEvaluator.tableAssessment(bounds)
        val calibration = calibrationOverride ?: PerspectiveCalibration.fromBounds(bounds)
        val warnings = mutableListOf<String>()

        val stateResult = GameStateClassifier.classify(image, bounds, config.felt)
        if (stateResult.state != GameState.LIVE_MATCH) {
            return AnalysisResult(
                analysedWidth = image.width,
                analysedHeight = image.height,
                table = bounds,
                tableAssessment = tableAssessment,
                calibration = calibration,
                balls = emptyList(),
                unmappedBlobs = 0,
                warnings = listOf(stateResult.description),
                gameStateResult = stateResult,
            )
        }

        if (!calibration.isValid()) warnings += "Calibration corners do not form a valid quadrilateral."
        if (tableAssessment.level == Confidence.UNCERTAIN || tableAssessment.level == Confidence.LOW) {
            warnings += "Table detection is uncertain. Check the calibration corners."
        }

        val expectedRadiusPx = config.ballRadiusToTableLength * bounds.width
        val blobs = BallDetector.detect(image, bounds, config.felt, config.ballDetector)
        val rawBalls = mutableListOf<DetectedBall>()
        var unmapped = 0
        for (blob in blobs) {
            val uv = calibration.toNormalized(Point2D(blob.centreX, blob.centreY))
            if (uv == null) {
                unmapped++
                continue
            }
            val inside = uv.x in -OUTSIDE_TOLERANCE..(1 + OUTSIDE_TOLERANCE) &&
                uv.y in -OUTSIDE_TOLERANCE..(1 + OUTSIDE_TOLERANCE)
            val classification = BallClassifier.classify(blob)
            val assessment = ConfidenceEvaluator.ballAssessment(blob, expectedRadiusPx, classification, inside)
            rawBalls += DetectedBall(null, classification.cls, uv, assessment, DetectionSource.AUTO)
        }

        val cueCandidates = rawBalls.filter { it.cls == BallClass.CUE }
        val bestCue = cueCandidates.maxByOrNull { it.assessment.score }

        val balls = rawBalls.map { ball ->
            if (ball.cls == BallClass.CUE && ball !== bestCue) {
                ball.copy(
                    cls = BallClass.UNCERTAIN,
                    assessment = ball.assessment.copy(
                        level = Confidence.UNCERTAIN,
                        reasons = ball.assessment.reasons + "secondary cue-ball candidate demoted",
                    ),
                )
            } else {
                ball
            }
        }

        var aimEstimate: AimResult? = null
        var cueStickResult: CueStickResult? = null
        var angleAnalysis: AngleAnalysis? = null

        if (bestCue != null) {
            aimEstimate = AimEstimator.estimate(image, bestCue.centre, calibration)
            cueStickResult = CueStickDetector.detect(image, bestCue.centre, calibration)
            if (!aimEstimate.detected) {
                warnings += aimEstimate.statusMessage
            }
            val tableSpec = TableGeometry3D.from(TableSpec.NINE_FOOT)
            val cuePosMetres = DetectionToPhysics.toTable(bestCue.centre, tableSpec)
            val targetMetres = if (aimEstimate.detected && aimEstimate.targetU != null && aimEstimate.targetV != null) {
                DetectionToPhysics.toTable(Point2D(aimEstimate.targetU, aimEstimate.targetV), tableSpec)
            } else null
            if (cuePosMetres != null && targetMetres != null) {
                val aimDir = (targetMetres - cuePosMetres).horizontal().normalizedOrZero()
                val physicsInput = DetectionToPhysics.build(balls, tableSpec)
                angleAnalysis = AngleAnalyzer.analyze(cuePosMetres, aimDir, physicsInput.balls, tableSpec)
            }
        }

        if (balls.none { it.cls == BallClass.CUE && it.assessment.level in setOf(Confidence.HIGH, Confidence.MEDIUM, Confidence.USER_CONFIRMED) }) {
            warnings += "Cue ball not identified. Place it manually."
        }
        if (cueCandidates.size > 1) warnings += "More than one cue-ball candidate found."
        if (balls.isEmpty()) warnings += "No ball-like objects found inside the table."
        if (unmapped > 0) warnings += "$unmapped detected region(s) could not be mapped to the table."

        return AnalysisResult(
            analysedWidth = image.width,
            analysedHeight = image.height,
            table = bounds,
            tableAssessment = tableAssessment,
            calibration = calibration,
            balls = balls,
            unmappedBlobs = unmapped,
            warnings = warnings,
            aimEstimate = aimEstimate,
            cueStickResult = cueStickResult,
            angleAnalysis = angleAnalysis,
            gameStateResult = stateResult,
        )
    }

    companion object {
        /** Detections slightly outside the cloth are kept but marked lower confidence. */
        private const val OUTSIDE_TOLERANCE = 0.02
    }
}

/** A user correction. [index] refers to an entry in the automatic list; null adds a new ball. */
data class ManualEdit(val index: Int?, val cls: BallClass, val centre: Point2D)

object ManualEdits {

    fun apply(balls: List<DetectedBall>, edits: List<ManualEdit>): List<DetectedBall> {
        val result = balls.toMutableList()
        for (edit in edits) {
            val confirmed = DetectedBall(
                id = null,
                cls = edit.cls,
                centre = edit.centre,
                assessment = Assessment(1.0, Confidence.USER_CONFIRMED, listOf("Confirmed by the user")),
                source = DetectionSource.MANUAL,
            )
            val index = edit.index
            if (index == null) {
                result += confirmed
            } else {
                require(index in result.indices) { "edit index $index is out of range" }
                result[index] = confirmed
            }
        }
        return result
    }

    fun remove(balls: List<DetectedBall>, indices: Set<Int>): List<DetectedBall> =
        balls.filterIndexed { i, _ -> i !in indices }
}
