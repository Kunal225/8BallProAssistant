package com.eightballpro.assistant.android.capture

import android.graphics.PixelFormat
import android.media.Image
import com.eightballpro.assistant.domain.frame.RawFrame
import com.eightballpro.assistant.domain.frame.RawFrameFactory

/** Converts an RGBA_8888 Image from ImageReader into a RawFrame. The caller still closes the Image. */
object ImageConverter {

    fun toRawFrame(image: Image): RawFrame? {
        if (image.format != PixelFormat.RGBA_8888) return null
        val plane = image.planes.firstOrNull() ?: return null
        if (plane.pixelStride != 4) return null
        return RawFrameFactory.fromBuffer(image.width, image.height, plane.rowStride, plane.buffer)
    }
}
