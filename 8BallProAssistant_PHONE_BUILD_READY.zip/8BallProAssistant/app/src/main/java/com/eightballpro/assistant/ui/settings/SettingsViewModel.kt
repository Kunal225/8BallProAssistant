package com.eightballpro.assistant.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.eightballpro.assistant.data.settings.SettingsRepository
import com.eightballpro.assistant.data.settings.settingsDataStore
import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.settings.AppSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository(application.settingsDataStore)

    val settings: StateFlow<AppSettings> = repository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AppSettings(),
    )

    fun updatePhysics(transform: (PhysicsConfig) -> PhysicsConfig) {
        viewModelScope.launch { repository.updatePhysics(transform) }
    }

    fun setShowGuideLines(value: Boolean) {
        viewModelScope.launch { repository.setShowGuideLines(value) }
    }

    fun setKeepScreenOn(value: Boolean) {
        viewModelScope.launch { repository.setKeepScreenOn(value) }
    }
}
