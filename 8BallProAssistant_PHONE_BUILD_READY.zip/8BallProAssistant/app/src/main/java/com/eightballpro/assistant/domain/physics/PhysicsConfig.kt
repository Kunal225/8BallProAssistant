package com.eightballpro.assistant.domain.physics

/**
 * User-adjustable physics parameters, used by the 3D engine. Construction validates ranges,
 * so an invalid configuration cannot reach the engine.
 *
 * - slidingFriction: ball-cloth sliding friction. Also used as the cushion friction coefficient.
 * - rollingFriction: rolling resistance (dimensionless; deceleration = value * g).
 * - cushionRestitution, ballRestitution: normal coefficients of restitution.
 * - ballFriction: ball-ball contact friction.
 * - clothRestitution: vertical bounce of the ball on the cloth.
 */
data class PhysicsConfig(
    val slidingFriction: Double = 0.2,
    val rollingFriction: Double = 0.01,
    val cushionRestitution: Double = 0.85,
    val ballRestitution: Double = 0.95,
    val ballFriction: Double = 0.05,
    val clothRestitution: Double = 0.5,
) {
    init {
        require(slidingFriction in SLIDING_FRICTION_RANGE) { "slidingFriction out of range: $slidingFriction" }
        require(rollingFriction in ROLLING_FRICTION_RANGE) { "rollingFriction out of range: $rollingFriction" }
        require(cushionRestitution in CUSHION_RESTITUTION_RANGE) { "cushionRestitution out of range: $cushionRestitution" }
        require(ballRestitution in BALL_RESTITUTION_RANGE) { "ballRestitution out of range: $ballRestitution" }
        require(ballFriction in BALL_FRICTION_RANGE) { "ballFriction out of range: $ballFriction" }
        require(clothRestitution in CLOTH_RESTITUTION_RANGE) { "clothRestitution out of range: $clothRestitution" }
    }

    companion object {
        // Ranges must be declared before DEFAULT, because DEFAULT's construction reads them.
        val SLIDING_FRICTION_RANGE: ClosedFloatingPointRange<Double> = 0.05..0.5
        val ROLLING_FRICTION_RANGE: ClosedFloatingPointRange<Double> = 0.001..0.05
        val CUSHION_RESTITUTION_RANGE: ClosedFloatingPointRange<Double> = 0.5..1.0
        val BALL_RESTITUTION_RANGE: ClosedFloatingPointRange<Double> = 0.8..1.0
        val BALL_FRICTION_RANGE: ClosedFloatingPointRange<Double> = 0.0..0.3
        val CLOTH_RESTITUTION_RANGE: ClosedFloatingPointRange<Double> = 0.0..0.9

        val DEFAULT = PhysicsConfig()
    }
}
