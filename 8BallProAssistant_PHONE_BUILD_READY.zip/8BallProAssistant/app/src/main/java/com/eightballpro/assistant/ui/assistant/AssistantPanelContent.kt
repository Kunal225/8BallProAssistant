package com.eightballpro.assistant.ui.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import com.eightballpro.assistant.android.AssistantController
import com.eightballpro.assistant.ui.common.LiveTrajectoryCanvas
import com.eightballpro.assistant.ui.common.TrajectoryRenderer
import com.eightballpro.assistant.domain.assistant.AimSettings
import com.eightballpro.assistant.domain.assistant.AimSource
import com.eightballpro.assistant.domain.assistant.AssistantSnapshot
import com.eightballpro.assistant.domain.assistant.DetectionView
import com.eightballpro.assistant.domain.assistant.PredictionConfidence
import com.eightballpro.assistant.domain.assistant.PredictionView
import com.eightballpro.assistant.domain.assistant.RunState
import com.eightballpro.assistant.domain.capture.CaptureState
import com.eightballpro.assistant.domain.capture.StopReason
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.table.TableSpec
import com.eightballpro.assistant.domain.vision.BallClass
import java.util.Locale

/**
 * The assistant panel. Used inside the floating window and on the Floating Assistant screen, so both
 * show the same state and send the same actions. Every control reflects the real state: a button is
 * enabled only when its action is allowed now.
 */
@Composable
fun AssistantPanelContent(
    modifier: Modifier = Modifier,
    onHide: (() -> Unit)? = null,
    onClose: (() -> Unit)? = null,
    scrollable: Boolean = true,
) {
    val context = LocalContext.current
    val snapshot by AssistantController.snapshot.collectAsState()
    var captureRequestError by remember { mutableStateOf<String?>(null) }

    val scrollModifier = if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .then(scrollModifier)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("8B Assistant", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (onHide != null) TextButton(onClick = onHide) { Text("Hide") }
            if (onClose != null) TextButton(onClick = onClose) { Text("Close") }
        }

        StatusCard(snapshot, captureRequestError)
        LiveTrajectoryCanvas(snapshot)
        DetectionCard(snapshot.detection)
        PredictionCard(snapshot.prediction)
        AngleAnalysisCard(snapshot)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = snapshot.ownGameAcknowledged,
                onCheckedChange = { AssistantController.setAcknowledged(it) },
            )
            Text(
                "This is my own game or an authorised test environment.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        CaptureControls(
            state = snapshot.captureState,
            acknowledged = snapshot.ownGameAcknowledged,
            onStart = { captureRequestError = AssistantController.requestCapture(context) },
            onStop = { AssistantController.stopCapture(context) },
        )
        AnalysisControls(snapshot.runState)
        AimControls(snapshot.aim, snapshot.aimSource, snapshot.autoAimAvailable)
    }
}

@Composable
private fun StatusCard(snapshot: AssistantSnapshot, requestError: String?) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Analysis: ${runLabel(snapshot.runState)}", style = MaterialTheme.typography.bodyMedium)
            Text("Capture: ${captureLabel(snapshot.captureState)}", style = MaterialTheme.typography.bodyMedium)
            Text("Frames analysed: ${snapshot.framesAnalysed}", style = MaterialTheme.typography.bodySmall)
            if (snapshot.analysing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            val error = requestError ?: snapshot.captureError
            if (error != null) {
                Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            val message = snapshot.message
            if (message != null && message != error) {
                Text(message, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun DetectionCard(detection: DetectionView) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Table: ${detection.tableStatus}", style = MaterialTheme.typography.bodyMedium)
            Text("Balls found: ${detection.ballCount}", style = MaterialTheme.typography.bodySmall)
            Text(
                if (detection.cueFound) "Cue ball: found" else "Cue ball: not found",
                style = MaterialTheme.typography.bodySmall,
            )
            detection.warnings.forEach { Text("- $it", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun PredictionCard(prediction: PredictionView) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Prediction", style = MaterialTheme.typography.titleSmall)
            Text(prediction.headline, style = MaterialTheme.typography.bodyMedium)
            if (prediction.available) {
                Text(confidenceLabel(prediction.confidence), style = MaterialTheme.typography.bodySmall)
                prediction.limitations.forEach { Text("- $it", style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
private fun AngleAnalysisCard(snapshot: AssistantSnapshot) {
    val table = remember { TableGeometry3D.from(TableSpec.NINE_FOOT) }
    val manual = snapshot.aimSource == AimSource.USER_MANUAL
    // The analysis is computed from the automatically detected aim, so it does not describe a manual aim.
    val analysis = if (manual) null else snapshot.latestResult?.angleAnalysis
    val cueStick = snapshot.latestResult?.cueStickResult
    val cue = snapshot.latestResult?.balls?.firstOrNull { it.cls == BallClass.CUE }
    // A manual aim gets the angle of its own line. Nothing is shown when no angle was measured.
    val aimAngle = if (manual) {
        cue?.let {
            TrajectoryRenderer.aimAngleDegrees(
                it.centre.x, it.centre.y, snapshot.aim.targetU, snapshot.aim.targetV, table.length, table.width,
            )
        }
    } else {
        analysis?.aimAngleDeg
    }
    val targetPocket = analysis?.targetPocket?.name?.lowercase()?.replace('_', ' ') ?: "None"
    val stickStatus = if (cueStick != null && cueStick.detected) "Detected (${degrees(cueStick.angleDeg)})" else "Searching..."

    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("360° Angle & Geometry Analysis", style = MaterialTheme.typography.titleSmall)
            Text("Cue Stick: $stickStatus", style = MaterialTheme.typography.bodySmall)
            Text(
                (if (manual) "Manual Aim Angle: " else "Aim Angle: ") + degrees(aimAngle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            if (manual) {
                Text("Cut, impact and rebound angles are measured for the automatic aim only.", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("Cut Angle: ${degrees(analysis?.cutAngleDeg)} | Impact Angle: ${degrees(analysis?.impactAngleDeg)}", style = MaterialTheme.typography.bodySmall)
                Text("Rebound Angle: ${degrees(analysis?.reboundAngleDeg)} | Deflection: ${degrees(analysis?.cueDeflectionAngleDeg)}", style = MaterialTheme.typography.bodySmall)
                Text("Target Pocket: $targetPocket", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** An angle for display, or "n/a" when it was not measured. A missing value is never shown as 0. */
private fun degrees(value: Double?): String =
    if (value == null) "n/a" else String.format(Locale.US, "%.1f°", value)

@Composable
private fun CaptureControls(
    state: CaptureState,
    acknowledged: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
) {
    val capturing = state is CaptureState.Capturing
    val awaiting = state is CaptureState.AwaitingConsent
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onStart, enabled = acknowledged && !capturing && !awaiting, modifier = Modifier.weight(1f)) {
            Text("Start capture")
        }
        OutlinedButton(onClick = onStop, enabled = capturing || awaiting, modifier = Modifier.weight(1f)) {
            Text("Stop capture")
        }
    }
}

@Composable
private fun AnalysisControls(state: RunState) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(onClick = { AssistantController.startAnalysis() }, enabled = state == RunState.STOPPED, modifier = Modifier.weight(1f)) {
            Text("Start")
        }
        OutlinedButton(onClick = { AssistantController.pauseAnalysis() }, enabled = state == RunState.RUNNING, modifier = Modifier.weight(1f)) {
            Text("Pause")
        }
        OutlinedButton(onClick = { AssistantController.resumeAnalysis() }, enabled = state == RunState.PAUSED, modifier = Modifier.weight(1f)) {
            Text("Resume")
        }
        OutlinedButton(onClick = { AssistantController.stopAnalysis() }, enabled = state != RunState.STOPPED, modifier = Modifier.weight(1f)) {
            Text("Stop")
        }
    }
}

@Composable
private fun AimControls(aim: AimSettings, source: AimSource, autoAimAvailable: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (source) {
                    AimSource.USER_MANUAL -> "Aim: MANUAL (set by you)"
                    AimSource.AUTO_DETECTION ->
                        if (autoAimAvailable) "Aim: AUTO (detected on screen)" else "Aim: AUTO (none detected yet)"
                },
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            OutlinedButton(
                onClick = { AssistantController.resumeAutoAim() },
                enabled = source == AimSource.USER_MANUAL,
            ) { Text("Use auto aim") }
        }
        // Moving a slider makes the aim manual. Automatic detection then leaves it alone until "Use auto aim".
        Text("Aim target along the table length: ${"%.2f".format(Locale.US, aim.targetU)}", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = aim.targetU.toFloat(),
            onValueChange = { v -> AssistantController.updateAim { it.copy(targetU = v.toDouble().coerceIn(0.0, 1.0)) } },
        )
        Text("Aim target across the table width: ${"%.2f".format(Locale.US, aim.targetV)}", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = aim.targetV.toFloat(),
            onValueChange = { v -> AssistantController.updateAim { it.copy(targetV = v.toDouble().coerceIn(0.0, 1.0)) } },
        )
        Text(
            "Power: ${"%.2f".format(Locale.US, aim.power)} (${"%.1f".format(Locale.US, aim.speedMetersPerSecond())} m/s)",
            style = MaterialTheme.typography.bodySmall,
        )
        Slider(
            value = aim.power.toFloat(),
            onValueChange = { v -> AssistantController.updateAim { it.copy(power = v.toDouble().coerceIn(0.0, 1.0)) } },
        )
    }
}

private fun runLabel(state: RunState): String = when (state) {
    RunState.STOPPED -> "stopped"
    RunState.RUNNING -> "running"
    RunState.PAUSED -> "paused"
}

private fun captureLabel(state: CaptureState): String = when (state) {
    CaptureState.Idle -> "not capturing"
    is CaptureState.AwaitingConsent -> "waiting for your approval"
    is CaptureState.Capturing -> "capturing the shared screen"
    is CaptureState.Stopped -> when (state.reason) {
        StopReason.USER_REQUESTED -> "stopped"
        StopReason.PROJECTION_ENDED -> "ended by the system"
    }
    is CaptureState.Denied -> "permission denied"
}

private fun confidenceLabel(confidence: PredictionConfidence): String = when (confidence) {
    PredictionConfidence.NONE -> "No estimate"
    PredictionConfidence.LOW -> "Low confidence: some balls were excluded"
    PredictionConfidence.MEDIUM -> "Estimate only: not validated against measured shots"
}
