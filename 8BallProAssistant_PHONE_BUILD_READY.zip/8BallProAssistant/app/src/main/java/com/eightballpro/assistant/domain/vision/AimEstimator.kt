package com.eightballpro.assistant.domain.vision

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class AimResult(
    val detected: Boolean,
    val targetU: Double?,
    val targetV: Double?,
    val aimAngleDeg: Double?,
    val confidence: Double,
    val statusMessage: String,
)

/**
 * Estimates automatic game shot aim direction from captured screen frames.
 * Inspects radial pixels around the detected cue ball to identify aiming guidelines or cue-stick direction.
 */
object AimEstimator {

    fun estimate(
        image: ArgbImage,
        cueNormalized: Point2D,
        calibration: PerspectiveCalibration,
    ): AimResult {
        val cuePx = calibration.toImage(cueNormalized.x, cueNormalized.y)
        val cx = cuePx.x.toInt()
        val cy = cuePx.y.toInt()

        if (cx !in 0 until image.width || cy !in 0 until image.height) {
            return AimResult(
                detected = false,
                targetU = null,
                targetV = null,
                aimAngleDeg = null,
                confidence = 0.0,
                statusMessage = "Aim not detected — cue ball outside frame bounds.",
            )
        }

        // Radial ray search around cue ball pixel (cx, cy)
        val minR = 12
        val maxR = 45
        var sumDx = 0.0
        var sumDy = 0.0
        var hitCount = 0

        for (r in minR..maxR step 3) {
            val stepDeg = 5
            for (deg in 0 until 360 step stepDeg) {
                val rad = Math.toRadians(deg.toDouble())
                val px = (cx + r * cos(rad)).toInt()
                val py = (cy + r * sin(rad)).toInt()
                if (px !in 0 until image.width || py !in 0 until image.height) continue

                val color = image.pixelAt(px, py)
                val red = (color shr 16) and 0xFF
                val green = (color shr 8) and 0xFF
                val blue = color and 0xFF
                val brightness = (red + green + blue) / 3

                // Aiming guidelines in pool games are bright white, yellow, or high-contrast lines
                if (brightness >= 210) {
                    sumDx += cos(rad)
                    sumDy += sin(rad)
                    hitCount++
                }
            }
        }

        if (hitCount < 8) {
            return AimResult(
                detected = false,
                targetU = null,
                targetV = null,
                aimAngleDeg = null,
                confidence = 0.0,
                statusMessage = "Aim not detected — adjust visibility or use manual aim preview.",
            )
        }

        val len = sqrt(sumDx * sumDx + sumDy * sumDy)
        val coherence = len / hitCount
        if (coherence < 0.4) {
            return AimResult(
                detected = false,
                targetU = null,
                targetV = null,
                aimAngleDeg = null,
                confidence = coherence,
                statusMessage = "Aim not detected — diffuse guideline reflections.",
            )
        }

        val dirX = sumDx / len
        val dirY = sumDy / len
        val aimAngleDeg = (Math.toDegrees(atan2(dirY, dirX)) + 360.0) % 360.0

        // Map ray vector into normalized table (u, v) space
        val pFarPx = Point2D(cuePx.x + dirX * 100.0, cuePx.y + dirY * 100.0)
        val uFar = calibration.toNormalized(pFarPx)

        if (uFar == null) {
            return AimResult(
                detected = false,
                targetU = null,
                targetV = null,
                aimAngleDeg = aimAngleDeg,
                confidence = 0.0,
                statusMessage = "Aim not detected — aim ray could not be mapped.",
            )
        }

        val targetU = uFar.x.coerceIn(0.0, 1.0)
        val targetV = uFar.y.coerceIn(0.0, 1.0)

        return AimResult(
            detected = true,
            targetU = targetU,
            targetV = targetV,
            aimAngleDeg = aimAngleDeg,
            confidence = coherence.coerceIn(0.5, 0.95),
            statusMessage = "Automatic aim detected.",
        )
    }
}
