package com.eightballpro.assistant.domain.vision

/** Table extent in pixel indices (inclusive). */
data class TableBounds(val left: Int, val top: Int, val right: Int, val bottom: Int, val feltCoverage: Double) {
    val width: Int get() = right - left + 1
    val height: Int get() = bottom - top + 1
    val aspectRatio: Double get() = width.toDouble() / height
}

/**
 * Finds the felt region as the rows and columns where felt pixels are dense. This is a bounding-box
 * detector, not a corner detector. It does not handle a table partly hidden by overlays, which the
 * user can correct with manual calibration.
 */
object TableBoundaryDetector {

    fun detect(
        image: ArgbImage,
        felt: ColorProfile,
        minRowFraction: Double = 0.3,
        minColumnFraction: Double = 0.3,
    ): TableBounds? {
        val w = image.width
        val h = image.height
        val mask = BooleanArray(w * h) { felt.matches(image.pixels[it]) }
        val rowCounts = IntArray(h)
        val columnCounts = IntArray(w)
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mask[y * w + x]) {
                    rowCounts[y]++
                    columnCounts[x]++
                }
            }
        }
        val rowThreshold = minRowFraction * w
        val columnThreshold = minColumnFraction * h
        val rows = (0 until h).filter { rowCounts[it] > rowThreshold }
        val columns = (0 until w).filter { columnCounts[it] > columnThreshold }
        if (rows.isEmpty() || columns.isEmpty()) return null

        val left = columns.first()
        val right = columns.last()
        val top = rows.first()
        val bottom = rows.last()
        var feltCount = 0
        for (y in top..bottom) {
            for (x in left..right) {
                if (mask[y * w + x]) feltCount++
            }
        }
        val area = (right - left + 1) * (bottom - top + 1)
        return TableBounds(left, top, right, bottom, feltCount.toDouble() / area)
    }
}
