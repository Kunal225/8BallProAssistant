package com.eightballpro.assistant.domain.analysis

import com.eightballpro.assistant.domain.assistant.AssistantPresenter
import com.eightballpro.assistant.domain.assistant.AssistantRunMachine
import com.eightballpro.assistant.domain.assistant.PredictionConfidence
import com.eightballpro.assistant.domain.assistant.PredictionView
import com.eightballpro.assistant.domain.assistant.RunState
import com.eightballpro.assistant.domain.frame.CropRect
import com.eightballpro.assistant.domain.frame.FrameAdapter
import com.eightballpro.assistant.domain.frame.FrameConversion
import com.eightballpro.assistant.domain.frame.FrameRotation
import com.eightballpro.assistant.domain.frame.RawFrame
import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.physics3d.ShotResult
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.table.TableSpec

/** Result of offering one frame to the coordinator. */
sealed interface FrameOutcome {
    val frameId: Long

    data class Analysed(override val frameId: Long, val result: AnalysisResult, val physics: PhysicsInput) : FrameOutcome
    data class Rejected(override val frameId: Long, val reason: String) : FrameOutcome
    data class Skipped(override val frameId: Long, val reason: String) : FrameOutcome
}

/** A prediction tied to the frame it was computed from. It is stale once that frame is no longer the latest. */
data class PredictionTicket(val frameId: Long, val view: PredictionView, val shot: ShotResult?)

/**
 * Connects FrameAdapter -> AnalysisPipeline -> DetectionToPhysics -> AssistantPresenter.
 *
 * Guarantees:
 * - Frame ids must increase. Older or repeated frames are skipped.
 * - Only one frame is analysed at a time. A call made while analysis is running is skipped.
 * - Frames are analysed only while the run state is RUNNING.
 * - A rejected frame clears the previous analysis, so old detections are never shown as current.
 * - A prediction is current only while the frame it came from is still the latest analysed frame.
 *
 * Synchronised on this object. Android callers should not hold locks around submit or predict.
 */
class FrameAnalysisCoordinator(
    private val pipeline: AnalysisPipeline = AnalysisPipeline(),
    private val table: TableGeometry3D = TableGeometry3D.from(TableSpec.NINE_FOOT),
) {
    private var lastAcceptedId = 0L
    private var inFlight = false

    /**
     * Volatile so [isCurrent] can read it without waiting for a running analysis. The UI thread asks
     * whether a prediction is still current every time it builds a snapshot, and must never block on [submit].
     */
    @Volatile
    private var latest: FrameOutcome? = null

    /** Test hook: runs at the start of analysis, while the frame is in flight. */
    internal var onAnalysisStarted: (() -> Unit)? = null

    @Synchronized
    fun submit(
        frameId: Long,
        runState: RunState,
        frame: RawFrame?,
        crop: CropRect? = null,
        rotation: FrameRotation = FrameRotation.R0,
    ): FrameOutcome {
        if (frameId <= lastAcceptedId) {
            return FrameOutcome.Skipped(frameId, "Frame $frameId is not newer than $lastAcceptedId.")
        }
        if (!AssistantRunMachine.mayProcessFrame(runState, inFlight)) {
            val reason = if (runState != RunState.RUNNING) "Analysis is not running."
                else "Previous frame is still being analysed."
            return FrameOutcome.Skipped(frameId, reason)
        }

        lastAcceptedId = frameId
        inFlight = true
        try {
            onAnalysisStarted?.invoke()
            val outcome = when (val conversion = FrameAdapter.convert(frame, crop, rotation)) {
                is FrameConversion.Rejected -> FrameOutcome.Rejected(frameId, conversion.reason)
                is FrameConversion.Converted -> {
                    val result = pipeline.analyze(conversion.image)
                    FrameOutcome.Analysed(frameId, result, DetectionToPhysics.build(result.balls, table))
                }
            }
            latest = outcome
            return outcome
        } catch (e: RuntimeException) {
            // Never leave the gate stuck, and never keep stale detections after a failure.
            val failed = FrameOutcome.Rejected(frameId, "Analysis failed: ${e.javaClass.simpleName}")
            latest = failed
            return failed
        } finally {
            inFlight = false
        }
    }

    /** Drops the current analysis, for example after the user changes the calibration. */
    @Synchronized
    fun invalidate() {
        latest = null
    }

    /** Predicts a shot from the latest analysed frame. Returns an unavailable view if there is none. */
    @Synchronized
    fun predict(
        direction: Vec3,
        speed: Double,
        sideOffset: Double,
        heightOffset: Double,
        elevationRad: Double,
        config: PhysicsConfig = PhysicsConfig.DEFAULT,
    ): PredictionTicket {
        val current = latest
        if (current !is FrameOutcome.Analysed) {
            return PredictionTicket(current?.frameId ?: 0L, AssistantPresenter.prediction(null, null), null)
        }
        return try {
            val shot = ShotPrediction.predict(
                current.physics, table, config, direction, speed, sideOffset, heightOffset, elevationRad,
            )
            PredictionTicket(current.frameId, AssistantPresenter.prediction(current.physics, shot), shot)
        } catch (e: IllegalArgumentException) {
            val view = PredictionView(
                available = false,
                headline = "Invalid shot settings: ${e.message}",
                confidence = PredictionConfidence.NONE,
                limitations = emptyList(),
            )
            PredictionTicket(current.frameId, view, null)
        }
    }

    /** True only while the frame behind [ticket] is still the latest analysed frame. Does not take the lock. */
    fun isCurrent(ticket: PredictionTicket): Boolean {
        val current = latest
        return current is FrameOutcome.Analysed && current.frameId == ticket.frameId
    }
}
