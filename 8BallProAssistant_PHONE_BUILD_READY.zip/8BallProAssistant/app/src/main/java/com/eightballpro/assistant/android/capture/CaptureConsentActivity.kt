package com.eightballpro.assistant.android.capture

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.eightballpro.assistant.android.AssistantController

/**
 * Shows the system screen-capture consent dialog. Capture starts only if the user approves here.
 * The activity is transparent and never stays in recents.
 */
class CaptureConsentActivity : ComponentActivity() {

    private val consentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            // The session refuses the grant when it is no longer waiting for one, for example when the user
            // pressed Stop capture or closed the assistant while this dialog was open. In that case the
            // approved projection must not be used, or capture would run without the session knowing.
            val refusal = AssistantController.onConsentResult(true)
            if (refusal == null) {
                try {
                    ScreenCaptureService.start(this, result.resultCode, data)
                } catch (e: RuntimeException) {
                    AssistantController.onCaptureEnded("Could not start the screen capture service.")
                }
            }
        } else {
            AssistantController.onConsentResult(false)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!AssistantController.isAwaitingConsent()) {
            finish()
            return
        }
        if (savedInstanceState == null) {
            val manager = getSystemService(MediaProjectionManager::class.java)
            consentLauncher.launch(manager.createScreenCaptureIntent())
        }
    }

    companion object {
        fun start(context: Context) {
            context.startActivity(
                Intent(context, CaptureConsentActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    }
}
