package com.eightballpro.assistant.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eightballpro.assistant.domain.assistant.AimSource
import com.eightballpro.assistant.domain.assistant.AssistantSnapshot
import com.eightballpro.assistant.domain.assistant.RunState
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.table.TableSpec
import com.eightballpro.assistant.domain.vision.BallClass
import com.eightballpro.assistant.domain.vision.GameState
import java.util.Locale

/** Yellow: the aim preview, the line from the cue ball to where the aim is set. Never a prediction. */
private val AimLineColor = Color(0xFFF2C14E)

/** Green and orange: simulated cue-ball and object-ball paths. Drawn only from the physics frames. */
private val CuePathColor = Color(0xFF3DDC97)
private val ObjectPathColor = Color(0xFFFF8A3D)

/** Red: the first cue-ball contact in the simulated shot. */
private val ImpactMarkerColor = Color(0xFFE5484D)

/** Purple: a geometric pocket guide from the angle analysis. It is not a simulated path. */
private val PocketGuideColor = Color(0xFF7C4DFF)

/** Object balls that move less than this in the simulation get no path. */
private const val MIN_OBJECT_PATH_M = 0.01

/**
 * Transparent, full-screen overlay canvas that draws over the game screen. It maps table-normalised points
 * through the detected table calibration into display coordinates.
 *
 * What is drawn, and where each part comes from:
 * - Rings around detected balls (detection).
 * - Yellow dashed line with arrow: the aim preview, from the cue ball to the aim target ([AssistantSnapshot.aim]).
 * - Green and orange lines, and the red dot: the simulated shot ([AssistantSnapshot.latestShot]). These appear
 *   only while there is a current prediction, and the yellow line never stands in for them.
 * - Purple pocket guide: geometry of the auto-detected aim. Hidden for a manual aim, which it does not describe.
 *
 * Detection markers are rings drawn outside the ball, so the ball's own pixels in the captured frame stay as the
 * game drew them. This canvas is part of the display that is captured, so anything drawn over a ball would change
 * what the next frame detects.
 */
@Composable
fun GameOverlayCanvas(
    snapshot: AssistantSnapshot,
    modifier: Modifier = Modifier,
) {
    val table = remember { TableGeometry3D.from(TableSpec.NINE_FOOT) }
    val prediction = snapshot.prediction
    val result = snapshot.latestResult
    val shot = snapshot.latestShot
    val calibration = result?.calibration
    val cueBall = result?.balls?.firstOrNull { it.cls == BallClass.CUE }
    val isLiveMatch = result?.gameStateResult?.state == GameState.LIVE_MATCH

    val layers = TrajectoryRenderer.overlayLayers(
        isLiveMatch = isLiveMatch,
        hasCueBall = cueBall != null,
        aimSource = snapshot.aimSource,
        aimDetectedInCurrentFrame = result?.aimEstimate?.detected == true,
        predictionAvailable = prediction.available,
        hasShot = shot != null,
    )

    // The simulated paths change only when a new shot arrives, so they are built once per shot.
    val paths = remember(shot, layers.physicsPaths) {
        if (layers.physicsPaths && shot != null) {
            TrajectoryRenderer.physicsPaths(shot.frames, table.length, table.width, MIN_OBJECT_PATH_M)
        } else {
            null
        }
    }
    val contact = remember(shot, layers.physicsPaths) {
        if (layers.physicsPaths && shot != null) {
            TrajectoryRenderer.firstCueContact(shot.events, table.length, table.width)
        } else {
            null
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (result == null || calibration == null || result.table == null) return@Canvas
            if (result.analysedWidth <= 0 || result.analysedHeight <= 0) return@Canvas

            val scaleX = size.width / result.analysedWidth.toFloat()
            val scaleY = size.height / result.analysedHeight.toFloat()

            fun toScreen(u: Double, v: Double): Offset {
                val pImg = calibration.toImage(u, v)
                return Offset(pImg.x.toFloat() * scaleX, pImg.y.toFloat() * scaleY)
            }

            /** Screen radius of a ball at table point (u, v), from the physical ball size. */
            fun ballRadiusPx(u: Double, v: Double): Float =
                (toScreen(u + BallPhysics.RADIUS_M / table.length, v) - toScreen(u, v)).getDistance()

            fun drawPolyline(points: List<TrajectoryRenderer.TrajectoryPoint>, color: Color, width: Float) {
                if (points.size < 2) return
                val path = Path()
                points.forEachIndexed { i, pt ->
                    val s = toScreen(pt.u, pt.v)
                    if (i == 0) path.moveTo(s.x, s.y) else path.lineTo(s.x, s.y)
                }
                drawPath(path, color = color, style = Stroke(width = width))
            }

            // 1. Detected balls, as rings just outside each ball.
            if (layers.ballMarkers) {
                for (ball in result.balls) {
                    val pos = toScreen(ball.centre.x, ball.centre.y)
                    val ring = (ballRadiusPx(ball.centre.x, ball.centre.y) * 1.4f).coerceIn(10f, 80f)
                    when (ball.cls) {
                        BallClass.CUE -> drawCircle(Color.Cyan, ring, pos, style = Stroke(3f))
                        BallClass.OBJECT -> drawCircle(Color.Yellow, ring, pos, style = Stroke(3f))
                        BallClass.BLACK -> drawCircle(Color.White, ring, pos, style = Stroke(3f))
                        else -> Unit
                    }
                }
            }

            // 2. Aim preview: cue ball to the aim target. Yellow, dashed, with an arrow.
            if (layers.aimPreview && cueBall != null) {
                val from = toScreen(cueBall.centre.x, cueBall.centre.y)
                val to = toScreen(snapshot.aim.targetU, snapshot.aim.targetV)
                drawLine(
                    AimLineColor,
                    from,
                    to,
                    strokeWidth = 4f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f)),
                )
                drawArrowhead(from, to, AimLineColor, arrowSize = 24f)
            }

            // 3. Simulated shot: green cue path, orange object paths, red first contact.
            if (paths != null) {
                for (points in paths.objectPaths.values) drawPolyline(points, ObjectPathColor, 4f)
                drawPolyline(paths.cuePath, CuePathColor, 5f)
                if (contact != null) {
                    val at = toScreen(contact.u, contact.v)
                    drawCircle(ImpactMarkerColor, 14f, at)
                    drawCircle(Color.White, 6f, at)
                }
            }

            // 4. Pocket guide from the angle geometry. It describes the auto-detected aim only.
            val analysis = result.angleAnalysis
            val impact = analysis?.impactPoint
            val pocketName = analysis?.targetPocket
            if (layers.aimPreview && snapshot.aimSource == AimSource.AUTO_DETECTION &&
                impact != null && pocketName != null
            ) {
                val pocket = table.pockets.firstOrNull { it.name == pocketName }
                if (pocket != null) {
                    val ghost = toScreen(impact.x / table.length, impact.y / table.width)
                    val pocketPos = toScreen(pocket.x / table.length, pocket.y / table.width)
                    drawLine(
                        PocketGuideColor,
                        ghost,
                        pocketPos,
                        strokeWidth = 3f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 10f)),
                    )
                    drawCircle(PocketGuideColor, 32f, pocketPos, style = Stroke(4f))
                }
            }
        }

        // Status badge: says which state the overlay is in, and who set the aim.
        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp),
            shape = RoundedCornerShape(50),
            color = Color.Black.copy(alpha = 0.8f),
        ) {
            val analysis = result?.angleAnalysis
            val gameState = result?.gameStateResult?.state
            val sourceLabel = if (snapshot.aimSource == AimSource.USER_MANUAL) "MANUAL AIM" else "AUTO AIM"

            val (statusText, statusColor) = when {
                gameState == GameState.TABLE_EDITOR -> "TABLE EDITOR DETECTED — PREDICTION DISABLED" to Color(0xFFFF8A3D)
                gameState == GameState.MENU -> "MENU SCREEN DETECTED — PREDICTION DISABLED" to Color.LightGray
                gameState == GameState.LOADING -> "TRANSITION SCREEN DETECTED — PREDICTION DISABLED" to Color.LightGray
                layers.aimPreview && cueBall != null -> {
                    // Angles are shown only when they were measured. A manual aim gets the angle of its own line.
                    val aimAngle = if (snapshot.aimSource == AimSource.AUTO_DETECTION && analysis != null) {
                        analysis.aimAngleDeg
                    } else {
                        TrajectoryRenderer.aimAngleDegrees(
                            cueBall.centre.x, cueBall.centre.y,
                            snapshot.aim.targetU, snapshot.aim.targetV,
                            table.length, table.width,
                        )
                    }
                    val parts = mutableListOf(sourceLabel)
                    if (aimAngle != null) parts += String.format(Locale.US, "AIM %.1f°", aimAngle)
                    if (snapshot.aimSource == AimSource.AUTO_DETECTION) {
                        analysis?.cutAngleDeg?.let { parts += String.format(Locale.US, "CUT %.1f°", it) }
                        analysis?.impactAngleDeg?.let { parts += String.format(Locale.US, "IMPACT %.1f°", it) }
                    }
                    parts.joinToString(" | ") to Color.Yellow
                }
                snapshot.aimSource == AimSource.USER_MANUAL && snapshot.runState == RunState.RUNNING ->
                    "MANUAL AIM — WAITING FOR CUE BALL" to Color.White
                snapshot.runState == RunState.RUNNING -> "AUTO AIM — AIM NOT DETECTED" to Color.White
                else -> "FLOATING ASSISTANT ACTIVE" to Color.White
            }
            Text(
                text = statusText,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = statusColor,
                fontSize = 13.sp,
            )
        }
    }
}

private fun DrawScope.drawArrowhead(
    from: Offset,
    to: Offset,
    color: Color,
    arrowSize: Float = 24f,
) {
    val dx = to.x - from.x
    val dy = to.y - from.y
    val len = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    if (len < 1f) return

    // Prevent the arrowhead from covering the entire short line
    val actualSize = minOf(arrowSize, len * 0.3f)

    val nx = dx / len
    val ny = dy / len

    val leftX = to.x - actualSize * nx + (actualSize * 0.5f) * ny
    val leftY = to.y - actualSize * ny - (actualSize * 0.5f) * nx

    val rightX = to.x - actualSize * nx - (actualSize * 0.5f) * ny
    val rightY = to.y - actualSize * ny + (actualSize * 0.5f) * nx

    val arrowPath = Path().apply {
        moveTo(to.x, to.y)
        lineTo(leftX, leftY)
        lineTo(rightX, rightY)
        close()
    }
    drawPath(arrowPath, color = color)
}
