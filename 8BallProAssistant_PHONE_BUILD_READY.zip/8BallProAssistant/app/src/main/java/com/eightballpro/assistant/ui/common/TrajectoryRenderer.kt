package com.eightballpro.assistant.ui.common

import com.eightballpro.assistant.domain.assistant.AimSettings
import com.eightballpro.assistant.domain.assistant.AimSource
import com.eightballpro.assistant.domain.analysis.AnalysisResult
import com.eightballpro.assistant.domain.physics3d.BallCollision
import com.eightballpro.assistant.domain.physics3d.Frame
import com.eightballpro.assistant.domain.physics3d.CUE_BALL_ID
import com.eightballpro.assistant.domain.physics3d.PhysicsEvent
import com.eightballpro.assistant.domain.vision.BallClass
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Pure coordinate-conversion and state-derivation logic for the LiveTrajectoryCanvas.
 *
 * All coordinate conventions are:
 *   - Normalised (u, v): both in [0.0, 1.0], where (0,0) is the top-left of the playing surface.
 *   - Metres: physics world units (table.length × table.width).
 *   - Screen pixels: derived from canvas size with uniform scaling.
 *
 * This object contains NO Compose or Android dependencies so that all logic can be tested
 * in plain JVM unit tests.
 */
object TrajectoryRenderer {

    /**
     * Placeholder cue-ball position shown when no detection is available.
     * Positioned at the standard break position (roughly 1/4 along, centre width).
     */
    const val PLACEHOLDER_CUE_U = 0.25
    const val PLACEHOLDER_CUE_V = 0.5

    /**
     * The minimum trajectory line length in screen pixels below which we suppress drawing.
     * Values below this are indistinguishable from a point and cause rendering artefacts.
     */
    const val MIN_LINE_LENGTH_PX = 4.0

    /**
     * The minimum total ball movement in screen pixels for an object ball path to be drawn.
     */
    const val MIN_OBJECT_BALL_MOVEMENT_PX = 2.0

    // -----------------------------------------------------------------------------------------
    // Coordinate conversions
    // -----------------------------------------------------------------------------------------

    /**
     * Converts a normalised table position (u, v) ∈ [0,1]² into canvas pixel coordinates.
     *
     * The table is centred inside the canvas with a uniform scale factor (preserving aspect
     * ratio) and an [inset] pixel border.
     *
     * @param u     Normalised position along table length (0 = left rail, 1 = right rail).
     * @param v     Normalised position along table width  (0 = top rail,  1 = bottom rail).
     * @param canvasW Canvas width in pixels.
     * @param canvasH Canvas height in pixels.
     * @param tableLengthM Table playing length in metres.
     * @param tableWidthM  Table playing width in metres.
     * @param inset Border inset in pixels.
     * @return Pair<Float, Float> (x, y) screen coordinates in pixels.
     */
    fun normalisedToScreen(
        u: Double,
        v: Double,
        canvasW: Float,
        canvasH: Float,
        tableLengthM: Double,
        tableWidthM: Double,
        inset: Float = 16f,
    ): Pair<Float, Float> {
        val scaleX = (canvasW - 2 * inset) / tableLengthM.toFloat()
        val scaleY = (canvasH - 2 * inset) / tableWidthM.toFloat()
        val scale = minOf(scaleX, scaleY)
        val originX = (canvasW - tableLengthM.toFloat() * scale) / 2f
        val originY = (canvasH - tableWidthM.toFloat() * scale) / 2f
        val x = originX + (u * tableLengthM).toFloat() * scale
        val y = originY + (v * tableWidthM).toFloat() * scale
        return x to y
    }

    /**
     * Converts a physics world position (metres) to normalised coordinates.
     * Returns null if the position is outside a reasonable [0 - margin, 1 + margin] range.
     */
    fun metresToNormalised(
        xMetres: Double,
        yMetres: Double,
        tableLengthM: Double,
        tableWidthM: Double,
        marginFraction: Double = 0.05,
    ): Pair<Double, Double>? {
        val u = xMetres / tableLengthM
        val v = yMetres / tableWidthM
        return if (u in -marginFraction..(1.0 + marginFraction) &&
                   v in -marginFraction..(1.0 + marginFraction)) {
            u.coerceIn(0.0, 1.0) to v.coerceIn(0.0, 1.0)
        } else {
            null
        }
    }

    // -----------------------------------------------------------------------------------------
    // Physics paths, contact point and aim direction
    // -----------------------------------------------------------------------------------------

    /** Cue-ball and object-ball paths from simulated frames, as normalised table points. */
    data class PhysicsPaths(
        val cuePath: List<TrajectoryPoint>,
        val objectPaths: Map<Int, List<TrajectoryPoint>>,
    )

    /**
     * Collects the ball paths of a simulated shot. Every point is a sampled physics position, so the result is
     * the predicted path and nothing else. Positions outside the table (beyond the margin) are skipped.
     *
     * @param minObjectMovementM object balls that travel less than this many metres are left out.
     */
    fun physicsPaths(
        physicsFrames: List<Frame>,
        tableLengthM: Double,
        tableWidthM: Double,
        minObjectMovementM: Double = 0.0,
    ): PhysicsPaths {
        val cuePath = mutableListOf<TrajectoryPoint>()
        val objectPaths = linkedMapOf<Int, MutableList<TrajectoryPoint>>()
        for (frame in physicsFrames) {
            val cuePos = frame.positions[CUE_BALL_ID]
            if (cuePos != null) {
                val uv = metresToNormalised(cuePos.x, cuePos.y, tableLengthM, tableWidthM)
                if (uv != null) cuePath.add(TrajectoryPoint(uv.first, uv.second))
            }
            for ((ballId, pos3) in frame.positions) {
                if (ballId == CUE_BALL_ID) continue
                val uv = metresToNormalised(pos3.x, pos3.y, tableLengthM, tableWidthM) ?: continue
                objectPaths.getOrPut(ballId) { mutableListOf() }.add(TrajectoryPoint(uv.first, uv.second))
            }
        }
        if (minObjectMovementM > 0.0) {
            objectPaths.entries.removeAll { (_, pts) ->
                var travelled = 0.0
                for (i in 1 until pts.size) {
                    travelled += hypot(
                        (pts[i].u - pts[i - 1].u) * tableLengthM,
                        (pts[i].v - pts[i - 1].v) * tableWidthM,
                    )
                }
                travelled < minObjectMovementM
            }
        }
        return PhysicsPaths(cuePath, objectPaths)
    }

    /**
     * Where the cue ball first touches another ball in the simulated shot, as a normalised table point.
     * The point comes from the physics collision event, not from the end of the cue path. Returns null when the
     * shot has no cue-ball contact, or when the event carries no position.
     */
    fun firstCueContact(
        events: List<PhysicsEvent>,
        tableLengthM: Double,
        tableWidthM: Double,
    ): TrajectoryPoint? {
        val hit = events.filterIsInstance<BallCollision>()
            .filter { it.ballA == CUE_BALL_ID || it.ballB == CUE_BALL_ID }
            .minByOrNull { it.time } ?: return null
        val point = hit.point ?: return null
        val uv = metresToNormalised(point.x, point.y, tableLengthM, tableWidthM) ?: return null
        return TrajectoryPoint(uv.first, uv.second)
    }

    /**
     * Direction of the line from the cue ball to the aim target, in degrees in [0, 360), measured in the table
     * plane from the long axis toward the short axis. This is the same convention as the angle analysis.
     * Returns null when the two points coincide, because no direction exists then.
     */
    fun aimAngleDegrees(
        cueU: Double,
        cueV: Double,
        targetU: Double,
        targetV: Double,
        tableLengthM: Double,
        tableWidthM: Double,
    ): Double? {
        val dx = (targetU - cueU) * tableLengthM
        val dy = (targetV - cueV) * tableWidthM
        if (hypot(dx, dy) < 1e-9) return null
        return (Math.toDegrees(atan2(dy, dx)) + 360.0) % 360.0
    }

    /** Which layers of the full-screen overlay may be drawn for one snapshot. */
    data class OverlayLayers(
        /** Rings around detected balls. */
        val ballMarkers: Boolean,
        /** The yellow aim preview line from the cue ball to the aim target. */
        val aimPreview: Boolean,
        /** The green and orange simulated paths. Requires the aim preview and a current prediction. */
        val physicsPaths: Boolean,
    )

    /**
     * The aim preview needs a live match, a detected cue ball and an aim the user can trust: one set by hand,
     * or one detected in the current frame. A stale detected aim from an earlier frame is not shown. The
     * simulated paths are drawn only together with a current prediction, so they can never appear on their own
     * and the preview can never stand in for them.
     */
    fun overlayLayers(
        isLiveMatch: Boolean,
        hasCueBall: Boolean,
        aimSource: AimSource,
        aimDetectedInCurrentFrame: Boolean,
        predictionAvailable: Boolean,
        hasShot: Boolean,
    ): OverlayLayers {
        val aimUsable = aimSource == AimSource.USER_MANUAL || aimDetectedInCurrentFrame
        val preview = isLiveMatch && hasCueBall && aimUsable
        return OverlayLayers(
            ballMarkers = isLiveMatch,
            aimPreview = preview,
            physicsPaths = preview && predictionAvailable && hasShot,
        )
    }

    // -----------------------------------------------------------------------------------------
    // State derivation
    // -----------------------------------------------------------------------------------------

    /**
     * Describes the visual status of the trajectory canvas.
     */
    enum class CanvasStatus {
        /** No screen capture / analysis running. Manual aim preview mode. */
        MANUAL_AIM_PREVIEW,
        /** Analysis is running but cue ball not yet detected. */
        WAITING_FOR_CUE_BALL,
        /** Cue ball detected but aim not yet available from detection; manual aim sliders are active. */
        CUE_DETECTED_MANUAL_AIM,
        /** Both cue ball and aim are detected; prediction computed. */
        LIVE_PREDICTION,
    }

    data class CueBallState(
        /** Normalised (u, v) position of the cue ball to draw. Never null; uses placeholder when undetected. */
        val u: Double,
        val v: Double,
        /** True when the position came from actual detection. */
        val isDetected: Boolean,
    )

    data class AimLineState(
        /** Normalised (u, v) of the cue ball origin. */
        val fromU: Double,
        val fromV: Double,
        /** Normalised (u, v) of the aim destination. */
        val toU: Double,
        val toV: Double,
        /** True when this is a non-trivial line (the two ends differ by more than MIN_LINE_LENGTH_PX). */
        val isNonTrivial: Boolean,
    )

    data class TrajectoryPoint(val u: Double, val v: Double)

    data class RendererState(
        val status: CanvasStatus,
        val cueBall: CueBallState,
        val aimLine: AimLineState,
        /** Normalised cue-ball path from physics frames. Empty when prediction not available. */
        val cuePath: List<TrajectoryPoint>,
        /** Normalised object-ball paths that move significantly. */
        val objectPaths: Map<Int, List<TrajectoryPoint>>,
        val statusLabel: String,
    )

    /**
     * Derives the complete renderer state from raw snapshot fields.
     * This function is deterministic and pure — no side effects.
     *
     * @param latestResult  The latest analysis result (null = no analysis done yet).
     * @param aim           The current aim settings (always present).
     * @param predAvailable Whether the prediction engine has a result.
     * @param physicsFrames The physics simulation frames (from ShotResult.frames).
     * @param tableLengthM  Table playing length in metres.
     * @param tableWidthM   Table playing width in metres.
     * @param canvasW       Canvas width in pixels (used only for the isNonTrivial check).
     * @param canvasH       Canvas height in pixels.
     */
    fun deriveState(
        latestResult: AnalysisResult?,
        aim: AimSettings,
        predAvailable: Boolean,
        physicsFrames: List<Frame>,
        tableLengthM: Double,
        tableWidthM: Double,
        canvasW: Float,
        canvasH: Float,
        inset: Float = 16f,
    ): RendererState {
        // 1. Determine cue ball position
        val detectedCue = latestResult?.balls?.firstOrNull { it.cls == BallClass.CUE }
        val cueBall = if (detectedCue != null) {
            CueBallState(
                u = detectedCue.centre.x.coerceIn(0.0, 1.0),
                v = detectedCue.centre.y.coerceIn(0.0, 1.0),
                isDetected = true,
            )
        } else {
            CueBallState(
                u = PLACEHOLDER_CUE_U,
                v = PLACEHOLDER_CUE_V,
                isDetected = false,
            )
        }

        // 2. Aim line
        val fromU = cueBall.u
        val fromV = cueBall.v
        val toU = aim.targetU
        val toV = aim.targetV

        // Check if the line is visually meaningful in screen pixels
        val (fromX, fromY) = normalisedToScreen(fromU, fromV, canvasW, canvasH, tableLengthM, tableWidthM, inset)
        val (toX, toY)     = normalisedToScreen(toU,   toV,   canvasW, canvasH, tableLengthM, tableWidthM, inset)
        val lineLenPx = kotlin.math.sqrt(
            ((toX - fromX) * (toX - fromX) + (toY - fromY) * (toY - fromY)).toDouble()
        )
        val aimLine = AimLineState(
            fromU = fromU,
            fromV = fromV,
            toU = toU,
            toV = toV,
            isNonTrivial = lineLenPx >= MIN_LINE_LENGTH_PX,
        )

        // 3. Physics trajectory paths. These come only from the simulated frames, never from the aim line.
        val cuePath: List<TrajectoryPoint>
        val objectPaths: Map<Int, List<TrajectoryPoint>>
        if (predAvailable && physicsFrames.size >= 2) {
            val paths = physicsPaths(physicsFrames, tableLengthM, tableWidthM)
            cuePath = paths.cuePath
            // Filter object paths that have negligible movement
            objectPaths = paths.objectPaths.filter { (_, pts) ->
                if (pts.size < 2) return@filter false
                var totalPx = 0.0
                for (i in 1 until pts.size) {
                    val (ax, ay) = normalisedToScreen(pts[i - 1].u, pts[i - 1].v, canvasW, canvasH, tableLengthM, tableWidthM, inset)
                    val (bx, by) = normalisedToScreen(pts[i].u, pts[i].v, canvasW, canvasH, tableLengthM, tableWidthM, inset)
                    totalPx += kotlin.math.sqrt(((bx - ax) * (bx - ax) + (by - ay) * (by - ay)).toDouble())
                }
                totalPx >= MIN_OBJECT_BALL_MOVEMENT_PX
            }
        } else {
            cuePath = emptyList()
            objectPaths = emptyMap()
        }

        // 4. Status
        val status = when {
            latestResult == null -> CanvasStatus.MANUAL_AIM_PREVIEW
            detectedCue == null  -> CanvasStatus.WAITING_FOR_CUE_BALL
            !predAvailable       -> CanvasStatus.CUE_DETECTED_MANUAL_AIM
            else                 -> CanvasStatus.LIVE_PREDICTION
        }
        val statusLabel = when (status) {
            CanvasStatus.MANUAL_AIM_PREVIEW    -> "Aim preview — start capture to analyse"
            CanvasStatus.WAITING_FOR_CUE_BALL  -> "Analysing — waiting for cue ball detection"
            CanvasStatus.CUE_DETECTED_MANUAL_AIM -> "Cue detected — adjust aim sliders"
            CanvasStatus.LIVE_PREDICTION       -> "Live Prediction: Active"
        }

        return RendererState(
            status = status,
            cueBall = cueBall,
            aimLine = aimLine,
            cuePath = cuePath,
            objectPaths = objectPaths,
            statusLabel = statusLabel,
        )
    }
}
