package com.eightballpro.assistant.domain.analysis

import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.CUE_BALL_ID
import com.eightballpro.assistant.domain.physics3d.CueStrike
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.PoolPhysicsEngine
import com.eightballpro.assistant.domain.physics3d.ShotResult
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.vision.BallClass
import com.eightballpro.assistant.domain.vision.Confidence

/** Physics state built from detections. Immutable, and kept separate from the detections themselves. */
data class PhysicsInput(
    val balls: List<PoolBall>,
    val excluded: List<DetectedBall>,
    val warnings: List<String>,
)

/** Converts detections to physics balls. Only confident or user-confirmed balls are used. */
object DetectionToPhysics {

    private val USABLE = setOf(Confidence.HIGH, Confidence.MEDIUM, Confidence.USER_CONFIRMED)

    fun build(detections: List<DetectedBall>, table: TableGeometry3D): PhysicsInput {
        val usable = detections.filter { it.assessment.level in USABLE }
        val warnings = mutableListOf<String>()
        val excluded = detections.filter { it.assessment.level !in USABLE }.toMutableList()
        if (excluded.isNotEmpty()) warnings += "${excluded.size} uncertain detection(s) excluded from physics."

        val cueCandidates = usable.filter { it.cls == BallClass.CUE }
        val cue = cueCandidates.maxByOrNull { it.assessment.score }
        if (cue == null) warnings += "No confident cue ball. Place it manually before simulating."
        if (cueCandidates.size > 1) {
            warnings += "Extra cue-ball candidates were excluded."
            excluded += cueCandidates.filter { it !== cue }
        }

        val balls = mutableListOf<PoolBall>()
        if (cue != null) {
            val cuePosition = toTable(cue.centre, table)
            if (cuePosition != null) {
                balls += PoolBall(CUE_BALL_ID, cuePosition)
            } else {
                warnings += "Cue ball lies outside the playing area."
                excluded += cue
            }
        }

        val ids = (1..15).toMutableList()
        for (ball in usable.filter { it.cls != BallClass.CUE }) {
            val position = toTable(ball.centre, table)
            if (position == null) {
                excluded += ball
                warnings += "A ball lies outside the playing area and was excluded."
                continue
            }
            val id = if (ids.isEmpty()) null else ids.removeAt(0)
            if (id == null) {
                warnings += "More than 15 object balls; extra balls were excluded."
                excluded += ball
            } else {
                balls += PoolBall(id, position)
            }
        }
        return PhysicsInput(balls, excluded, warnings)
    }

    /** Table-normalised (u, v) to physics metres on the cloth. Returns null outside the playing area. */
    internal fun toTable(centre: com.eightballpro.assistant.domain.vision.Point2D, table: TableGeometry3D): Vec3? {
        val r = BallPhysics.RADIUS_M
        val p = Vec3(centre.x * table.length, centre.y * table.width, r)
        return if (table.isInsidePlayArea(p)) p else null
    }
}

object ShotPrediction {

    /**
     * Predicted shot from the detected cue ball. The result is new data: [input] is not modified, and the
     * prediction is not written back into the detections or any game state.
     * Returns null when there is no cue ball.
     */
    fun predict(
        input: PhysicsInput,
        table: TableGeometry3D,
        config: PhysicsConfig,
        direction: Vec3,
        speed: Double,
        sideOffset: Double,
        heightOffset: Double,
        elevationRad: Double,
        maxTime: Double = 8.0,
    ): ShotResult? {
        val cue = input.balls.firstOrNull { it.isCue } ?: return null
        val struck = CueStrike.apply(cue, direction, speed, sideOffset, heightOffset, elevationRad)
        val layout = input.balls.map { if (it.isCue) struck else it }
        return PoolPhysicsEngine(table, config).simulate(layout, maxTime)
    }
}
