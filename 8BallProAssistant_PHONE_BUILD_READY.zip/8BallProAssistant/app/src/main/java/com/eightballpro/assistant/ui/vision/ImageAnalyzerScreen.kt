@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.vision

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.domain.analysis.AnalysisConfig
import com.eightballpro.assistant.domain.analysis.AnalysisPipeline
import com.eightballpro.assistant.domain.analysis.AnalysisResult
import com.eightballpro.assistant.domain.vision.ArgbImage
import com.eightballpro.assistant.domain.vision.ColorProfile
import com.eightballpro.assistant.ui.common.ScreenScaffold

private object SampleImageGenerator {
    fun createTableImage(): ArgbImage {
        val width = 240
        val height = 140
        val feltColor = 0xFF1F6FB2.toInt()
        val whiteColor = 0xFFFFFFFF.toInt()
        val redColor = 0xFFE5484D.toInt()
        val bgColor = 0xFF101010.toInt()
        val pixels = IntArray(width * height) { bgColor }

        // Felt rectangle
        for (y in 20..119) {
            for (x in 20..219) {
                pixels[y * width + x] = feltColor
            }
        }

        // White ball at (60, 70)
        drawDisc(pixels, width, height, 60.0, 70.0, 8.0, whiteColor)
        // Red ball at (150, 60)
        drawDisc(pixels, width, height, 150.0, 60.0, 8.0, redColor)

        return ArgbImage(width, height, pixels)
    }

    private fun drawDisc(pixels: IntArray, width: Int, height: Int, cx: Double, cy: Double, r: Double, color: Int) {
        val r2 = r * r
        for (y in (cy - r - 1).toInt()..(cy + r + 1).toInt()) {
            for (x in (cx - r - 1).toInt()..(cx + r + 1).toInt()) {
                if (x !in 0 until width || y !in 0 until height) continue
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r2) {
                    pixels[y * width + x] = color
                }
            }
        }
    }
}

@Composable
fun ImageAnalyzerScreen(onBack: () -> Unit) {
    val pipeline = remember {
        AnalysisPipeline(AnalysisConfig(felt = ColorProfile.BLUE_FELT, ballRadiusToTableLength = 0.04))
    }
    var sampleFrame by remember { mutableStateOf(SampleImageGenerator.createTableImage()) }
    var result by remember { mutableStateOf<AnalysisResult?>(pipeline.analyze(sampleFrame)) }

    ScreenScaffold(title = "Image Analyzer & Vision", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    text = "Offline Computer Vision & Ball Detection",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            sampleFrame = SampleImageGenerator.createTableImage()
                            result = pipeline.analyze(sampleFrame)
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("Load Standard Table") }

                    Button(
                        onClick = {
                            val emptyImg = ArgbImage(240, 140, IntArray(240 * 140) { 0xFF101010.toInt() })
                            result = pipeline.analyze(emptyImg)
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("Test Empty Image") }
                }
            }
            val res = result
            if (res != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Table Bounds & Calibration", style = MaterialTheme.typography.titleMedium)
                            Text("Resolution: ${res.analysedWidth} x ${res.analysedHeight} px", style = MaterialTheme.typography.bodySmall)
                            val table = res.table
                            if (table != null) {
                                Text("Bounds: Left=${table.left}, Top=${table.top}, Right=${table.right}, Bottom=${table.bottom}", style = MaterialTheme.typography.bodyMedium)
                                Text("Felt Coverage: %.1f%%".format(table.feltCoverage * 100.0), style = MaterialTheme.typography.bodyMedium)
                                Text("Aspect Ratio: %.2f".format(table.aspectRatio), style = MaterialTheme.typography.bodyMedium)
                            } else {
                                Text("No table felt detected.", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
                item {
                    Text("Detected Balls (${res.balls.size})", style = MaterialTheme.typography.titleMedium)
                }
                items(res.balls) { ball ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Ball Class: ${ball.cls.name}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                            Text("Position (u, v): (%.3f, %.3f)".format(ball.centre.x, ball.centre.y), style = MaterialTheme.typography.bodyMedium)
                            Text("Confidence: ${ball.assessment.level.name} (Score: %.2f)".format(ball.assessment.score), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (res.warnings.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text("Warnings & Diagnostics", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                res.warnings.forEach { warn ->
                                    Text("• $warn", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
