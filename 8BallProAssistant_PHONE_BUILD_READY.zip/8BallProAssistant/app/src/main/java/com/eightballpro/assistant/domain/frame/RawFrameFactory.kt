package com.eightballpro.assistant.domain.frame

import java.nio.ByteBuffer

/**
 * Builds a RawFrame from a plane buffer without Android types. Copies only the bytes the frame needs,
 * and does not move the source buffer's position, so the caller can release the Image afterwards.
 */
object RawFrameFactory {

    fun fromBuffer(width: Int, height: Int, rowStrideBytes: Int, buffer: ByteBuffer): RawFrame? {
        if (width <= 0 || height <= 0 || rowStrideBytes <= 0) return null
        val bpp = FramePixelFormat.RGBA_8888.bytesPerPixel
        val required = rowStrideBytes.toLong() * (height - 1) + width.toLong() * bpp
        if (required > buffer.remaining()) return null
        val bytes = ByteArray(required.toInt())
        buffer.duplicate().get(bytes)
        return RawFrame(width, height, rowStrideBytes, bytes)
    }
}
