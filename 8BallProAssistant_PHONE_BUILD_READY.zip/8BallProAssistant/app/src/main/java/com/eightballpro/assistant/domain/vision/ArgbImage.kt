package com.eightballpro.assistant.domain.vision

/** Pixel buffer in ARGB format. Pure Kotlin so the analysis can be tested without Android. */
class ArgbImage(val width: Int, val height: Int, val pixels: IntArray) {
    init {
        require(width > 0 && height > 0) { "image size must be positive" }
        require(pixels.size == width * height) { "pixel count does not match size" }
    }

    fun pixelAt(x: Int, y: Int): Int = pixels[y * width + x]
}

/** Box-filter downscale to limit memory and CPU use. Coordinates stay relative to the returned image. */
object Downsampler {
    fun toMaxWidth(source: ArgbImage, maxWidth: Int): ArgbImage {
        require(maxWidth > 0) { "maxWidth must be positive" }
        if (source.width <= maxWidth) return source
        val factor = (source.width + maxWidth - 1) / maxWidth
        val w = source.width / factor
        val h = source.height / factor
        val out = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0
                var g = 0
                var b = 0
                for (dy in 0 until factor) {
                    for (dx in 0 until factor) {
                        val p = source.pixelAt(x * factor + dx, y * factor + dy)
                        r += (p shr 16) and 0xFF
                        g += (p shr 8) and 0xFF
                        b += p and 0xFF
                    }
                }
                val n = factor * factor
                out[y * w + x] = (0xFF shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        return ArgbImage(w, h, out)
    }
}

/** Colour rule for the table felt, defined in HSV. Hue in degrees, saturation and value in [0, 1]. */
data class ColorProfile(
    val hueMin: Float,
    val hueMax: Float,
    val saturationMin: Float,
    val valueMin: Float,
) {
    fun matches(argb: Int): Boolean {
        val r = (argb shr 16) and 0xFF
        val g = (argb shr 8) and 0xFF
        val b = argb and 0xFF
        val hue = hueDegrees(r, g, b)
        val max = maxOf(r, maxOf(g, b))
        val min = minOf(r, minOf(g, b))
        val saturation = if (max == 0) 0f else (max - min).toFloat() / max
        val value = max / 255f
        return hue in hueMin..hueMax && saturation >= saturationMin && value >= valueMin
    }

    companion object {
        /** Blue felt. Calibrate per game: the thresholds are a starting point, not a measured value. */
        val BLUE_FELT = ColorProfile(hueMin = 190f, hueMax = 230f, saturationMin = 0.35f, valueMin = 0.2f)
    }
}

/** RGB to hue in degrees, 0 to 360. Returns 0 for greys. */
fun hueDegrees(r: Int, g: Int, b: Int): Float {
    val max = maxOf(r, maxOf(g, b))
    val min = minOf(r, minOf(g, b))
    val d = (max - min).toFloat()
    if (d == 0f) return 0f
    val h = when (max) {
        r -> 60f * ((g - b) / d)
        g -> 60f * ((b - r) / d + 2f)
        else -> 60f * ((r - g) / d + 4f)
    }
    return if (h < 0f) h + 360f else h
}
