package com.eightballpro.assistant.domain.spin

import com.eightballpro.assistant.domain.geometry.Vec2

/**
 * Cue-ball contact point selectable by the user. Only the contact model lives here;
 * the resulting spin dynamics are implemented in Batch 3.
 * offsetX: -1 = left, +1 = right. offsetY: -1 = bottom (back spin), +1 = top (top spin).
 */
enum class SpinContactPoint(val label: String, val offsetX: Int, val offsetY: Int) {
    CENTER("Center Hit", 0, 0),
    TOP_SPIN("Top Spin", 0, 1),
    BACK_SPIN("Back Spin", 0, -1),
    LEFT_SPIN("Left Spin", -1, 0),
    RIGHT_SPIN("Right Spin", 1, 0),
    TOP_LEFT("Top-left Spin", -1, 1),
    TOP_RIGHT("Top-right Spin", 1, 1),
    BOTTOM_LEFT("Bottom-left Spin", -1, -1),
    BOTTOM_RIGHT("Bottom-right Spin", 1, -1);

    /** Contact offset from the cue-ball centre, scaled so that a rim contact has length 1. */
    fun normalizedOffset(): Vec2 = Vec2(offsetX.toDouble(), offsetY.toDouble()).normalizedOrZero()
}
