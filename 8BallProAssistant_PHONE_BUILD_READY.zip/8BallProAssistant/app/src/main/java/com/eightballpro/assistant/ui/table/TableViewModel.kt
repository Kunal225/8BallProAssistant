package com.eightballpro.assistant.ui.table

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.eightballpro.assistant.data.settings.SettingsRepository
import com.eightballpro.assistant.data.settings.settingsDataStore
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.CUE_BALL_ID
import com.eightballpro.assistant.domain.physics3d.CueStrike
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.PoolPhysicsEngine
import com.eightballpro.assistant.domain.physics3d.ShotResult
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.spin.SpinContactPoint
import com.eightballpro.assistant.domain.table.TableSpec
import kotlin.math.PI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class EditMode(val label: String) {
    AIM("Aim"),
    PLACE_CUE("Cue"),
    ADD_BALL("Add"),
    REMOVE("Remove"),
}

data class TableUiState(
    val balls: List<PoolBall> = emptyList(),
    val mode: EditMode = EditMode.AIM,
    val aimTarget: Vec3? = null,
    val power: Double = 0.5,
    val spin: SpinContactPoint = SpinContactPoint.CENTER,
    val spinIntensity: Double = 0.5,
    val elevationDeg: Double = 0.0,
    val showTrajectories: Boolean = true,
    val animate: Boolean = true,
    val shot: ShotResult? = null,
    val shotVersion: Int = 0,
    val isSimulating: Boolean = false,
    val message: String? = null,
)

/**
 * Holds the practice layout, the shot controls and the latest simulated shot.
 * The shot is computed by the same engine used by the unit tests, using the saved physics settings.
 */
class TableViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application.settingsDataStore)
    private val table = TableGeometry3D.from(TableSpec.NINE_FOOT)
    private val _state = MutableStateFlow(TableUiState(balls = practiceLayout()))
    val state: StateFlow<TableUiState> = _state.asStateFlow()

    fun setMode(mode: EditMode) = _state.update { it.copy(mode = mode, message = null) }

    /** Table tap, interpreted according to the current mode. [p] is in metres, z ignored. */
    fun onTableTap(p: Vec3) {
        val s = _state.value
        when (s.mode) {
            EditMode.AIM -> Unit
            EditMode.PLACE_CUE -> placeBall(p, CUE_BALL_ID, replaceCue = true)
            EditMode.ADD_BALL -> {
                val id = nextObjectId(s.balls)
                if (id == null) setMessage("All 15 object balls are already on the table.")
                else placeBall(p, id, replaceCue = false)
            }
            EditMode.REMOVE -> removeNearest(p)
        }
    }

    /** Aim target on the table. Only applies in Aim mode. The aim direction is cue ball to target. */
    fun setAimTarget(p: Vec3) {
        if (_state.value.mode != EditMode.AIM) return
        _state.update { it.copy(aimTarget = Vec3(p.x, p.y, 0.0), message = null) }
    }

    fun setPower(value: Double) = _state.update { it.copy(power = value.coerceIn(0.0, 1.0)) }

    fun setSpin(point: SpinContactPoint) = _state.update { it.copy(spin = point) }

    fun setSpinIntensity(value: Double) = _state.update { it.copy(spinIntensity = value.coerceIn(0.0, 1.0)) }

    fun setElevationDeg(value: Double) = _state.update { it.copy(elevationDeg = value.coerceIn(-15.0, 15.0)) }

    fun setShowTrajectories(value: Boolean) = _state.update { it.copy(showTrajectories = value) }

    /** Ball speed in metres per second for a power setting in [0, 1]. */
    fun speedMetersPerSecond(power: Double): Double =
        MIN_SHOT_SPEED + power.coerceIn(0.0, 1.0) * (MAX_SHOT_SPEED - MIN_SHOT_SPEED)

    /**
     * Strikes the cue ball with the current controls and simulates the shot.
     * [animate] = true plays the shot back; false shows the final trajectories immediately (preview).
     */
    fun shoot(animate: Boolean) {
        val s = _state.value
        if (s.isSimulating) return
        val cue = s.balls.firstOrNull { it.isCue } ?: return setMessage("Place the cue ball first.")
        val target = s.aimTarget ?: return setMessage("Drag on the table to aim first.")
        val direction = target - cue.position
        if (direction.horizontal().length() < MIN_AIM_LENGTH) return setMessage("Aim away from the cue ball.")

        val fraction = s.spinIntensity * MAX_TIP_OFFSET_FRACTION
        val offset = s.spin.normalizedOffset()
        val struck = CueStrike.apply(
            ball = cue,
            direction = direction,
            speed = speedMetersPerSecond(s.power),
            sideOffset = offset.x * fraction,
            heightOffset = offset.y * fraction,
            elevationRad = s.elevationDeg * PI / 180.0,
        )
        val layout = s.balls.map { if (it.isCue) struck else it }

        _state.update { it.copy(isSimulating = true, message = null) }
        viewModelScope.launch {
            val config = settingsRepository.settings.first().physics
            val result = withContext(Dispatchers.Default) {
                PoolPhysicsEngine(table, config).simulate(layout, MAX_SIM_TIME_S)
            }
            _state.update {
                it.copy(
                    shot = result,
                    shotVersion = it.shotVersion + 1,
                    animate = animate,
                    isSimulating = false,
                )
            }
        }
    }

    /** Adopts the final positions of the last shot as the new practice layout. */
    fun keepShotResult() {
        val shot = _state.value.shot ?: return
        if (shot.duration >= MAX_SIM_TIME_S - 1e-6) {
            return setMessage("The shot was still moving at the time limit. Result not kept.")
        }
        val kept = shot.finalBalls
            .filter { !it.pocketed }
            .map { it.copy(velocity = Vec3.ZERO, angularVelocity = Vec3.ZERO) }
        _state.update { it.copy(balls = kept, shot = null, aimTarget = null, message = null) }
    }

    fun clearShot() = _state.update { it.copy(shot = null, message = null) }

    fun resetLayout() = _state.update {
        it.copy(balls = practiceLayout(), shot = null, aimTarget = null, message = null)
    }

    private fun practiceLayout(): List<PoolBall> {
        val y = table.width / 2.0
        val r = BallPhysics.RADIUS_M
        return listOf(
            PoolBall(CUE_BALL_ID, Vec3(0.75, y, r)),
            PoolBall(1, Vec3(1.75, y, r)),
        )
    }

    private fun placeBall(p: Vec3, id: Int, replaceCue: Boolean) {
        val s = _state.value
        val others = if (replaceCue) s.balls.filterNot { it.isCue } else s.balls
        val error = placementError(p, others)
        if (error != null) return setMessage(error)
        val ball = PoolBall(id, Vec3(p.x, p.y, BallPhysics.RADIUS_M))
        _state.update { it.copy(balls = others + ball, shot = null, message = null) }
    }

    private fun placementError(p: Vec3, others: List<PoolBall>): String? {
        val r = BallPhysics.RADIUS_M
        if (!table.isInsidePlayArea(Vec3(p.x, p.y, r))) return "Place balls inside the cushions."
        if (table.pockets.any { it.distanceTo(p) < it.captureRadius + r }) return "Too close to a pocket."
        if (others.any { it.position.distanceTo(p) < 2 * r + MIN_GAP_M }) return "That spot overlaps another ball."
        return null
    }

    private fun removeNearest(p: Vec3) {
        val nearest = _state.value.balls.minByOrNull { it.position.distanceTo(p) }
        if (nearest == null || nearest.position.distanceTo(p) > MAX_PICK_DISTANCE_M) {
            return setMessage("No ball near that spot.")
        }
        _state.update {
            it.copy(
                balls = it.balls - nearest,
                shot = null,
                aimTarget = if (nearest.isCue) null else it.aimTarget,
                message = null,
            )
        }
    }

    private fun nextObjectId(balls: List<PoolBall>): Int? =
        (1..15).firstOrNull { id -> balls.none { it.id == id } }

    private fun setMessage(text: String) = _state.update { it.copy(message = text) }

    companion object {
        private const val MIN_SHOT_SPEED = 0.2
        private const val MAX_SHOT_SPEED = 6.0
        private const val MAX_TIP_OFFSET_FRACTION = 0.5
        private const val MAX_SIM_TIME_S = 12.0
        private const val MIN_AIM_LENGTH = 1e-3
        private const val MIN_GAP_M = 0.001
        private const val MAX_PICK_DISTANCE_M = 0.12
    }
}
