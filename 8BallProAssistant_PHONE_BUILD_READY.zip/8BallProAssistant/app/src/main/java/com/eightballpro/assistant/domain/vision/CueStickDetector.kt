package com.eightballpro.assistant.domain.vision

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class CueStickResult(
    val detected: Boolean,
    val angleDeg: Double?,
    val directionVector: Point2D?,
    val confidence: Double,
    val statusMessage: String,
)

/**
 * Detects the in-game cue stick and its orientation angle (0–360°) from captured game frames.
 * Inspects dark/metallic/wooden linear structures aligned radially with the cue ball.
 */
object CueStickDetector {

    fun detect(
        image: ArgbImage,
        cueNormalized: Point2D,
        calibration: PerspectiveCalibration,
    ): CueStickResult {
        val cuePx = calibration.toImage(cueNormalized.x, cueNormalized.y)
        val cx = cuePx.x.toInt()
        val cy = cuePx.y.toInt()

        if (cx !in 0 until image.width || cy !in 0 until image.height) {
            return CueStickResult(
                detected = false,
                angleDeg = null,
                directionVector = null,
                confidence = 0.0,
                statusMessage = "Cue stick detection unavailable — cue ball out of bounds.",
            )
        }

        val minR = 30
        val maxR = 100
        val stepR = 5
        val stepDeg = 3

        val angleHits = DoubleArray(360)

        for (deg in 0 until 360 step stepDeg) {
            val rad = Math.toRadians(deg.toDouble())
            val cosR = cos(rad)
            val sinR = sin(rad)
            var darkHits = 0
            var totalSamples = 0

            for (r in minR..maxR step stepR) {
                val px = (cx + r * cosR).toInt()
                val py = (cy + r * sinR).toInt()
                if (px !in 0 until image.width || py !in 0 until image.height) continue

                totalSamples++
                val color = image.pixelAt(px, py)
                val red = (color shr 16) and 0xFF
                val green = (color shr 8) and 0xFF
                val blue = color and 0xFF
                val maxC = maxOf(red, maxOf(green, blue))
                val minC = minOf(red, minOf(green, blue))

                // Cue stick body pixels: dark, metallic, or wooden contrast against felt
                if (maxC < 110 || (maxC - minC > 50 && red > blue)) {
                    darkHits++
                }
            }

            if (totalSamples > 0) {
                angleHits[deg] = darkHits.toDouble() / totalSamples
            }
        }

        // Find dominant angle peak
        var bestDeg = -1
        var maxHits = 0.0
        for (deg in 0 until 360) {
            // Smooth over 5-degree window
            var score = 0.0
            for (offset in -2..2) {
                val idx = (deg + offset + 360) % 360
                score += angleHits[idx]
            }
            if (score > maxHits) {
                maxHits = score
                bestDeg = deg
            }
        }

        val peakScore = maxHits / 5.0
        if (peakScore < 0.35) {
            return CueStickResult(
                detected = false,
                angleDeg = null,
                directionVector = null,
                confidence = 0.0,
                statusMessage = "Cue stick not detected — aim guidelines used.",
            )
        }

        // Aim direction points away from the stick through the cue ball
        val stickAngleRad = Math.toRadians(bestDeg.toDouble())
        val aimAngleRad = stickAngleRad + PI
        val aimAngleDeg = (Math.toDegrees(aimAngleRad) + 360.0) % 360.0

        val dirVec = Point2D(cos(aimAngleRad), sin(aimAngleRad))

        return CueStickResult(
            detected = true,
            angleDeg = aimAngleDeg,
            directionVector = dirVec,
            confidence = peakScore.coerceIn(0.5, 0.95),
            statusMessage = "Cue stick detected at %.1f°.".format(aimAngleDeg),
        )
    }
}
