package com.eightballpro.assistant.domain.vision

import kotlin.math.abs

data class Point2D(val x: Double, val y: Double)

/**
 * Maps table coordinates (u, v) in [0, 1] x [0, 1] to image pixels through four corners, using bilinear
 * interpolation. This is exact for an axis-aligned table and an approximation for a trapezoidal view.
 * Assumes the table is roughly planar and that the four corners are supplied by the user or the
 * table detector. Lens distortion is not modelled.
 */
class PerspectiveCalibration(
    val topLeft: Point2D,
    val topRight: Point2D,
    val bottomRight: Point2D,
    val bottomLeft: Point2D,
) {
    /** True when the corners form a non-degenerate convex quadrilateral in a consistent order. */
    fun isValid(): Boolean {
        val pts = listOf(topLeft, topRight, bottomRight, bottomLeft)
        var sign = 0
        for (i in pts.indices) {
            val a = pts[i]
            val b = pts[(i + 1) % 4]
            val c = pts[(i + 2) % 4]
            val cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x)
            if (abs(cross) < 1e-9) return false
            val s = if (cross > 0) 1 else -1
            if (sign == 0) sign = s else if (s != sign) return false
        }
        return true
    }

    fun toImage(u: Double, v: Double): Point2D = Point2D(
        x = (1 - u) * (1 - v) * topLeft.x + u * (1 - v) * topRight.x + u * v * bottomRight.x + (1 - u) * v * bottomLeft.x,
        y = (1 - u) * (1 - v) * topLeft.y + u * (1 - v) * topRight.y + u * v * bottomRight.y + (1 - u) * v * bottomLeft.y,
    )

    /**
     * Inverse mapping by Newton iteration. Returns null if it does not converge, which happens for
     * points far outside the table or for degenerate corners.
     */
    fun toNormalized(p: Point2D): Point2D? {
        var u = 0.5
        var v = 0.5
        val h = 1e-6
        for (iteration in 0 until MAX_ITERATIONS) {
            val f = toImage(u, v)
            val ex = f.x - p.x
            val ey = f.y - p.y
            if (abs(ex) + abs(ey) < TOLERANCE_PX) return Point2D(u, v)
            val fu = toImage(u + h, v)
            val fv = toImage(u, v + h)
            val a = (fu.x - f.x) / h
            val b = (fv.x - f.x) / h
            val c = (fu.y - f.y) / h
            val d = (fv.y - f.y) / h
            val det = a * d - b * c
            if (abs(det) < 1e-12) return null
            u -= (d * ex - b * ey) / det
            v -= (-c * ex + a * ey) / det
        }
        val f = toImage(u, v)
        return if (abs(f.x - p.x) + abs(f.y - p.y) < TOLERANCE_PX) Point2D(u, v) else null
    }

    companion object {
        private const val MAX_ITERATIONS = 50
        private const val TOLERANCE_PX = 1e-9

        /** Calibration matching the detected bounds. Uses half-open pixel edges, so the corners sit on the outer edge. */
        fun fromBounds(bounds: TableBounds): PerspectiveCalibration = PerspectiveCalibration(
            topLeft = Point2D(bounds.left.toDouble(), bounds.top.toDouble()),
            topRight = Point2D((bounds.right + 1).toDouble(), bounds.top.toDouble()),
            bottomRight = Point2D((bounds.right + 1).toDouble(), (bounds.bottom + 1).toDouble()),
            bottomLeft = Point2D(bounds.left.toDouble(), (bounds.bottom + 1).toDouble()),
        )
    }
}
