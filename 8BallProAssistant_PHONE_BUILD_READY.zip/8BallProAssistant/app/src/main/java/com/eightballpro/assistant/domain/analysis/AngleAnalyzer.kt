package com.eightballpro.assistant.domain.analysis

import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.table.PocketPosition
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class AngleAnalysis(
    val aimAngleDeg: Double,
    val cutAngleDeg: Double?,
    val impactAngleDeg: Double?,
    val reboundAngleDeg: Double?,
    val bankShotAngleDeg: Double?,
    val cueDeflectionAngleDeg: Double?,
    val targetBallId: Int?,
    val impactPoint: Vec3?,
    val targetPocket: PocketPosition?,
    val summaryText: String,
)

object AngleAnalyzer {

    fun analyze(
        cuePos: Vec3,
        aimDirection: Vec3,
        balls: List<PoolBall>,
        table: TableGeometry3D,
    ): AngleAnalysis {
        val dir = aimDirection.horizontal().normalizedOrZero()
        val aimAngleDeg = (Math.toDegrees(atan2(dir.y, dir.x)) + 360.0) % 360.0

        if (dir == Vec3.ZERO) {
            return AngleAnalysis(
                aimAngleDeg = 0.0,
                cutAngleDeg = null,
                impactAngleDeg = null,
                reboundAngleDeg = null,
                bankShotAngleDeg = null,
                cueDeflectionAngleDeg = null,
                targetBallId = null,
                impactPoint = null,
                targetPocket = null,
                summaryText = "Aim angle unavailable.",
            )
        }

        val radius = BallPhysics.RADIUS_M
        val objectBalls = balls.filter { !it.isCue && !it.pocketed }

        // Find first object ball along the aim ray
        var nearestObj: PoolBall? = null
        var minRayDist = Double.MAX_VALUE
        var nearestImpact: Vec3? = null

        for (obj in objectBalls) {
            val toObj = obj.position - cuePos
            val projDist = toObj.dot(dir)
            if (projDist <= 0.0) continue // Behind cue ball

            val perp = toObj - dir * projDist
            val perpDist = perp.length()

            // Collision occurs if perpendicular distance <= 2 * radius
            if (perpDist <= 2.0 * radius) {
                val backDist = sqrt((2.0 * radius) * (2.0 * radius) - perpDist * perpDist)
                val impactDist = projDist - backDist
                if (impactDist > 0.0 && impactDist < minRayDist) {
                    minRayDist = impactDist
                    nearestObj = obj
                    nearestImpact = cuePos + dir * impactDist
                }
            }
        }

        if (nearestObj == null || nearestImpact == null) {
            // Check cushion rebound angle along cue aim ray
            val cushionImpact = findCushionImpact(cuePos, dir, table)
            val reboundAngle = cushionImpact?.let { calculateReboundAngle(dir, it.second) }

            return AngleAnalysis(
                aimAngleDeg = aimAngleDeg,
                cutAngleDeg = null,
                impactAngleDeg = null,
                reboundAngleDeg = reboundAngle,
                bankShotAngleDeg = null,
                cueDeflectionAngleDeg = null,
                targetBallId = null,
                impactPoint = cushionImpact?.first,
                targetPocket = null,
                summaryText = "Aim: %.1f° | Straight to cushion.".format(aimAngleDeg),
            )
        }

        // Object ball collision geometry
        val ghostPos = nearestImpact
        val objPos = nearestObj.position
        val objToTargetDir = (objPos - ghostPos).horizontal().normalizedOrZero()

        // Cut angle between cue aim direction and object ball line of centers
        val dotCut = dir.dot(objToTargetDir).coerceIn(-1.0, 1.0)
        val cutAngleDeg = Math.toDegrees(acos(dotCut))

        // Impact angle (complement of cut angle)
        val impactAngleDeg = (90.0 - cutAngleDeg).coerceAtLeast(0.0)

        // Cue ball deflection angle (tangent line ~ 90° - cutAngle for elastic collision)
        val cueDeflectionAngleDeg = (90.0 - cutAngleDeg).coerceAtLeast(0.0)

        // Find nearest pocket along object ball travel direction
        val (targetPocket, bankAngle) = findObjectTargetPocket(objPos, objToTargetDir, table)

        val summary = "Aim: %.1f° | Cut: %.1f° | Impact: %.1f° | Target Ball: %d".format(
            aimAngleDeg, cutAngleDeg, impactAngleDeg, nearestObj.id,
        )

        return AngleAnalysis(
            aimAngleDeg = aimAngleDeg,
            cutAngleDeg = cutAngleDeg,
            impactAngleDeg = impactAngleDeg,
            reboundAngleDeg = null,
            bankShotAngleDeg = bankAngle,
            cueDeflectionAngleDeg = cueDeflectionAngleDeg,
            targetBallId = nearestObj.id,
            impactPoint = nearestImpact,
            targetPocket = targetPocket,
            summaryText = summary,
        )
    }

    private fun findCushionImpact(cuePos: Vec3, dir: Vec3, table: TableGeometry3D): Pair<Vec3, Vec3>? {
        for (cushion in table.cushions) {
            val crossing = cushion.crossing(cuePos)
            val proj = dir.dot(cushion.inwardNormal)
            if (proj < 0.0) {
                val dist = crossing / (-proj)
                if (dist > 0.0) {
                    val hitPos = cuePos + dir * dist
                    return hitPos to cushion.inwardNormal
                }
            }
        }
        return null
    }

    private fun calculateReboundAngle(inDir: Vec3, normal: Vec3): Double {
        val dot = inDir.dot(normal).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(abs(dot)))
    }

    private fun findObjectTargetPocket(
        objPos: Vec3,
        objDir: Vec3,
        table: TableGeometry3D,
    ): Pair<PocketPosition?, Double?> {
        var bestPocket: PocketPosition? = null
        var maxDot = -1.0

        for (pocket in table.pockets) {
            val pocketPos = Vec3(pocket.x, pocket.y, BallPhysics.RADIUS_M)
            val toPocket = (pocketPos - objPos).horizontal().normalizedOrZero()
            val dot = objDir.dot(toPocket)
            if (dot > maxDot && dot > 0.7) { // Within ~45° cone
                maxDot = dot
                bestPocket = pocket.name
            }
        }

        val bankAngle = if (bestPocket != null) Math.toDegrees(acos(maxDot.coerceIn(-1.0, 1.0))) else null
        return bestPocket to bankAngle
    }
}
