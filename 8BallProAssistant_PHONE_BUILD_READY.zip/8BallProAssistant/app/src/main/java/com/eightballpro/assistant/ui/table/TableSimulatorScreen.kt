@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.table

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.CUE_BALL_ID
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.ShotResult
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.spin.SpinContactPoint
import com.eightballpro.assistant.domain.table.TableSpec
import com.eightballpro.assistant.ui.common.ScreenScaffold
import com.eightballpro.assistant.ui.settings.SettingsViewModel

private val FrameColor = Color(0xFF1B2A44)
private val FeltColor = Color(0xFF1F6FB2)
private val GuideColor = Color(0x66FFFFFF)
private val PocketColor = Color(0xFF05080F)
private val PocketZoneColor = Color(0x33FFFFFF)
private val AimColor = Color(0xFFF2C14E)
private val BallPalette = listOf(
    Color(0xFFFFFFFF), // 0 cue
    Color(0xFFF2C14E), // 1
    Color(0xFF2F6FD1), // 2
    Color(0xFFE5484D), // 3
    Color(0xFF7C4DFF), // 4
    Color(0xFFFF8A3D), // 5
    Color(0xFF3DDC97), // 6
    Color(0xFF7A2E2E), // 7
    Color(0xFF111111), // 8
    Color(0xFFF5E08A), // 9
    Color(0xFF8FB8F0), // 10
    Color(0xFFFF9AA2), // 11
    Color(0xFFB99CFF), // 12
    Color(0xFFFFC28A), // 13
    Color(0xFFA6F0CF), // 14
    Color(0xFFB07A7A), // 15
)

private val SPIN_GRID = listOf(
    SpinContactPoint.TOP_LEFT, SpinContactPoint.TOP_SPIN, SpinContactPoint.TOP_RIGHT,
    SpinContactPoint.LEFT_SPIN, SpinContactPoint.CENTER, SpinContactPoint.RIGHT_SPIN,
    SpinContactPoint.BOTTOM_LEFT, SpinContactPoint.BACK_SPIN, SpinContactPoint.BOTTOM_RIGHT,
)

private fun spinLabel(point: SpinContactPoint): String = when (point) {
    SpinContactPoint.TOP_LEFT -> "TL"
    SpinContactPoint.TOP_SPIN -> "Top"
    SpinContactPoint.TOP_RIGHT -> "TR"
    SpinContactPoint.LEFT_SPIN -> "Left"
    SpinContactPoint.CENTER -> "Centre"
    SpinContactPoint.RIGHT_SPIN -> "Right"
    SpinContactPoint.BOTTOM_LEFT -> "BL"
    SpinContactPoint.BACK_SPIN -> "Back"
    SpinContactPoint.BOTTOM_RIGHT -> "BR"
}

private fun ballColor(id: Int): Color = BallPalette.getOrElse(id) { Color(0xFFB0B8C8) }

/** Maps table metres to canvas pixels and back. */
private class TableViewport(canvasWidth: Float, canvasHeight: Float, private val table: TableGeometry3D) {
    private val inset = 24f
    val scale: Float = minOf(
        (canvasWidth - 2 * inset) / table.length.toFloat(),
        (canvasHeight - 2 * inset) / table.width.toFloat(),
    )
    private val originX = (canvasWidth - table.length.toFloat() * scale) / 2f
    private val originY = (canvasHeight - table.width.toFloat() * scale) / 2f

    fun toScreen(x: Double, y: Double): Offset = Offset(originX + x.toFloat() * scale, originY + y.toFloat() * scale)
    fun toTableX(px: Float): Double = ((px - originX) / scale).toDouble()
    fun toTableY(py: Float): Double = ((py - originY) / scale).toDouble()
    fun radiusPx(meters: Double): Float = (meters * scale).toFloat()
}

@Composable
fun TableSimulatorScreen(
    onBack: () -> Unit,
    settingsViewModel: SettingsViewModel = viewModel(),
    tableViewModel: TableViewModel = viewModel(),
) {
    val settings by settingsViewModel.settings.collectAsStateWithLifecycle()
    val uiState by tableViewModel.state.collectAsStateWithLifecycle()
    val table = remember { TableGeometry3D.from(TableSpec.NINE_FOOT) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var playTime by remember { mutableDoubleStateOf(0.0) }
    val shot = uiState.shot

    // Plays back the latest shot in real time, or jumps to the end for previews.
    LaunchedEffect(uiState.shotVersion) {
        val current = shot ?: return@LaunchedEffect
        if (!uiState.animate) {
            playTime = current.duration
            return@LaunchedEffect
        }
        playTime = 0.0
        var last = withFrameNanos { it }
        while (playTime < current.duration) {
            val now = withFrameNanos { it }
            playTime += (now - last) / 1e9
            last = now
        }
        playTime = current.duration
    }

    val playIndex = shot?.let { (playTime / it.sampleInterval).toInt().coerceIn(0, it.frames.lastIndex) } ?: 0
    val shownPositions: List<Pair<Int, Vec3>> = if (shot != null) {
        shot.frames[playIndex].positions.map { (id, p) -> id to p }
    } else {
        uiState.balls.filter { !it.pocketed }.map { it.id to it.position }
    }

    ScreenScaffold(title = "Pool Table Simulator", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { InfoCard(table) }
            item {
                TableSurface(
                    table = table,
                    uiState = uiState,
                    shot = shot,
                    shownPositions = shownPositions,
                    playIndex = playIndex,
                    showGuides = settings.showGuideLines,
                    canvasSize = canvasSize,
                    onSizeChanged = { canvasSize = it },
                    onTap = { tableViewModel.onTableTap(it) },
                    onAim = { tableViewModel.setAimTarget(it) },
                )
            }
            item { ModeRow(uiState.mode) { tableViewModel.setMode(it) } }
            item { ControlsCard(uiState, tableViewModel) }
            item { ShotActions(uiState, tableViewModel) }
            item { ShotSummary(uiState, shot) }
        }
    }
}

@Composable
private fun InfoCard(table: TableGeometry3D) {
    val spec = TableSpec.NINE_FOOT
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Standard 9-foot table", style = MaterialTheme.typography.titleMedium)
            Spacer8()
            Text(
                "Playing surface: ${spec.playingLengthMm.toInt()} x ${spec.playingWidthMm.toInt()} mm  |  " +
                    "Pockets: ${table.pockets.size}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "3D engine: positions, velocities and spin in metres and seconds. Set the cue ball, add balls, " +
                    "aim by dragging on the table, then shoot.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun Spacer8() = androidx.compose.foundation.layout.Spacer(Modifier.height(4.dp))

@Composable
private fun TableSurface(
    table: TableGeometry3D,
    uiState: TableUiState,
    shot: ShotResult?,
    shownPositions: List<Pair<Int, Vec3>>,
    playIndex: Int,
    showGuides: Boolean,
    canvasSize: IntSize,
    onSizeChanged: (IntSize) -> Unit,
    onTap: (Vec3) -> Unit,
    onAim: (Vec3) -> Unit,
) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(320.dp)
            .onSizeChanged(onSizeChanged)
            .pointerInput(uiState.mode, canvasSize) {
                detectTapGestures(onTap = { offset ->
                    val vp = TableViewport(canvasSize.width.toFloat(), canvasSize.height.toFloat(), table)
                    if (vp.scale > 0f) onTap(Vec3(vp.toTableX(offset.x), vp.toTableY(offset.y), BallPhysics.RADIUS_M))
                })
            }
            .pointerInput(uiState.mode, canvasSize) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val vp = TableViewport(canvasSize.width.toFloat(), canvasSize.height.toFloat(), table)
                        if (vp.scale > 0f) onAim(Vec3(vp.toTableX(offset.x), vp.toTableY(offset.y), 0.0))
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val vp = TableViewport(canvasSize.width.toFloat(), canvasSize.height.toFloat(), table)
                        if (vp.scale > 0f) onAim(Vec3(vp.toTableX(change.position.x), vp.toTableY(change.position.y), 0.0))
                    },
                )
            },
    ) {
        val vp = TableViewport(size.width, size.height, table)
        if (vp.scale <= 0f) return@Canvas

        val origin = vp.toScreen(0.0, 0.0)
        val far = vp.toScreen(table.length, table.width)
        val tableSize = Size(far.x - origin.x, far.y - origin.y)

        drawRoundRect(
            color = FrameColor,
            topLeft = origin - Offset(18f, 18f),
            size = Size(tableSize.width + 36f, tableSize.height + 36f),
            cornerRadius = CornerRadius(18f),
        )
        drawRect(color = FeltColor, topLeft = origin, size = tableSize)

        if (showGuides) {
            val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
            val midX = origin.x + tableSize.width / 2f
            val midY = origin.y + tableSize.height / 2f
            drawLine(GuideColor, Offset(midX, origin.y), Offset(midX, origin.y + tableSize.height), 2f, pathEffect = dash)
            drawLine(GuideColor, Offset(origin.x, midY), Offset(origin.x + tableSize.width, midY), 2f, pathEffect = dash)
        }

        table.pockets.forEach { pocket ->
            val center = vp.toScreen(pocket.x, pocket.y)
            drawCircle(PocketZoneColor, vp.radiusPx(pocket.captureRadius), center)
            drawCircle(PocketColor, 10f, center)
        }

        // Trajectories: the path each ball has taken up to the current playback position.
        if (shot != null && uiState.showTrajectories) {
            val ids = shot.frames.flatMap { it.positions.keys }.toSet()
            for (id in ids) {
                val path = Path()
                var started = false
                for (k in 0..playIndex) {
                    val p = shot.frames[k].positions[id] ?: continue
                    val o = vp.toScreen(p.x, p.y)
                    if (!started) {
                        path.moveTo(o.x, o.y)
                        started = true
                    } else {
                        path.lineTo(o.x, o.y)
                    }
                }
                if (started) drawPath(path, ballColor(id).copy(alpha = 0.7f), style = Stroke(width = 2f))
            }
        }

        // Aim line, shown when there is no shot to display.
        val cue = uiState.balls.firstOrNull { it.isCue && !it.pocketed }
        val target = uiState.aimTarget
        if (shot == null && uiState.mode == EditMode.AIM && cue != null && target != null) {
            val dir = (target - cue.position).horizontal().normalizedOrZero()
            if (dir != Vec3.ZERO) {
                val from = vp.toScreen(cue.position.x, cue.position.y)
                val to = vp.toScreen(cue.position.x + dir.x * 0.8, cue.position.y + dir.y * 0.8)
                drawLine(AimColor, from, to, 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
            }
        }

        val ballRadius = maxOf(vp.radiusPx(BallPhysics.RADIUS_M), 3f)
        shownPositions.forEach { (id, p) ->
            drawCircle(ballColor(id), ballRadius, vp.toScreen(p.x, p.y))
        }
    }
}

@Composable
private fun ModeRow(mode: EditMode, onMode: (EditMode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        EditMode.entries.forEach { m ->
            FilterChip(
                selected = mode == m,
                onClick = { onMode(m) },
                label = { Text(m.label) },
            )
        }
    }
}

@Composable
private fun ControlsCard(uiState: TableUiState, vm: TableViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Cue-ball contact point", style = MaterialTheme.typography.titleMedium)
            SpinGrid(selected = uiState.spin, onSelect = { vm.setSpin(it) })
            LabeledSlider(
                label = "Spin intensity",
                value = uiState.spinIntensity,
                range = 0.0..1.0,
                onChange = { vm.setSpinIntensity(it) },
                format = { "%.2f".format(it) },
            )
            LabeledSlider(
                label = "Power",
                value = uiState.power,
                range = 0.0..1.0,
                onChange = { vm.setPower(it) },
                format = { "%.2f m/s".format(vm.speedMetersPerSecond(it)) },
            )
            LabeledSlider(
                label = "Cue elevation",
                value = uiState.elevationDeg,
                range = -15.0..15.0,
                onChange = { vm.setElevationDeg(it) },
                format = { "%.0f deg".format(it) },
            )
        }
    }
}

@Composable
private fun SpinGrid(selected: SpinContactPoint, onSelect: (SpinContactPoint) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SPIN_GRID.chunked(3).forEach { rowPoints ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rowPoints.forEach { point ->
                    val label = spinLabel(point)
                    if (point == selected) {
                        FilledTonalButton(onClick = { onSelect(point) }, modifier = Modifier.weight(1f)) { Text(label) }
                    } else {
                        OutlinedButton(onClick = { onSelect(point) }, modifier = Modifier.weight(1f)) { Text(label) }
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Double,
    range: ClosedFloatingPointRange<Double>,
    onChange: (Double) -> Unit,
    format: (Double) -> String,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(format(value), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.tertiary)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toDouble()) },
            valueRange = range.start.toFloat()..range.endInclusive.toFloat(),
        )
    }
}

@Composable
private fun ShotActions(uiState: TableUiState, vm: TableViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.shoot(animate = true) },
                enabled = !uiState.isSimulating,
                modifier = Modifier.weight(1f),
            ) { Text("Shoot") }
            OutlinedButton(
                onClick = { vm.shoot(animate = false) },
                enabled = !uiState.isSimulating,
                modifier = Modifier.weight(1f),
            ) { Text("Preview path") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { vm.keepShotResult() },
                enabled = uiState.shot != null,
                modifier = Modifier.weight(1f),
            ) { Text("Use result") }
            OutlinedButton(
                onClick = { vm.clearShot() },
                enabled = uiState.shot != null,
                modifier = Modifier.weight(1f),
            ) { Text("Clear shot") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.resetLayout() }, modifier = Modifier.weight(1f)) { Text("Reset layout") }
            FilterChip(
                selected = uiState.showTrajectories,
                onClick = { vm.setShowTrajectories(!uiState.showTrajectories) },
                label = { Text("Trails") },
            )
        }
    }
}

@Composable
private fun ShotSummary(uiState: TableUiState, shot: ShotResult?) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        uiState.message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
        if (uiState.isSimulating) {
            Text("Simulating...", style = MaterialTheme.typography.bodyMedium)
        }
        if (shot != null) {
            Text(
                "Cue ball travel: %.2f m  |  Duration: %.2f s".format(shot.cueDistance, shot.duration),
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Ball collisions: ${shot.collisionCount}  |  Cushion impacts: ${shot.cushionCount}",
                style = MaterialTheme.typography.bodyMedium,
            )
            val pocketed = shot.pocketed.joinToString { "ball ${it.ballId} into ${it.pocket.toString().lowercase()}" }
            Text(
                if (pocketed.isEmpty()) "No balls pocketed." else "Pocketed: $pocketed",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (shot.cuePocketed) {
                Text("Scratch: the cue ball was pocketed.", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
