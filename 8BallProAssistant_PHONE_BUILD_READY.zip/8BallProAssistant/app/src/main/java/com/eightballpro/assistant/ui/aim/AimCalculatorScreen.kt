@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.aim

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.ui.common.ScreenScaffold
import kotlin.math.acos

@Composable
fun AimCalculatorScreen(onBack: () -> Unit) {
    var cueU by remember { mutableDoubleStateOf(0.2) }
    var cueV by remember { mutableDoubleStateOf(0.5) }
    var objU by remember { mutableDoubleStateOf(0.6) }
    var objV by remember { mutableDoubleStateOf(0.4) }
    var pocketU by remember { mutableDoubleStateOf(1.0) }
    var pocketV by remember { mutableDoubleStateOf(0.0) }

    val tableLen = 2.54
    val tableWidth = 1.27
    val radius = BallPhysics.RADIUS_M

    val cuePos = Vec3(cueU * tableLen, cueV * tableWidth, radius)
    val objPos = Vec3(objU * tableLen, objV * tableWidth, radius)
    val pocketPos = Vec3(pocketU * tableLen, pocketV * tableWidth, radius)

    // Ghost ball is 2*radius back from object ball along the object-to-pocket line
    val objToPocket = (pocketPos - objPos).horizontal().normalizedOrZero()
    val ghostPos = objPos - objToPocket * (2.0 * radius)

    // Aim direction from cue ball to ghost ball
    val cueToGhost = (ghostPos - cuePos).horizontal().normalizedOrZero()

    // Cut angle between cue-to-ghost line and object-to-pocket line
    val dot = (cueToGhost.dot(objToPocket)).coerceIn(-1.0, 1.0)
    val cutAngleDeg = Math.toDegrees(acos(dot))

    ScreenScaffold(title = "Aim Calculator (Ghost-Ball)", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    text = "Ghost-Ball Geometry & Collision Prediction",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            item {
                AimCanvas(
                    cuePos = cuePos,
                    objPos = objPos,
                    ghostPos = ghostPos,
                    pocketPos = pocketPos,
                    tableLen = tableLen,
                    tableWidth = tableWidth,
                )
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Position Sliders (Table Normalized Coordinates)", style = MaterialTheme.typography.titleMedium)

                        Text("Cue Ball U: %.2f".format(cueU), style = MaterialTheme.typography.bodySmall)
                        Slider(value = cueU.toFloat(), onValueChange = { cueU = it.toDouble() }, valueRange = 0.05f..0.95f)

                        Text("Object Ball U: %.2f".format(objU), style = MaterialTheme.typography.bodySmall)
                        Slider(value = objU.toFloat(), onValueChange = { objU = it.toDouble() }, valueRange = 0.05f..0.95f)

                        Text("Object Ball V: %.2f".format(objV), style = MaterialTheme.typography.bodySmall)
                        Slider(value = objV.toFloat(), onValueChange = { objV = it.toDouble() }, valueRange = 0.05f..0.95f)
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Calculated Aim Data", style = MaterialTheme.typography.titleMedium)
                        Text("Cut Angle: %.1f°".format(cutAngleDeg), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        Text("Ghost Ball Center: (%.3f m, %.3f m)".format(ghostPos.x, ghostPos.y), style = MaterialTheme.typography.bodySmall)
                        Text("Cue Aim Vector: (%.3f, %.3f)".format(cueToGhost.x, cueToGhost.y), style = MaterialTheme.typography.bodySmall)
                        Text("Distance to Contact: %.3f m".format((ghostPos - cuePos).length()), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun AimCanvas(
    cuePos: Vec3,
    objPos: Vec3,
    ghostPos: Vec3,
    pocketPos: Vec3,
    tableLen: Double,
    tableWidth: Double,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(2.0f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1F6FB2)),
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val scaleX = size.width / tableLen.toFloat()
            val scaleY = size.height / tableWidth.toFloat()

            fun map(p: Vec3): Offset = Offset(p.x.toFloat() * scaleX, p.y.toFloat() * scaleY)

            val cScreen = map(cuePos)
            val oScreen = map(objPos)
            val gScreen = map(ghostPos)
            val pScreen = map(pocketPos)

            val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))

            // Cue to Ghost line
            drawLine(Color.Yellow, cScreen, gScreen, strokeWidth = 3f, pathEffect = dash)
            // Object to Pocket line
            drawLine(Color.Green, oScreen, pScreen, strokeWidth = 3f)

            // Draw balls
            drawCircle(Color.White, radius = 14f, center = cScreen)
            drawCircle(Color.Red, radius = 14f, center = oScreen)
            drawCircle(Color.White.copy(alpha = 0.4f), radius = 14f, center = gScreen)
            drawCircle(Color.Black, radius = 18f, center = pScreen)
        }
    }
}
