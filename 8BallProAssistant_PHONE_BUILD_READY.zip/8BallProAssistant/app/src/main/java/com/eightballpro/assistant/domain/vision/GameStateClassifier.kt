package com.eightballpro.assistant.domain.vision

enum class GameState {
    LIVE_MATCH,
    TABLE_EDITOR,
    MENU,
    LOADING,
    UNKNOWN,
}

data class GameStateResult(
    val state: GameState,
    val confidence: Double,
    val description: String,
)

/**
 * Classifies captured screen frames into game states: LIVE_MATCH, TABLE_EDITOR, MENU, LOADING, or UNKNOWN.
 * Live prediction engine runs ONLY when state is LIVE_MATCH.
 */
object GameStateClassifier {

    fun classify(
        image: ArgbImage,
        bounds: TableBounds?,
        felt: ColorProfile,
    ): GameStateResult {
        if (bounds == null) {
            return GameStateResult(
                state = GameState.MENU,
                confidence = 0.9,
                description = "Menu or home screen — table not detected.",
            )
        }

        if (bounds.feltCoverage < 0.45) {
            return GameStateResult(
                state = GameState.LOADING,
                confidence = 0.85,
                description = "Loading or transition screen — felt coverage low.",
            )
        }

        val w = image.width
        val topRegionHeight = bounds.top.coerceAtLeast(10)
        var topUiPixelCount = 0
        var totalTopPixels = 0

        // Inspect top bar area above table bounds for Table Editor UI buttons (e.g., Edit, Rewind, Save buttons)
        for (y in 0 until topRegionHeight) {
            for (x in 0 until w) {
                totalTopPixels++
                val p = image.pixelAt(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF

                // Check for high-contrast UI buttons (orange/blue/white editor action buttons)
                if ((r > 200 && g in 60..180 && b < 100) || (b > 180 && r < 100) || (r > 220 && g > 220 && b > 220)) {
                    topUiPixelCount++
                }
            }
        }

        val topUiRatio = if (totalTopPixels > 0) topUiPixelCount.toDouble() / totalTopPixels else 0.0

        // In 8 Ball Pool Table Editor / Customization screen, top bar is packed with editor controls
        if (topUiRatio > 0.18) {
            return GameStateResult(
                state = GameState.TABLE_EDITOR,
                confidence = 0.9,
                description = "Table Editor screen detected — Live prediction disabled.",
            )
        }

        return GameStateResult(
            state = GameState.LIVE_MATCH,
            confidence = 0.95,
            description = "Active Live Match detected.",
        )
    }
}
