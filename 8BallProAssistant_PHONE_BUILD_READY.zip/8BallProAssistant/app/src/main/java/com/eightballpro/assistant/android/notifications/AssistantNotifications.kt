package com.eightballpro.assistant.android.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.eightballpro.assistant.MainActivity
import com.eightballpro.assistant.R
import com.eightballpro.assistant.android.capture.ScreenCaptureService

object AssistantNotifications {

    const val CHANNEL_OVERLAY = "assistant_overlay"
    const val CHANNEL_CAPTURE = "assistant_capture"

    fun ensureChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_OVERLAY, "Floating assistant", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows that the floating assistant is running"
            },
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_CAPTURE, "Screen capture", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Shown while screen capture is active"
            },
        )
    }

    fun overlay(context: Context): Notification =
        NotificationCompat.Builder(context, CHANNEL_OVERLAY)
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentTitle("8 Ball Pro Assistant")
            .setContentText("Floating assistant is running")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent(context))
            .build()

    fun capture(context: Context): Notification =
        NotificationCompat.Builder(context, CHANNEL_CAPTURE)
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentTitle("Screen capture active")
            .setContentText("The assistant is reading the screen you shared.")
            .setOngoing(true)
            .addAction(0, "Stop capture", stopCaptureIntent(context))
            .setContentIntent(openAppIntent(context))
            .build()

    private fun openAppIntent(context: Context): PendingIntent = PendingIntent.getActivity(
        context,
        0,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun stopCaptureIntent(context: Context): PendingIntent = PendingIntent.getService(
        context,
        1,
        Intent(context, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
}
