package com.eightballpro.assistant.domain.mode

/**
 * MODE A: a game the developer owns, or an explicitly authorised test environment. Live capture allowed.
 * MODE B: a third-party game. Only user-selected screenshots are analysed. No live capture or live overlay analysis.
 */
enum class GameMode { OWN_GAME_AUTHORIZED, THIRD_PARTY_SCREENSHOT }

/** Explicit user acknowledgement that the game is their own or an authorised test environment. */
data class Authorization(val ownGameAcknowledged: Boolean)

data class ModeCapabilities(
    val liveCapture: Boolean,
    val liveAnalysis: Boolean,
    val screenshotImport: Boolean,
    val offlinePractice: Boolean,
)

sealed interface PolicyDecision {
    data object Allowed : PolicyDecision
    data class Denied(val reason: String) : PolicyDecision
}

object ModePolicy {

    fun capabilities(mode: GameMode): ModeCapabilities = when (mode) {
        GameMode.OWN_GAME_AUTHORIZED -> ModeCapabilities(
            liveCapture = true,
            liveAnalysis = true,
            screenshotImport = true,
            offlinePractice = true,
        )
        GameMode.THIRD_PARTY_SCREENSHOT -> ModeCapabilities(
            liveCapture = false,
            liveAnalysis = false,
            screenshotImport = true,
            offlinePractice = true,
        )
    }

    /** Live capture is only allowed in Mode A, and only after the user has acknowledged authorisation. */
    fun decideLiveCapture(mode: GameMode, authorization: Authorization): PolicyDecision = when {
        mode == GameMode.THIRD_PARTY_SCREENSHOT ->
            PolicyDecision.Denied("Live capture is not available for third-party games. Import a screenshot instead.")
        !authorization.ownGameAcknowledged ->
            PolicyDecision.Denied("Confirm that this is your own game or an authorised test environment first.")
        else -> PolicyDecision.Allowed
    }
}
