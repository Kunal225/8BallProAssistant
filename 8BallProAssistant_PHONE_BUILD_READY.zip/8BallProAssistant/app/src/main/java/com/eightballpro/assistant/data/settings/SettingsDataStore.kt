package com.eightballpro.assistant.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.settings.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "app_settings")

private object Keys {
    val SLIDING_FRICTION = doublePreferencesKey("physics_sliding_friction")
    val ROLLING_FRICTION = doublePreferencesKey("physics_rolling_friction")
    val CUSHION_RESTITUTION = doublePreferencesKey("physics_cushion_restitution")
    val BALL_RESTITUTION = doublePreferencesKey("physics_ball_restitution")
    val BALL_FRICTION = doublePreferencesKey("physics_ball_friction")
    val CLOTH_RESTITUTION = doublePreferencesKey("physics_cloth_restitution")
    val SHOW_GUIDE_LINES = booleanPreferencesKey("show_guide_lines")
    val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
}

/**
 * Maps stored preferences to settings. Missing keys use defaults. If the stored physics values are
 * out of range, the whole physics block falls back to defaults rather than producing an invalid configuration.
 */
internal fun Preferences.toAppSettings(): AppSettings {
    val d = PhysicsConfig.DEFAULT
    val physics = runCatching {
        PhysicsConfig(
            slidingFriction = this[Keys.SLIDING_FRICTION] ?: d.slidingFriction,
            rollingFriction = this[Keys.ROLLING_FRICTION] ?: d.rollingFriction,
            cushionRestitution = this[Keys.CUSHION_RESTITUTION] ?: d.cushionRestitution,
            ballRestitution = this[Keys.BALL_RESTITUTION] ?: d.ballRestitution,
            ballFriction = this[Keys.BALL_FRICTION] ?: d.ballFriction,
            clothRestitution = this[Keys.CLOTH_RESTITUTION] ?: d.clothRestitution,
        )
    }.getOrDefault(d)
    return AppSettings(
        physics = physics,
        showGuideLines = this[Keys.SHOW_GUIDE_LINES] ?: true,
        keepScreenOn = this[Keys.KEEP_SCREEN_ON] ?: false,
    )
}

class SettingsRepository(private val dataStore: DataStore<Preferences>) {

    val settings: Flow<AppSettings> = dataStore.data.map { it.toAppSettings() }

    /**
     * Applies [transform] to the stored physics config inside a single transactional edit, so
     * concurrent slider updates cannot overwrite each other with stale values.
     * Returns failure if [transform] throws (for example, an out-of-range value); nothing is stored then.
     */
    suspend fun updatePhysics(transform: (PhysicsConfig) -> PhysicsConfig): Result<Unit> = runCatching {
        dataStore.edit { prefs: MutablePreferences ->
            val next = transform(prefs.toAppSettings().physics)
            prefs[Keys.SLIDING_FRICTION] = next.slidingFriction
            prefs[Keys.ROLLING_FRICTION] = next.rollingFriction
            prefs[Keys.CUSHION_RESTITUTION] = next.cushionRestitution
            prefs[Keys.BALL_RESTITUTION] = next.ballRestitution
            prefs[Keys.BALL_FRICTION] = next.ballFriction
            prefs[Keys.CLOTH_RESTITUTION] = next.clothRestitution
        }
        Unit
    }

    suspend fun setShowGuideLines(value: Boolean) {
        dataStore.edit { it[Keys.SHOW_GUIDE_LINES] = value }
    }

    suspend fun setKeepScreenOn(value: Boolean) {
        dataStore.edit { it[Keys.KEEP_SCREEN_ON] = value }
    }
}
