package com.eightballpro.assistant.domain.physics3d

const val CUE_BALL_ID = 0

/**
 * Solid-sphere pool ball constants in SI units. Standard 2.25-inch ball, 0.17 kg.
 * The impulse factors come from the contact mechanics used in ContactSolver:
 * - Two equal solid spheres: the tangential effective mass is 2m/7, so the impulse that stops
 *   a relative slip of u is m*u/7.
 * - A sphere against a rigid surface: the tangential effective mass is 2m/7 (7m/2 inverse), so the
 *   impulse is 2*m*u/7.
 */
object BallPhysics {
    const val MASS_KG = 0.17
    const val RADIUS_M = 0.028575
    const val INERTIA = 0.4 * MASS_KG * RADIUS_M * RADIUS_M
    const val GRAVITY = 9.81
    const val PAIR_SLIP_IMPULSE_FACTOR = 1.0 / 7.0
    const val SINGLE_SLIP_IMPULSE_FACTOR = 2.0 / 7.0
}

/** Full dynamic state of one ball. Pocketed balls are kept in the list but excluded from physics. */
data class PoolBall(
    val id: Int,
    val position: Vec3,
    val velocity: Vec3 = Vec3.ZERO,
    val angularVelocity: Vec3 = Vec3.ZERO,
    val pocketed: Boolean = false,
) {
    val isCue: Boolean get() = id == CUE_BALL_ID
}
