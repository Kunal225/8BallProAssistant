package com.eightballpro.assistant.android.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.eightballpro.assistant.android.AssistantController
import com.eightballpro.assistant.android.notifications.AssistantNotifications

/**
 * Foreground service that owns the floating assistant window. It is not sticky: if the process is killed,
 * the bubble does not come back without the user opening it, and capture is never restarted on its own.
 */
class OverlayService : Service() {

    private var overlay: OverlayWindowController? = null

    override fun onCreate() {
        super.onCreate()
        AssistantNotifications.ensureChannels(this)
        try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                AssistantNotifications.overlay(this),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
            )
        } catch (e: RuntimeException) {
            // For example, a missing foreground-service permission. Stop cleanly instead of crashing.
            stopSelf()
            return
        }
        isRunning = true
        val controller = OverlayWindowController(this) { stopSelf() }
        if (controller.show()) {
            overlay = controller
        } else {
            controller.destroy()
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        overlay?.onConfigurationChanged()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        overlay?.destroy()
        overlay = null
        isRunning = false
        AssistantController.onOverlayStopped(applicationContext)
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 1001

        /** True between onCreate and onDestroy. Read by the UI to show the current state. */
        @Volatile
        var isRunning: Boolean = false

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}
