package com.eightballpro.assistant.domain.vision

import kotlin.math.abs
import kotlin.math.cbrt
import kotlin.math.min

enum class Confidence { HIGH, MEDIUM, LOW, UNCERTAIN, USER_CONFIRMED }

/** Score in [0, 1] with reasons. A score is a heuristic ranking, not a measured probability. */
data class Assessment(val score: Double, val level: Confidence, val reasons: List<String>)

object ConfidenceEvaluator {

    private const val ROUND_FILL_TARGET = 0.69
    private const val ROUND_FILL_TOLERANCE = 0.2
    private const val SIZE_TOLERANCE = 0.4
    private const val ASPECT_TARGET = 2.0
    private const val ASPECT_TOLERANCE = 0.5

    fun ballAssessment(
        blob: RawBlob,
        expectedRadiusPx: Double,
        classification: ClassifiedBall,
        insidePlayArea: Boolean,
    ): Assessment {
        val reasons = mutableListOf<String>()
        val roundness = 1.0 - min(1.0, abs(blob.fillRatio - ROUND_FILL_TARGET) / ROUND_FILL_TOLERANCE)
        if (roundness < 0.5) reasons += "shape is not close to a circle"

        val aspectRatio = blob.boxWidth.toDouble() / blob.boxHeight.coerceAtLeast(1)
        val aspectScore = 1.0 - min(1.0, abs(aspectRatio - 1.0) / 0.4)
        if (aspectScore < 0.5) reasons += "bounding box is not square"

        val sizeRatio = blob.radiusPx / expectedRadiusPx
        val sizeScore = 1.0 - min(1.0, abs(sizeRatio - 1.0) / SIZE_TOLERANCE)
        if (sizeScore < 0.5) reasons += "size differs from the expected ball size (ratio %.2f)".format(sizeRatio)

        if (classification.cls == BallClass.UNCERTAIN) reasons += "colour does not clearly identify the ball"
        if (!insidePlayArea) reasons += "centre lies outside the playing area"

        val shapeQuality = (roundness * aspectScore).coerceIn(0.0, 1.0)
        val combined = cbrt(shapeQuality * sizeScore * classification.confidence)
        val score = if (insidePlayArea) combined else combined * 0.5
        val level = levelFor(score, classification.cls == BallClass.UNCERTAIN)
        return Assessment(score, level, reasons)
    }

    fun tableAssessment(bounds: TableBounds): Assessment {
        val reasons = mutableListOf<String>()
        if (bounds.feltCoverage < 0.7) reasons += "table area is not uniformly felt-coloured"
        val aspectScore = 1.0 - min(1.0, abs(bounds.aspectRatio - ASPECT_TARGET) / ASPECT_TOLERANCE)
        if (aspectScore < 0.5) reasons += "table aspect ratio is not close to 2:1"
        val score = bounds.feltCoverage * (0.5 + 0.5 * aspectScore)
        return Assessment(score, levelFor(score, uncertain = false), reasons)
    }

    private fun levelFor(score: Double, uncertain: Boolean): Confidence = when {
        uncertain -> Confidence.UNCERTAIN
        score >= 0.75 -> Confidence.HIGH
        score >= 0.5 -> Confidence.MEDIUM
        score >= 0.25 -> Confidence.LOW
        else -> Confidence.UNCERTAIN
    }
}
