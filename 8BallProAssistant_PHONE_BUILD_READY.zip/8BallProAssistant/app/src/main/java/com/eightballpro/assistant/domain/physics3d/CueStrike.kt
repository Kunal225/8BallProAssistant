package com.eightballpro.assistant.domain.physics3d

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Cue impulse applied to a ball. This is an idealised impulse model. It does not model cue tip
 * compliance, squirt, or the cue's contact duration.
 *
 * Conventions (looking along the shot with z up):
 * - heightOffset: +1 = top of ball (top spin / follow), -1 = bottom (back spin / draw).
 * - sideOffset: +1 = right of the shot line, -1 = left.
 * - elevationRad: angle of the impulse above horizontal. Positive lifts the ball, negative presses it down.
 */
object CueStrike {

    fun apply(
        ball: PoolBall,
        direction: Vec3,
        speed: Double,
        sideOffset: Double,
        heightOffset: Double,
        elevationRad: Double,
    ): PoolBall {
        require(speed >= 0.0) { "speed must not be negative" }
        require(sideOffset in -1.0..1.0 && heightOffset in -1.0..1.0) { "contact offsets must be within [-1, 1]" }
        require(sideOffset * sideOffset + heightOffset * heightOffset <= 1.0 + 1e-9) {
            "contact point must lie on the ball surface"
        }
        val horizontal = direction.horizontal().normalizedOrZero()
        require(horizontal != Vec3.ZERO) { "direction must have a horizontal component" }

        val mass = BallPhysics.MASS_KG
        val right = horizontal.cross(Vec3.UP)
        val impulseDirection = horizontal * cos(elevationRad) + Vec3.UP * sin(elevationRad)
        val impulse = impulseDirection * (mass * speed)

        val contactOffset = (Vec3.UP * heightOffset + right * sideOffset) * BallPhysics.RADIUS_M
        val dv = impulse * (1.0 / mass)
        val dw = contactOffset.cross(impulse) * (1.0 / BallPhysics.INERTIA)
        return ball.copy(
            velocity = ball.velocity + dv,
            angularVelocity = ball.angularVelocity + dw,
        )
    }
}
