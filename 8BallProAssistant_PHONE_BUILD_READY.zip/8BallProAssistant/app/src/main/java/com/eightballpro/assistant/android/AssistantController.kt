package com.eightballpro.assistant.android

import android.content.Context
import android.util.Log
import com.eightballpro.assistant.android.capture.CaptureConsentActivity
import com.eightballpro.assistant.android.capture.ScreenCaptureService
import com.eightballpro.assistant.domain.assistant.AimSettings
import com.eightballpro.assistant.domain.assistant.AimSource
import com.eightballpro.assistant.domain.assistant.AssistantSession
import com.eightballpro.assistant.domain.assistant.AssistantSnapshot
import com.eightballpro.assistant.domain.assistant.PredictionConfidence
import com.eightballpro.assistant.domain.assistant.PredictionView
import com.eightballpro.assistant.domain.frame.RawFrame
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

/**
 * Process-wide holder for the assistant. Owns the single [AssistantSession] and the single analysis
 * thread. Every change goes through the session, and the result is published to [snapshot].
 * The overlay service and the capture service are the only callers that change capture state.
 */
object AssistantController {

    private const val TAG = "AssistantController"

    private val session = AssistantSession()
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "assistant-analysis").apply { isDaemon = true }
    }
    private val mutableSnapshot = MutableStateFlow(session.snapshot())

    /**
     * The newest aim the user chose that the session has not applied yet. While it is set, published
     * snapshots keep showing it, so a slider never snaps back to an older value while the shot is recomputed.
     */
    private val pendingAim = AtomicReference<AimSettings?>(null)

    val snapshot: StateFlow<AssistantSnapshot> = mutableSnapshot.asStateFlow()

    private fun publish() {
        val next = session.snapshot()
        val pending = pendingAim.get()
        mutableSnapshot.value = if (pending != null) withPendingAim(next, pending) else next
    }

    /**
     * A snapshot as it must look while [pending] is the newest aim and the session has not applied it yet.
     * The aim and its source are the user's. The shot belongs to an older aim, so it is hidden instead of being
     * drawn next to an aim it does not match; it comes back once the session has recomputed it.
     */
    private fun withPendingAim(snapshot: AssistantSnapshot, pending: AimSettings): AssistantSnapshot =
        snapshot.copy(
            aim = pending,
            aimSource = AimSource.USER_MANUAL,
            prediction = PredictionView(false, "Updating the shot for the new aim.", PredictionConfidence.NONE, emptyList()),
            latestShot = null,
        )

    fun setAcknowledged(value: Boolean) {
        session.setAcknowledged(value)
        publish()
    }

    /**
     * Applies a change to the current aim. Safe to call from the UI thread on every slider event: the new
     * value is shown at once, and the shot is recomputed on the analysis thread. Events that arrive while a
     * recomputation is waiting are merged, so only the newest aim is simulated.
     */
    fun updateAim(transform: (AimSettings) -> AimSettings) {
        setAim(transform(pendingAim.get() ?: mutableSnapshot.value.aim))
    }

    fun setAim(aim: AimSettings) {
        pendingAim.set(aim)
        mutableSnapshot.update { withPendingAim(it, aim) }
        analysisExecutor.execute {
            val next = pendingAim.get() ?: return@execute
            try {
                session.setAim(next)
            } catch (e: Exception) {
                // A failed simulation must not take the whole app down from a background thread.
                Log.w(TAG, "Could not apply the aim.", e)
            } finally {
                // Clear it only if no newer aim arrived meanwhile; that one has its own queued task.
                pendingAim.compareAndSet(next, null)
                publish()
            }
        }
    }

    /**
     * Hands the aim back to automatic detection, after the user had set it by hand. A manual change that is
     * still waiting to be applied is dropped, because the user chose automatic after making it. The work runs
     * on the analysis thread, in order after any manual change that is already being applied.
     */
    fun resumeAutoAim() {
        pendingAim.set(null)
        analysisExecutor.execute {
            session.resumeAutoAim()
            publish()
        }
    }

    fun startAnalysis() {
        session.startAnalysis()
        publish()
    }

    fun pauseAnalysis() {
        session.pauseAnalysis()
        publish()
    }

    fun resumeAnalysis() {
        session.resumeAnalysis()
        publish()
    }

    fun stopAnalysis() {
        session.stopAnalysis()
        publish()
    }

    /** Opens the system consent flow. Returns null when it was opened, otherwise the reason it was refused. */
    fun requestCapture(context: Context): String? {
        var error = session.requestCapture()
        if (error == null) {
            try {
                CaptureConsentActivity.start(context)
            } catch (e: RuntimeException) {
                error = session.onConsentResult(false) ?: "Could not open the screen capture consent screen."
            }
        }
        publish()
        return error
    }

    fun isAwaitingConsent(): Boolean = session.isAwaitingConsent()

    fun onConsentResult(granted: Boolean): String? {
        val error = session.onConsentResult(granted)
        publish()
        return error
    }

    fun onCaptureEnded(reason: String) {
        session.onCaptureEnded(reason)
        publish()
    }

    fun onServiceDestroyed() {
        session.onServiceDestroyed()
        publish()
    }

    /** User pressed Stop capture. Stops the capture service too. */
    fun stopCapture(context: Context) {
        session.stopCapture()
        publish()
        ScreenCaptureService.stop(context)
    }

    /** The overlay was closed. Stops analysis and capture, so nothing keeps running in the background. */
    fun onOverlayStopped(context: Context) {
        session.stopAnalysis()
        session.stopCapture()
        publish()
        ScreenCaptureService.stop(context)
    }

    /**
     * Asks whether a captured image should be analysed. Returns a frame id when it should, or null when it
     * must be dropped (not running, previous frame still analysing, or throttled). The capture service calls
     * this before it copies the image, so dropped images cost nothing. A non-null result must be followed by
     * [submitReservedFrame].
     */
    fun reserveFrame(nowMs: Long): Long? = session.beginFrame(nowMs)

    /** Hands over the copied frame for an id from [reserveFrame]. A null [frame] releases the reservation. */
    fun submitReservedFrame(id: Long, frame: RawFrame?) {
        if (frame == null) {
            session.abandonFrame("A captured frame could not be read.")
            publish()
            return
        }
        analysisExecutor.execute {
            try {
                session.analyseFrame(id, frame)
            } catch (e: Exception) {
                session.abandonFrame("Analysis failed.")
            } finally {
                publish()
            }
        }
    }

    /** Reserves and submits in one step, for callers that already hold a copied frame. */
    fun offerFrame(nowMs: Long, frame: RawFrame) {
        val id = reserveFrame(nowMs) ?: return
        submitReservedFrame(id, frame)
    }
}
