@file:OptIn(ExperimentalMaterial3Api::class)

package com.eightballpro.assistant.ui.power

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.ui.common.ScreenScaffold

@Composable
fun PowerCalculatorScreen(onBack: () -> Unit) {
    var powerFraction by remember { mutableDoubleStateOf(0.5) }
    var ballRestitution by remember { mutableDoubleStateOf(PhysicsConfig.DEFAULT.ballRestitution) }

    val minSpeed = 0.2
    val maxSpeed = 6.0
    val strikeSpeed = minSpeed + powerFraction * (maxSpeed - minSpeed)
    val mass = BallPhysics.MASS_KG
    val kineticEnergyJ = 0.5 * mass * strikeSpeed * strikeSpeed

    // Head-on collision energy transfer
    val objectSpeedPost = strikeSpeed * (1.0 + ballRestitution) / 2.0
    val cueSpeedPost = strikeSpeed * (1.0 - ballRestitution) / 2.0

    ScreenScaffold(title = "Power Calculator", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(
                    text = "Shot Power, Velocity & Energy Calculations",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Power Input", style = MaterialTheme.typography.titleMedium)

                        Text("Power Ratio: %.0f%%".format(powerFraction * 100.0), style = MaterialTheme.typography.bodyMedium)
                        Slider(value = powerFraction.toFloat(), onValueChange = { powerFraction = it.toDouble() }, valueRange = 0f..1f)

                        Text("Ball-to-Ball Restitution (e): %.2f".format(ballRestitution), style = MaterialTheme.typography.bodyMedium)
                        Slider(value = ballRestitution.toFloat(), onValueChange = { ballRestitution = it.toDouble() }, valueRange = 0.8f..0.98f)
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Energy & Speed Output", style = MaterialTheme.typography.titleMedium)
                        Text("Cue Strike Speed: %.2f m/s".format(strikeSpeed), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text("Cue Kinetic Energy: %.3f Joules".format(kineticEnergyJ), style = MaterialTheme.typography.bodyMedium)
                        Text("Head-on Object Ball Speed: %.2f m/s".format(objectSpeedPost), style = MaterialTheme.typography.bodyMedium)
                        Text("Head-on Cue Residual Speed: %.2f m/s".format(cueSpeedPost), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
