package com.eightballpro.assistant.domain.frame

import com.eightballpro.assistant.domain.vision.ArgbImage

/** Pixel layouts the adapter accepts. RGBA_8888 matches the format requested from ImageReader. */
enum class FramePixelFormat(val bytesPerPixel: Int) { RGBA_8888(4) }

enum class FrameRotation { R0, R90, R180, R270 }

/**
 * A captured frame in raw form, independent of Android types. [rowStrideBytes] may exceed
 * width * bytesPerPixel because hardware buffers are often padded.
 */
class RawFrame(
    val width: Int,
    val height: Int,
    val rowStrideBytes: Int,
    val bytes: ByteArray,
    val format: FramePixelFormat = FramePixelFormat.RGBA_8888,
)

/** Region in raw frame pixels. [right] and [bottom] are exclusive. */
data class CropRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

sealed interface FrameConversion {
    data class Converted(val image: ArgbImage) : FrameConversion
    data class Rejected(val reason: String) : FrameConversion
}

/**
 * Converts a raw frame into the [ArgbImage] used by the vision pipeline. Cropping and rotation happen
 * in one pass: each output pixel is read from its source position, so no intermediate copy is made.
 * Invalid input is rejected with a reason and is never turned into a guessed image.
 */
object FrameAdapter {

    const val MAX_DIMENSION = 8192

    fun convert(
        frame: RawFrame?,
        crop: CropRect? = null,
        rotation: FrameRotation = FrameRotation.R0,
    ): FrameConversion {
        if (frame == null) return FrameConversion.Rejected("No frame was received.")
        validate(frame)?.let { return FrameConversion.Rejected(it) }

        val region = crop ?: CropRect(0, 0, frame.width, frame.height)
        if (region.width <= 0 || region.height <= 0) return FrameConversion.Rejected("Crop region is empty.")
        if (region.left < 0 || region.top < 0 || region.right > frame.width || region.bottom > frame.height) {
            return FrameConversion.Rejected("Crop region lies outside the frame.")
        }

        val cw = region.width
        val ch = region.height
        val swapped = rotation == FrameRotation.R90 || rotation == FrameRotation.R270
        val outW = if (swapped) ch else cw
        val outH = if (swapped) cw else ch
        val out = IntArray(outW * outH)
        val src = frame.bytes
        val bpp = frame.format.bytesPerPixel

        for (oy in 0 until outH) {
            for (ox in 0 until outW) {
                val sx: Int
                val sy: Int
                when (rotation) {
                    FrameRotation.R0 -> { sx = ox; sy = oy }
                    FrameRotation.R90 -> { sx = oy; sy = ch - 1 - ox }
                    FrameRotation.R180 -> { sx = cw - 1 - ox; sy = ch - 1 - oy }
                    FrameRotation.R270 -> { sx = cw - 1 - oy; sy = ox }
                }
                val i = (region.top + sy) * frame.rowStrideBytes + (region.left + sx) * bpp
                val r = src[i].toInt() and 0xFF
                val g = src[i + 1].toInt() and 0xFF
                val b = src[i + 2].toInt() and 0xFF
                val a = src[i + 3].toInt() and 0xFF
                out[oy * outW + ox] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return FrameConversion.Converted(ArgbImage(outW, outH, out))
    }

    private fun validate(frame: RawFrame): String? {
        if (frame.width !in 1..MAX_DIMENSION || frame.height !in 1..MAX_DIMENSION) {
            return "Frame size ${frame.width}x${frame.height} is outside the supported range."
        }
        val bpp = frame.format.bytesPerPixel
        if (frame.rowStrideBytes < frame.width * bpp) return "Row stride is smaller than one row of pixels."
        val required = frame.rowStrideBytes.toLong() * (frame.height - 1) + frame.width.toLong() * bpp
        if (frame.bytes.size < required) {
            return "Buffer has ${frame.bytes.size} bytes but the frame needs $required."
        }
        return null
    }
}
