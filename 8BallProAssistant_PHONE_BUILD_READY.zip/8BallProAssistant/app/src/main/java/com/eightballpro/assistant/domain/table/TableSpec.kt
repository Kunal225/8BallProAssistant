package com.eightballpro.assistant.domain.table

import com.eightballpro.assistant.domain.geometry.Vec2

enum class PocketPosition {
    TOP_LEFT, TOP_MIDDLE, TOP_RIGHT,
    BOTTOM_LEFT, BOTTOM_MIDDLE, BOTTOM_RIGHT
}

/**
 * Physical description of a pool table's playing surface.
 * Origin is the top-left corner of the playing surface; x runs along the length,
 * y runs along the width. Values are nominal and must be calibrated per table.
 */
data class TableSpec(
    val playingLengthMm: Double,
    val playingWidthMm: Double,
    val ballDiameterMm: Double,
) {
    init {
        require(playingLengthMm > 0.0) { "playingLengthMm must be positive" }
        require(playingWidthMm > 0.0) { "playingWidthMm must be positive" }
        require(ballDiameterMm > 0.0) { "ballDiameterMm must be positive" }
    }

    val ballRadiusMm: Double get() = ballDiameterMm / 2.0

    /** Pocket centres on the rails and corners. Six entries, in insertion order. */
    fun pocketCenters(): Map<PocketPosition, Vec2> {
        val l = playingLengthMm
        val w = playingWidthMm
        return linkedMapOf(
            PocketPosition.TOP_LEFT to Vec2(0.0, 0.0),
            PocketPosition.TOP_MIDDLE to Vec2(l / 2.0, 0.0),
            PocketPosition.TOP_RIGHT to Vec2(l, 0.0),
            PocketPosition.BOTTOM_LEFT to Vec2(0.0, w),
            PocketPosition.BOTTOM_MIDDLE to Vec2(l / 2.0, w),
            PocketPosition.BOTTOM_RIGHT to Vec2(l, w),
        )
    }

    companion object {
        /** Standard 9-foot (2540 x 1270 mm) table with 2.25-inch (57.15 mm) balls. */
        val NINE_FOOT = TableSpec(
            playingLengthMm = 2540.0,
            playingWidthMm = 1270.0,
            ballDiameterMm = 57.15,
        )
    }
}
