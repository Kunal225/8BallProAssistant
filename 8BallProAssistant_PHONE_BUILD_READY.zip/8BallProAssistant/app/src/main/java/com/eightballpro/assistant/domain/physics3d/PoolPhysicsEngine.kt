package com.eightballpro.assistant.domain.physics3d

import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.table.PocketPosition
import kotlin.math.abs

sealed interface PhysicsEvent {
    val time: Double
}

data class BallCollision(
    override val time: Double,
    val ballA: Int,
    val ballB: Int,
    val closingSpeed: Double,
    /**
     * Where the two ball surfaces touch, in metres in the table frame: the midpoint of the two ball centres at the
     * moment the contact is detected. Null when the producer of the event does not know it. [ballA] and [ballB]
     * keep their meaning; this field only adds information.
     */
    val point: Vec3? = null,
) : PhysicsEvent

data class CushionImpact(override val time: Double, val ballId: Int, val cushionIndex: Int, val normalSpeed: Double) : PhysicsEvent

data class PocketEntry(override val time: Double, val ballId: Int, val pocket: PocketPosition) : PhysicsEvent

data class WorldState(val time: Double, val balls: List<PoolBall>)

data class StepResult(val state: WorldState, val events: List<PhysicsEvent>)

/** Positions of the balls still on the table at one sampled time. */
data class Frame(val time: Double, val positions: Map<Int, Vec3>)

data class ShotResult(
    val frames: List<Frame>,
    val events: List<PhysicsEvent>,
    val finalBalls: List<PoolBall>,
    val duration: Double,
    val sampleInterval: Double,
    val cueDistance: Double,
) {
    val collisionCount: Int get() = events.count { it is BallCollision }
    val cushionCount: Int get() = events.count { it is CushionImpact }
    val pocketed: List<PocketEntry> get() = events.filterIsInstance<PocketEntry>()
    val cuePocketed: Boolean get() = pocketed.any { it.ballId == CUE_BALL_ID }
}

/**
 * Fixed-step 3D pool simulation. Each step:
 * 1. applies floor friction and rolling resistance to balls touching the cloth,
 * 2. applies gravity, integrates position, and applies the floor bounce,
 * 3. resolves ball-ball contacts with impulses and separates overlaps,
 * 4. checks pocket capture, then resolves rail contacts.
 *
 * Accuracy depends on [dt]. The default 2e-4 s is adequate for the playback and the test tolerances;
 * the unit tests use smaller steps where they check exact values.
 */
class PoolPhysicsEngine(
    private val table: TableGeometry3D,
    private val config: PhysicsConfig,
    val dt: Double = DEFAULT_DT,
) {
    init {
        require(dt > 0.0 && dt <= 1e-3) { "dt must be in (0, 1e-3]" }
    }

    fun step(state: WorldState): StepResult {
        val time = state.time + dt
        val events = ArrayList<PhysicsEvent>()
        val balls = state.balls.toMutableList()
        val radius = BallPhysics.RADIUS_M
        val g = BallPhysics.GRAVITY

        // 1 and 2: floor contact, gravity, integration.
        for (i in balls.indices) {
            var ball = balls[i]
            if (ball.pocketed) continue
            if (ball.position.z <= radius + FLOOR_EPSILON) {
                ball = ContactSolver.applyFloorFriction(ball, dt, config.slidingFriction, config.rollingFriction)
            }
            ball = ball.copy(velocity = ball.velocity - Vec3(0.0, 0.0, g * dt))
            var position = ball.position + ball.velocity * dt
            var velocity = ball.velocity
            if (position.z < radius) {
                position = Vec3(position.x, position.y, radius)
                if (velocity.z < 0.0) {
                    val rebound = if (-velocity.z > BOUNCE_THRESHOLD) -config.clothRestitution * velocity.z else 0.0
                    velocity = Vec3(velocity.x, velocity.y, rebound)
                }
            }
            balls[i] = ball.copy(position = position, velocity = velocity)
        }

        // 3: ball-ball contacts.
        for (i in balls.indices) {
            for (j in i + 1 until balls.size) {
                val a = balls[i]
                val b = balls[j]
                if (a.pocketed || b.pocketed) continue
                val d = b.position - a.position
                val dist = d.length()
                if (dist <= 0.0 || dist >= 2.0 * radius) continue
                val n = d * (1.0 / dist)

                var na = a
                var nb = b
                val closing = (a.velocity - b.velocity).dot(n)
                if (closing > 0.0) {
                    val pair = ContactSolver.resolveBallPair(a, b, config.ballRestitution, config.ballFriction)
                    na = pair.first
                    nb = pair.second
                    events.add(BallCollision(time, a.id, b.id, closing, (a.position + b.position) * 0.5))
                }
                // Separate overlapping balls equally so they cannot stay interpenetrated.
                val overlap = 2.0 * radius - dist
                na = na.copy(position = na.position - n * (overlap / 2.0))
                nb = nb.copy(position = nb.position + n * (overlap / 2.0))
                balls[i] = na
                balls[j] = nb
            }
        }

        // 4: pockets, then rails.
        for (i in balls.indices) {
            var ball = balls[i]
            if (ball.pocketed) continue
            val pocket = table.capturingPocket(ball.position)
            if (pocket != null) {
                balls[i] = ball.copy(pocketed = true, velocity = Vec3.ZERO, angularVelocity = Vec3.ZERO)
                events.add(PocketEntry(time, ball.id, pocket.name))
                continue
            }
            for ((index, cushion) in table.cushions.withIndex()) {
                val crossing = cushion.crossing(ball.position)
                if (crossing <= 0.0) continue
                ball = ball.copy(position = ball.position + cushion.inwardNormal * crossing)
                val normalSpeed = ball.velocity.dot(cushion.inwardNormal)
                if (normalSpeed < 0.0) {
                    events.add(CushionImpact(time, ball.id, index, -normalSpeed))
                    ball = ContactSolver.resolveCushion(
                        ball,
                        cushion.inwardNormal,
                        config.cushionRestitution,
                        config.slidingFriction,
                    )
                }
            }
            balls[i] = ball
        }

        return StepResult(WorldState(time, balls.toList()), events)
    }

    /**
     * Runs the simulation from [initial] until every ball is at rest, all balls are pocketed, or
     * [maxTime] is reached. Positions are sampled every [sampleInterval] seconds for playback and trajectories.
     */
    fun simulate(initial: List<PoolBall>, maxTime: Double, sampleInterval: Double = 1.0 / 60.0): ShotResult {
        require(maxTime > 0.0 && sampleInterval > 0.0) { "maxTime and sampleInterval must be positive" }
        var state = WorldState(0.0, initial)
        val frames = mutableListOf(frameOf(state))
        val events = mutableListOf<PhysicsEvent>()
        var nextSample = sampleInterval
        var cueDistance = 0.0

        while (state.time < maxTime && !isAtRest(state.balls)) {
            val cueBefore = state.balls.firstOrNull { it.isCue && !it.pocketed }?.position
            val result = step(state)
            state = result.state
            events.addAll(result.events)
            val cueAfter = state.balls.firstOrNull { it.isCue && !it.pocketed }?.position
            if (cueBefore != null && cueAfter != null) {
                cueDistance += (cueAfter - cueBefore).length()
            }
            if (state.time + 1e-12 >= nextSample) {
                frames.add(frameOf(state))
                nextSample += sampleInterval
            }
        }
        frames.add(frameOf(state))
        return ShotResult(
            frames = frames,
            events = events,
            finalBalls = state.balls,
            duration = state.time,
            sampleInterval = sampleInterval,
            cueDistance = cueDistance,
        )
    }

    private fun frameOf(state: WorldState): Frame =
        Frame(state.time, state.balls.filter { !it.pocketed }.associate { it.id to it.position })

    private fun isAtRest(balls: List<PoolBall>): Boolean {
        val radius = BallPhysics.RADIUS_M
        return balls.all { b ->
            b.pocketed || (
                b.velocity.length() < REST_LINEAR_SPEED &&
                    abs(b.angularVelocity.x) < REST_ANGULAR_SPEED &&
                    abs(b.angularVelocity.y) < REST_ANGULAR_SPEED &&
                    b.position.z <= radius + FLOOR_EPSILON
                )
        }
    }

    companion object {
        const val DEFAULT_DT = 2e-4
        private const val FLOOR_EPSILON = 1e-9
        private const val BOUNCE_THRESHOLD = 0.01
        private const val REST_LINEAR_SPEED = 1e-3
        private const val REST_ANGULAR_SPEED = 1e-2
    }
}
