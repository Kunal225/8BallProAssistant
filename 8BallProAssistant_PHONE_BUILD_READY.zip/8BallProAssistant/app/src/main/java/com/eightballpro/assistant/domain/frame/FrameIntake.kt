package com.eightballpro.assistant.domain.frame

/**
 * Turns captured images into analysis frames while owning every image it is given. Pure Kotlin: [I] is the
 * image type, so the same logic runs in the capture service with real images and in unit tests with fakes.
 *
 * Rules:
 * - An image is converted only after a frame was reserved for it, so dropped images are never copied.
 * - An image whose [stamp] equals the previous reserved image's is dropped, so one image is never analysed twice.
 * - Every image is released exactly once before [accept] returns, on every path, including exceptions.
 * - Every reservation ends in exactly one [submit] call. A frame that could not be produced is submitted as null,
 *   which releases the reservation, so one bad image cannot block analysis.
 */
class FrameIntake<I>(
    private val reserve: (nowMs: Long) -> Long?,
    private val convert: (I) -> RawFrame?,
    private val release: (I) -> Unit,
    private val submit: (id: Long, frame: RawFrame?) -> Unit,
) {
    @Volatile
    private var lastStamp = NO_STAMP

    /** Forgets the previous image, for a new capture session. */
    fun reset() {
        lastStamp = NO_STAMP
    }

    /**
     * Takes ownership of [image]. Returns true when a frame was handed to [submit], and false when the image
     * was dropped.
     */
    fun accept(image: I, stamp: Long, nowMs: Long): Boolean {
        var id: Long? = null
        var frame: RawFrame? = null
        try {
            if (stamp == lastStamp) return false
            id = reserve(nowMs)
            if (id == null) return false
            lastStamp = stamp
            frame = try {
                convert(image)
            } catch (e: RuntimeException) {
                null
            }
        } catch (e: RuntimeException) {
            // Something failed after the reservation, or in reserve itself. A reservation, if there is one,
            // is still released below with a null frame.
            frame = null
        } finally {
            try {
                release(image)
            } catch (ignored: RuntimeException) {
                // Nothing more can be done for an image that will not close.
            }
        }
        val reservedId = id ?: return false
        submit(reservedId, frame)
        return true
    }

    private companion object {
        const val NO_STAMP = Long.MIN_VALUE
    }
}
