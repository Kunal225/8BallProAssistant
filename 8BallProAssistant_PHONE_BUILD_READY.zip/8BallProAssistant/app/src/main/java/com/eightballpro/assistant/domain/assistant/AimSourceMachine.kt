package com.eightballpro.assistant.domain.assistant

/** Where the current aim came from. */
enum class AimSource {
    /** Taken from the aim detected in the screen capture. This is also the state before any aim exists. */
    AUTO_DETECTION,

    /** Set by the user. Automatic detection never overwrites it. */
    USER_MANUAL,
}

/** The current aim, which is null until one is set or detected, and where it came from. */
data class AimState(
    val aim: AimSettings? = null,
    val source: AimSource = AimSource.AUTO_DETECTION,
)

sealed interface AimEvent {
    /** The user moved an aim control or set the aim. Adjusting the power counts, because power is part of the aim. */
    data class UserSet(val aim: AimSettings) : AimEvent

    /** An aim target found in an analysed frame, in table-normalised coordinates. */
    data class Detected(val targetU: Double, val targetV: Double) : AimEvent

    /**
     * The user asked to follow the detection again. [detected] is the target found in the latest analysed
     * frame as (u, v), or null when that frame has none.
     */
    data class ResumeAuto(val detected: Pair<Double, Double>?) : AimEvent
}

/**
 * Decides who owns the aim. The one rule: a detection never replaces an aim the user set. Only the user
 * leaves USER_MANUAL, through [AimEvent.ResumeAuto]. Pure and free of Android types, like the other
 * state machines, so the rule can be tested without a device.
 */
object AimSourceMachine {

    fun reduce(state: AimState, event: AimEvent): AimState = when (event) {
        is AimEvent.UserSet -> AimState(event.aim, AimSource.USER_MANUAL)

        is AimEvent.Detected ->
            if (state.source == AimSource.USER_MANUAL) state else followed(state, event.targetU, event.targetV)

        is AimEvent.ResumeAuto -> {
            val detected = event.detected
            // The source switches even when nothing is detected right now, so the next detection is followed.
            // The current aim stays in place until then; it is never replaced by a guess.
            val resumed = state.copy(source = AimSource.AUTO_DETECTION)
            if (detected == null) resumed else followed(resumed, detected.first, detected.second)
        }
    }

    /** Applies a detected target, keeping the power. Out-of-range targets are ignored, not clamped. */
    private fun followed(state: AimState, u: Double, v: Double): AimState {
        if (!(u in 0.0..1.0 && v in 0.0..1.0)) return state
        return AimState(AimSettings(u, v, state.aim?.power ?: DEFAULT_POWER), AimSource.AUTO_DETECTION)
    }

    private const val DEFAULT_POWER = 0.5
}
