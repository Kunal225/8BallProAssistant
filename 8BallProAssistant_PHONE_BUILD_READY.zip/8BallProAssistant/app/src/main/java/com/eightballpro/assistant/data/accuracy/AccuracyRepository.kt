package com.eightballpro.assistant.data.accuracy

import com.eightballpro.assistant.domain.physics3d.Vec3
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sqrt

data class ShotAccuracyRecord(
    val timestampMs: Long,
    val predictedCuePos: Vec3,
    val actualCuePos: Vec3,
    val predictedObjectPocketed: Boolean,
    val actualObjectPocketed: Boolean,
    val confidenceLevel: String,
) {
    val positionErrorMeters: Double get() {
        val dx = actualCuePos.x - predictedCuePos.x
        val dy = actualCuePos.y - predictedCuePos.y
        return sqrt(dx * dx + dy * dy)
    }

    val positionErrorMm: Double get() = positionErrorMeters * 1000.0
    val pocketPredictionMatched: Boolean get() = predictedObjectPocketed == actualObjectPocketed
}

data class AccuracySummary(
    val totalShots: Int,
    val avgErrorMm: Double,
    val pocketAccuracyPct: Double,
    val calibrationQualityScore: Double,
)

object AccuracyRepository {
    private val records = mutableListOf<ShotAccuracyRecord>()
    private val mutableFlow = MutableStateFlow<List<ShotAccuracyRecord>>(emptyList())

    val history: StateFlow<List<ShotAccuracyRecord>> = mutableFlow.asStateFlow()

    init {
        // Seed default initial sample record for demonstration and testing
        addRecord(
            ShotAccuracyRecord(
                timestampMs = System.currentTimeMillis() - 60_000,
                predictedCuePos = Vec3(1.2, 0.6, 0.0285),
                actualCuePos = Vec3(1.215, 0.592, 0.0285),
                predictedObjectPocketed = true,
                actualObjectPocketed = true,
                confidenceLevel = "HIGH",
            )
        )
    }

    @Synchronized
    fun addRecord(record: ShotAccuracyRecord) {
        records.add(0, record)
        mutableFlow.value = records.toList()
    }

    @Synchronized
    fun clearHistory() {
        records.clear()
        mutableFlow.value = emptyList()
    }

    fun getSummary(): AccuracySummary {
        val list = mutableFlow.value
        if (list.isEmpty()) {
            return AccuracySummary(totalShots = 0, avgErrorMm = 0.0, pocketAccuracyPct = 100.0, calibrationQualityScore = 1.0)
        }
        val avgError = list.map { it.positionErrorMm }.average()
        val matchedCount = list.count { it.pocketPredictionMatched }
        val pocketPct = (matchedCount.toDouble() / list.size) * 100.0
        val calScore = (1.0 - (avgError / 100.0).coerceAtMost(1.0)).coerceAtLeast(0.0)
        return AccuracySummary(
            totalShots = list.size,
            avgErrorMm = avgError,
            pocketAccuracyPct = pocketPct,
            calibrationQualityScore = calScore,
        )
    }
}
