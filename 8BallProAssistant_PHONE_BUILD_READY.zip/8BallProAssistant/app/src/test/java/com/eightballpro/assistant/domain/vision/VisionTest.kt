package com.eightballpro.assistant.domain.vision

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TableBoundaryDetectorTest {

    @Test
    fun findsTheFeltRectangle() {
        val bounds = TableBoundaryDetector.detect(SyntheticImage.twoBallTable(), ColorProfile.BLUE_FELT)
        assertEquals(TableBounds(20, 20, 219, 119, bounds!!.feltCoverage), bounds)
        assertTrue(bounds.feltCoverage > 0.97)
        assertEquals(2.0, bounds.aspectRatio, 1e-12)
    }

    @Test
    fun imageWithoutFeltReturnsNull() {
        val blank = SyntheticImage(64, 32).build()
        assertNull(TableBoundaryDetector.detect(blank, ColorProfile.BLUE_FELT))
    }
}

class BallDetectorTest {

    private val image = SyntheticImage.twoBallTable()
    private val bounds = TableBoundaryDetector.detect(image, ColorProfile.BLUE_FELT)!!

    @Test
    fun findsBothBallsWithCentresAndRadii() {
        val blobs = BallDetector.detect(image, bounds, ColorProfile.BLUE_FELT)
        assertEquals(2, blobs.size)
        val cue = blobs.first { Math.abs(it.centreX - 60) < 2 }
        assertEquals(70.0, cue.centreY, 0.5)
        assertEquals(8.0, cue.radiusPx, 1.2)
        assertTrue(cue.fillRatio in 0.6..0.85)
    }

    @Test
    fun classifiesWhiteAsCueAndRedAsObject() {
        val blobs = BallDetector.detect(image, bounds, ColorProfile.BLUE_FELT)
        val cue = blobs.first { Math.abs(it.centreX - 60) < 2 }
        val red = blobs.first { Math.abs(it.centreX - 150) < 2 }
        assertEquals(BallClass.CUE, BallClassifier.classify(cue).cls)
        assertEquals(BallClass.OBJECT, BallClassifier.classify(red).cls)
    }

    @Test
    fun classifiesShadedWhiteCueBall() {
        val shadedCueBlob = RawBlob(
            centreX = 50.0, centreY = 50.0, radiusPx = 8.0, area = 200, fillRatio = 0.69,
            boxWidth = 16, boxHeight = 16, meanR = 185, meanG = 190, meanB = 195,
        )
        val classified = BallClassifier.classify(shadedCueBlob)
        assertEquals(BallClass.CUE, classified.cls)
        assertTrue(classified.confidence > 0.6)
    }

    @Test
    fun classifiesDarkBlobAsBlackBall() {
        val img = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, SyntheticImage.FELT)
            .disc(100.0, 70.0, 8.0, SyntheticImage.BLACK_BALL)
            .build()
        val b = TableBoundaryDetector.detect(img, ColorProfile.BLUE_FELT)!!
        val blob = BallDetector.detect(img, b, ColorProfile.BLUE_FELT).single()
        assertEquals(BallClass.BLACK, BallClassifier.classify(blob).cls)
    }

    @Test
    fun tinySpecksBelowMinimumAreaAreIgnored() {
        val img = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, SyntheticImage.FELT)
            .fillRect(50, 50, 51, 51, SyntheticImage.WHITE)
            .build()
        val b = TableBoundaryDetector.detect(img, ColorProfile.BLUE_FELT)!!
        assertTrue(BallDetector.detect(img, b, ColorProfile.BLUE_FELT).isEmpty())
    }
}

class PerspectiveCalibrationTest {

    @Test
    fun boundsCalibrationMapsCornersToUnitSquare() {
        val bounds = TableBounds(20, 20, 219, 119, 1.0)
        val cal = PerspectiveCalibration.fromBounds(bounds)
        assertTrue(cal.isValid())
        val tl = cal.toNormalized(Point2D(20.0, 20.0))!!
        val br = cal.toNormalized(Point2D(220.0, 120.0))!!
        assertEquals(0.0, tl.x, 1e-9); assertEquals(0.0, tl.y, 1e-9)
        assertEquals(1.0, br.x, 1e-9); assertEquals(1.0, br.y, 1e-9)
    }

    @Test
    fun cueBallIsNormalisedToExpectedTablePosition() {
        val cal = PerspectiveCalibration.fromBounds(TableBounds(20, 20, 219, 119, 1.0))
        val uv = cal.toNormalized(Point2D(60.0, 70.0))!!
        assertEquals(0.2, uv.x, 1e-9)
        assertEquals(0.5, uv.y, 1e-9)
    }

    @Test
    fun trapezoidRoundTripIsAccurate() {
        val cal = PerspectiveCalibration(
            topLeft = Point2D(30.0, 22.0), topRight = Point2D(212.0, 26.0),
            bottomRight = Point2D(220.0, 118.0), bottomLeft = Point2D(18.0, 116.0),
        )
        assertTrue(cal.isValid())
        for (u in listOf(0.1, 0.3, 0.5, 0.8, 0.95)) {
            for (v in listOf(0.05, 0.4, 0.7, 0.9)) {
                val p = cal.toImage(u, v)
                val back = cal.toNormalized(p)!!
                assertEquals(u, back.x, 1e-6)
                assertEquals(v, back.y, 1e-6)
            }
        }
    }

    @Test
    fun bowTieCornersAreInvalid() {
        val bowTie = PerspectiveCalibration(
            topLeft = Point2D(0.0, 0.0), topRight = Point2D(10.0, 10.0),
            bottomRight = Point2D(10.0, 0.0), bottomLeft = Point2D(0.0, 10.0),
        )
        assertFalse(bowTie.isValid())
    }
}

class ConfidenceEvaluatorTest {

    private val expectedRadius = 8.0

    private fun blob(fill: Double = 0.69, radius: Double = 8.0) = RawBlob(
        centreX = 10.0, centreY = 10.0, radiusPx = radius, area = 200, fillRatio = fill,
        boxWidth = 17, boxHeight = 17, meanR = 255, meanG = 255, meanB = 255,
    )

    @Test
    fun wellFormedCueWithExpectedSizeIsHighConfidence() {
        val a = ConfidenceEvaluator.ballAssessment(blob(), expectedRadius, ClassifiedBall(BallClass.CUE, 0.9), insidePlayArea = true)
        assertEquals(Confidence.HIGH, a.level)
        assertTrue(a.reasons.isEmpty())
    }

    @Test
    fun uncertainColourIsUncertainEvenWithGoodShape() {
        val a = ConfidenceEvaluator.ballAssessment(blob(), expectedRadius, ClassifiedBall(BallClass.UNCERTAIN, 0.3), true)
        assertEquals(Confidence.UNCERTAIN, a.level)
        assertTrue(a.reasons.any { it.contains("colour") })
    }

    @Test
    fun irregularShapeScoresZero() {
        val a = ConfidenceEvaluator.ballAssessment(blob(fill = 0.2), expectedRadius, ClassifiedBall(BallClass.OBJECT, 0.9), true)
        assertEquals(Confidence.UNCERTAIN, a.level)
        assertTrue(a.reasons.any { it.contains("circle") })
    }

    @Test
    fun outsidePlayAreaLowersScoreAndAddsReason() {
        val inside = ConfidenceEvaluator.ballAssessment(blob(), expectedRadius, ClassifiedBall(BallClass.CUE, 0.9), true)
        val outside = ConfidenceEvaluator.ballAssessment(blob(), expectedRadius, ClassifiedBall(BallClass.CUE, 0.9), false)
        assertTrue(outside.score < inside.score)
        assertTrue(outside.reasons.any { it.contains("outside") })
    }

    @Test
    fun wrongSizeIsReported() {
        val a = ConfidenceEvaluator.ballAssessment(blob(radius = 2.0), expectedRadius, ClassifiedBall(BallClass.CUE, 0.9), true)
        assertTrue(a.reasons.any { it.contains("size") })
        assertTrue(a.level != Confidence.HIGH)
    }

    @Test
    fun fullFeltTableWithTwoToOneAspectIsHighConfidence() {
        val a = ConfidenceEvaluator.tableAssessment(TableBounds(0, 0, 199, 99, feltCoverage = 0.98))
        assertEquals(Confidence.HIGH, a.level)
    }
}

class ColorAndImageTest {

    @Test
    fun feltProfileMatchesFeltOnly() {
        assertTrue(ColorProfile.BLUE_FELT.matches(SyntheticImage.FELT))
        assertFalse(ColorProfile.BLUE_FELT.matches(SyntheticImage.WHITE))
        assertFalse(ColorProfile.BLUE_FELT.matches(SyntheticImage.RED))
    }

    @Test
    fun redHueIsNearThreeHundredFiftyEight() {
        val h = hueDegrees(229, 72, 77)
        assertTrue("hue was $h", h in 350f..360f)
    }

    @Test
    fun downsamplerAveragesBlocks() {
        val src = ArgbImage(4, 2, intArrayOf(
            0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(),
            0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(),
        ))
        val out = Downsampler.toMaxWidth(src, 2)
        assertEquals(2, out.width)
        assertEquals(1, out.height)
        val grey = out.pixelAt(0, 0) and 0xFF
        assertTrue("average was $grey", grey in 127..128)
    }

    @Test
    fun smallImageIsNotCopied() {
        val img = ArgbImage(8, 8, IntArray(64))
        assertTrue(Downsampler.toMaxWidth(img, 480) === img)
    }

    @Test(expected = IllegalArgumentException::class)
    fun pixelCountMustMatchSize() {
        ArgbImage(3, 3, IntArray(5))
    }
}
