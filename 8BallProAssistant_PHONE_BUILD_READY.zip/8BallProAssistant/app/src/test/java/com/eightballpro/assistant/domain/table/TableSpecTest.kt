package com.eightballpro.assistant.domain.table

import com.eightballpro.assistant.domain.geometry.Vec2
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class TableSpecTest {

    private val spec = TableSpec.NINE_FOOT

    @Test
    fun hasSixPockets() {
        assertEquals(6, spec.pocketCenters().size)
    }

    @Test
    fun cornerPocketsSitAtPlayingSurfaceCorners() {
        val p = spec.pocketCenters()
        assertEquals(Vec2(0.0, 0.0), p[PocketPosition.TOP_LEFT])
        assertEquals(Vec2(2540.0, 0.0), p[PocketPosition.TOP_RIGHT])
        assertEquals(Vec2(0.0, 1270.0), p[PocketPosition.BOTTOM_LEFT])
        assertEquals(Vec2(2540.0, 1270.0), p[PocketPosition.BOTTOM_RIGHT])
    }

    @Test
    fun sidePocketsSitAtRailMidpoints() {
        val p = spec.pocketCenters()
        assertEquals(Vec2(1270.0, 0.0), p[PocketPosition.TOP_MIDDLE])
        assertEquals(Vec2(1270.0, 1270.0), p[PocketPosition.BOTTOM_MIDDLE])
    }

    @Test
    fun ballRadiusIsHalfDiameter() {
        assertEquals(28.575, spec.ballRadiusMm, 1e-9)
    }

    @Test
    fun rejectsNonPositiveDimensions() {
        assertThrows(IllegalArgumentException::class.java) { TableSpec(0.0, 1.0, 1.0) }
        assertThrows(IllegalArgumentException::class.java) { TableSpec(1.0, -1.0, 1.0) }
        assertThrows(IllegalArgumentException::class.java) { TableSpec(1.0, 1.0, 0.0) }
    }
}
