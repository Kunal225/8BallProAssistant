package com.eightballpro.assistant.domain.mode

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModePolicyTest {

    @Test
    fun thirdPartyModeNeverAllowsLiveCaptureOrLiveAnalysis() {
        val caps = ModePolicy.capabilities(GameMode.THIRD_PARTY_SCREENSHOT)
        assertFalse(caps.liveCapture)
        assertFalse(caps.liveAnalysis)
        assertTrue(caps.screenshotImport)
        assertTrue(caps.offlinePractice)
    }

    @Test
    fun thirdPartyModeRefusesLiveCaptureEvenWithAcknowledgement() {
        val decision = ModePolicy.decideLiveCapture(GameMode.THIRD_PARTY_SCREENSHOT, Authorization(ownGameAcknowledged = true))
        assertTrue(decision is PolicyDecision.Denied)
        assertTrue((decision as PolicyDecision.Denied).reason.contains("not available for third-party"))
    }

    @Test
    fun ownGameModeRequiresAcknowledgement() {
        val decision = ModePolicy.decideLiveCapture(GameMode.OWN_GAME_AUTHORIZED, Authorization(ownGameAcknowledged = false))
        assertTrue(decision is PolicyDecision.Denied)
    }

    @Test
    fun ownGameModeAllowsLiveCaptureWhenAcknowledged() {
        assertEquals(PolicyDecision.Allowed, ModePolicy.decideLiveCapture(GameMode.OWN_GAME_AUTHORIZED, Authorization(true)))
        val caps = ModePolicy.capabilities(GameMode.OWN_GAME_AUTHORIZED)
        assertTrue(caps.liveCapture && caps.liveAnalysis)
    }
}
