package com.eightballpro.assistant.domain.assistant

import com.eightballpro.assistant.domain.analysis.AnalysisResult
import com.eightballpro.assistant.domain.analysis.DetectedBall
import com.eightballpro.assistant.domain.analysis.DetectionSource
import com.eightballpro.assistant.domain.analysis.PhysicsInput
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.ShotResult
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.vision.Assessment
import com.eightballpro.assistant.domain.vision.BallClass
import com.eightballpro.assistant.domain.vision.Confidence
import com.eightballpro.assistant.domain.vision.Point2D
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantRunMachineTest {

    private fun run(state: RunState, event: RunEvent, capture: Boolean = true) =
        AssistantRunMachine.reduce(state, event, capture)

    @Test
    fun startRequiresActiveCapture() {
        assertEquals(RunState.STOPPED, run(RunState.STOPPED, RunEvent.Start, capture = false).state)
        assertEquals(RunState.RUNNING, run(RunState.STOPPED, RunEvent.Start).state)
    }

    @Test
    fun pauseAndResumeKeepTheCaptureAndSwitchStates() {
        assertEquals(RunState.PAUSED, run(RunState.RUNNING, RunEvent.Pause).state)
        assertEquals(RunState.RUNNING, run(RunState.PAUSED, RunEvent.Resume).state)
    }

    @Test
    fun resumeAfterCaptureEndedStopsWithMessage() {
        val step = run(RunState.PAUSED, RunEvent.Resume, capture = false)
        assertEquals(RunState.STOPPED, step.state)
        assertTrue(step.message!!.contains("Start capture again"))
    }

    @Test
    fun duplicateStartAndInvalidPauseAreNoOps() {
        assertEquals(RunState.RUNNING, run(RunState.RUNNING, RunEvent.Start).state)
        assertEquals(RunState.STOPPED, run(RunState.STOPPED, RunEvent.Pause).state)
    }

    @Test
    fun stopAlwaysStops() {
        assertEquals(RunState.STOPPED, run(RunState.RUNNING, RunEvent.Stop).state)
        assertEquals(RunState.STOPPED, run(RunState.PAUSED, RunEvent.Stop).state)
    }

    @Test
    fun captureEndingWhileRunningStopsAnalysis() {
        val step = run(RunState.RUNNING, RunEvent.CaptureEnded)
        assertEquals(RunState.STOPPED, step.state)
        assertTrue(step.message!!.contains("Screen capture ended"))
    }

    @Test
    fun framesAreProcessedOnlyWhileRunningAndNotOverlapping() {
        assertTrue(AssistantRunMachine.mayProcessFrame(RunState.RUNNING, previousFrameInFlight = false))
        assertFalse(AssistantRunMachine.mayProcessFrame(RunState.RUNNING, previousFrameInFlight = true))
        assertFalse(AssistantRunMachine.mayProcessFrame(RunState.PAUSED, previousFrameInFlight = false))
        assertFalse(AssistantRunMachine.mayProcessFrame(RunState.STOPPED, previousFrameInFlight = false))
    }
}

class AssistantPresenterTest {

    private fun ball(cls: BallClass, level: Confidence) = DetectedBall(
        id = null, cls = cls, centre = Point2D(0.2, 0.5),
        assessment = Assessment(0.9, level, emptyList()), source = DetectionSource.AUTO,
    )

    @Test
    fun noFrameShowsNoAnalysis() {
        val view = AssistantPresenter.detection(null)
        assertEquals("No frame analysed yet", view.tableStatus)
        assertEquals(0, view.ballCount)
        assertFalse(view.cueFound)
    }

    @Test
    fun missingTableIsReportedWithWarnings() {
        val result = AnalysisResult(64, 32, null, null, null, emptyList(), 0, listOf("No table detected."))
        val view = AssistantPresenter.detection(result)
        assertEquals("Table not detected", view.tableStatus)
        assertEquals(listOf("No table detected."), view.warnings)
    }

    @Test
    fun predictionIsNotShownWithoutCue() {
        val physics = PhysicsInput(balls = emptyList(), excluded = emptyList(), warnings = emptyList())
        val view = AssistantPresenter.prediction(physics, shot = null)
        assertFalse(view.available)
        assertEquals(PredictionConfidence.NONE, view.confidence)
        assertTrue(view.headline.contains("no confident cue ball"))
    }

    @Test
    fun predictionNeedsAShotEvenWithACue() {
        val physics = PhysicsInput(listOf(PoolBall(0, Vec3(0.5, 0.5, 0.028575))), emptyList(), emptyList())
        val view = AssistantPresenter.prediction(physics, shot = null)
        assertFalse(view.available)
        assertTrue(view.headline.contains("Set aim and power"))
    }

    @Test
    fun predictionIsNeverHighConfidence() {
        val physics = PhysicsInput(listOf(PoolBall(0, Vec3(0.5, 0.5, 0.028575))), emptyList(), emptyList())
        val shot = ShotResult(
            frames = emptyList(), events = emptyList(), finalBalls = physics.balls,
            duration = 1.0, sampleInterval = 1.0 / 60.0, cueDistance = 0.8,
        )
        val view = AssistantPresenter.prediction(physics, shot)
        assertTrue(view.available)
        assertEquals(PredictionConfidence.MEDIUM, view.confidence)
        assertTrue(view.limitations.isNotEmpty())
        assertTrue(view.headline.contains("0.80 m"))
    }

    @Test
    fun excludedBallsLowerConfidenceAndAreReported() {
        val physics = PhysicsInput(
            balls = listOf(PoolBall(0, Vec3(0.5, 0.5, 0.028575))),
            excluded = listOf(ball(BallClass.OBJECT, Confidence.UNCERTAIN)),
            warnings = emptyList(),
        )
        val shot = ShotResult(emptyList(), emptyList(), physics.balls, 1.0, 1.0 / 60.0, 0.5)
        val view = AssistantPresenter.prediction(physics, shot)
        assertEquals(PredictionConfidence.LOW, view.confidence)
        assertTrue(view.limitations.any { it.contains("left out") })
    }
}
