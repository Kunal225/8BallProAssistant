package com.eightballpro.assistant.domain.frame

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer

class RawFrameFactoryTest {

    @Test
    fun copiesTheBytesAndLeavesTheSourcePositionAlone() {
        val bytes = ByteArray(32) { it.toByte() }
        val buffer = ByteBuffer.wrap(bytes)
        val frame = RawFrameFactory.fromBuffer(4, 2, 16, buffer)!!
        assertEquals(4, frame.width)
        assertEquals(2, frame.height)
        assertEquals(16, frame.rowStrideBytes)
        assertTrue(frame.bytes.contentEquals(bytes))
        assertEquals(0, buffer.position())
    }

    @Test
    fun paddedStrideCopiesOnlyTheRequiredBytes() {
        val buffer = ByteBuffer.wrap(ByteArray(40) { 9 })
        val frame = RawFrameFactory.fromBuffer(4, 2, 20, buffer)!!
        // Last row needs 4 * 4 = 16 bytes; the first row needs the full stride of 20.
        assertEquals(36, frame.bytes.size)
    }

    @Test
    fun rejectsInvalidOrTruncatedInput() {
        assertNull(RawFrameFactory.fromBuffer(0, 2, 16, ByteBuffer.wrap(ByteArray(32))))
        assertNull(RawFrameFactory.fromBuffer(4, 2, 0, ByteBuffer.wrap(ByteArray(32))))
        assertNull(RawFrameFactory.fromBuffer(4, 2, 16, ByteBuffer.wrap(ByteArray(20))))
    }
}
