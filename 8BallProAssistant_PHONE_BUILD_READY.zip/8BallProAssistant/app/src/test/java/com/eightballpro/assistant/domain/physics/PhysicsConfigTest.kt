package com.eightballpro.assistant.domain.physics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicsConfigTest {

    @Test
    fun defaultsAreValid() {
        val d = PhysicsConfig.DEFAULT
        assertEquals(PhysicsConfig(), d)
        assertTrue(d.slidingFriction in PhysicsConfig.SLIDING_FRICTION_RANGE)
        assertTrue(d.rollingFriction in PhysicsConfig.ROLLING_FRICTION_RANGE)
        assertTrue(d.cushionRestitution in PhysicsConfig.CUSHION_RESTITUTION_RANGE)
        assertTrue(d.ballRestitution in PhysicsConfig.BALL_RESTITUTION_RANGE)
        assertTrue(d.ballFriction in PhysicsConfig.BALL_FRICTION_RANGE)
        assertTrue(d.clothRestitution in PhysicsConfig.CLOTH_RESTITUTION_RANGE)
    }

    @Test
    fun rejectsOutOfRangeSlidingFriction() {
        assertThrows(IllegalArgumentException::class.java) { PhysicsConfig(slidingFriction = 0.0) }
    }

    @Test
    fun rejectsOutOfRangeRollingFriction() {
        assertThrows(IllegalArgumentException::class.java) { PhysicsConfig(rollingFriction = 0.5) }
    }

    @Test
    fun rejectsRestitutionAboveOne() {
        assertThrows(IllegalArgumentException::class.java) { PhysicsConfig(cushionRestitution = 1.5) }
        assertThrows(IllegalArgumentException::class.java) { PhysicsConfig(ballRestitution = 1.5) }
    }

    @Test
    fun rejectsNaN() {
        assertThrows(IllegalArgumentException::class.java) { PhysicsConfig(slidingFriction = Double.NaN) }
    }

    @Test
    fun rejectsOutOfRangeBallFrictionAndClothRestitution() {
        assertThrows(IllegalArgumentException::class.java) { PhysicsConfig(ballFriction = 0.5) }
        assertThrows(IllegalArgumentException::class.java) { PhysicsConfig(clothRestitution = 1.0) }
    }

    @Test
    fun copyWithValidValueSucceeds() {
        val updated = PhysicsConfig.DEFAULT.copy(slidingFriction = 0.3)
        assertEquals(0.3, updated.slidingFriction, 1e-12)
    }
}
