package com.eightballpro.assistant.domain.assistant

import com.eightballpro.assistant.domain.analysis.AnalysisResult
import com.eightballpro.assistant.domain.analysis.FrameOutcome
import com.eightballpro.assistant.domain.analysis.PhysicsInput
import com.eightballpro.assistant.domain.vision.AimResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The aim source as the session applies it: detections arrive as analysed frames, the user sets aim directly. */
class AimSourceSessionTest {

    private var nextId = 1L

    private fun detection(u: Double, v: Double): FrameOutcome.Analysed = FrameOutcome.Analysed(
        frameId = nextId++,
        result = AnalysisResult(
            analysedWidth = 10,
            analysedHeight = 10,
            table = null,
            tableAssessment = null,
            calibration = null,
            balls = emptyList(),
            unmappedBlobs = 0,
            warnings = emptyList(),
            aimEstimate = AimResult(true, u, v, 0.0, 0.9, "Automatic aim detected."),
        ),
        physics = PhysicsInput(emptyList(), emptyList(), emptyList()),
    )

    private fun runningSession(): AssistantSession {
        val s = AssistantSession(minFrameIntervalMs = 0L)
        s.setAcknowledged(true)
        assertNull(s.requestCapture())
        assertNull(s.onConsentResult(true))
        s.startAnalysis()
        assertEquals(RunState.RUNNING, s.snapshot().runState)
        return s
    }

    @Test
    fun aDetectedAimIsFollowedAndReportedAsAuto() {
        val s = runningSession()
        s.storeOutcomeForTest(detection(0.3, 0.6))
        val snap = s.snapshot()
        assertEquals(AimSource.AUTO_DETECTION, snap.aimSource)
        assertEquals(0.3, snap.aim.targetU, 0.0)
        assertEquals(0.6, snap.aim.targetV, 0.0)
        assertTrue(snap.autoAimAvailable)
    }

    // Scenario A at session level.
    @Test
    fun aManualAimSurvivesAFreshDetection() {
        val s = runningSession()
        val manual = AimSettings(0.8, 0.2, 0.7)
        s.setAim(manual)
        s.storeOutcomeForTest(detection(0.3, 0.6))
        val snap = s.snapshot()
        assertEquals(AimSource.USER_MANUAL, snap.aimSource)
        assertEquals(manual, snap.aim)
        assertTrue(snap.autoAimAvailable)
    }

    @Test
    fun settingTheAimAfterAutoFollowingSwitchesToManual() {
        val s = runningSession()
        s.storeOutcomeForTest(detection(0.3, 0.6))
        s.setAim(AimSettings(0.9, 0.9, 0.5))
        s.storeOutcomeForTest(detection(0.1, 0.1))
        assertEquals(0.9, s.snapshot().aim.targetU, 0.0)
        assertEquals(AimSource.USER_MANUAL, s.snapshot().aimSource)
    }

    // Scenario B at session level.
    @Test
    fun resumingAutoTakesTheDetectedAimAndFollowsTheNextOne() {
        val s = runningSession()
        s.setAim(AimSettings(0.8, 0.2, 0.7))
        s.storeOutcomeForTest(detection(0.3, 0.6))
        s.resumeAutoAim()
        assertEquals(AimSource.AUTO_DETECTION, s.snapshot().aimSource)
        assertEquals(0.3, s.snapshot().aim.targetU, 0.0)

        s.storeOutcomeForTest(detection(0.45, 0.55))
        assertEquals(0.45, s.snapshot().aim.targetU, 0.0)
    }

    @Test
    fun resumingAutoBeforeAnyDetectionLeavesTheAimAndFollowsTheFirstDetection() {
        val s = runningSession()
        val manual = AimSettings(0.8, 0.2, 0.7)
        s.setAim(manual)
        s.resumeAutoAim()
        assertEquals(AimSource.AUTO_DETECTION, s.snapshot().aimSource)
        assertEquals(manual, s.snapshot().aim)
        assertFalse(s.snapshot().autoAimAvailable)

        s.storeOutcomeForTest(detection(0.5, 0.5))
        assertEquals(0.5, s.snapshot().aim.targetU, 0.0)
    }

    // Scenario C at session level, with real threads.
    @Test
    fun detectionsRunningOnAnotherThreadNeverOverwriteTheManualAim() {
        val s = runningSession()
        val manual = AimSettings(0.8, 0.2, 0.7)
        val detector = Thread {
            for (i in 0 until 300) s.storeOutcomeForTest(detection((i % 10) / 10.0, 0.5))
        }
        detector.start()
        for (i in 0 until 100) s.setAim(AimSettings((i % 10) / 10.0, 0.5, 0.5))
        s.setAim(manual)
        detector.join()
        assertEquals(manual, s.snapshot().aim)
        assertEquals(AimSource.USER_MANUAL, s.snapshot().aimSource)
    }

    @Test
    fun aManualAimIsNotResetByPauseResumeStopOrACaptureRestart() {
        val s = runningSession()
        val manual = AimSettings(0.8, 0.2, 0.7)
        s.setAim(manual)

        s.pauseAnalysis()
        s.resumeAnalysis()
        s.stopAnalysis()
        s.stopCapture()
        s.onCaptureEnded("The system stopped the capture.")
        assertEquals(manual, s.snapshot().aim)
        assertEquals(AimSource.USER_MANUAL, s.snapshot().aimSource)

        // A new capture and a new run start with the user's aim still in place.
        assertNull(s.requestCapture())
        assertNull(s.onConsentResult(true))
        s.startAnalysis()
        s.storeOutcomeForTest(detection(0.1, 0.1))
        assertEquals(manual, s.snapshot().aim)
        assertEquals(AimSource.USER_MANUAL, s.snapshot().aimSource)
    }

    @Test
    fun aRejectedFrameDoesNotChangeTheAimOrItsSource() {
        val s = runningSession()
        val manual = AimSettings(0.8, 0.2, 0.7)
        s.setAim(manual)
        s.storeOutcomeForTest(FrameOutcome.Rejected(nextId++, "No frame was received."))
        assertEquals(manual, s.snapshot().aim)
        assertEquals(AimSource.USER_MANUAL, s.snapshot().aimSource)
        assertFalse(s.snapshot().autoAimAvailable)
    }
}
