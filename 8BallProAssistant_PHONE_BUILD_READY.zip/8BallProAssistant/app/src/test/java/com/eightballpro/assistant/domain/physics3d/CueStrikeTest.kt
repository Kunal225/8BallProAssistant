package com.eightballpro.assistant.domain.physics3d

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class CueStrikeTest {

    private val r = BallPhysics.RADIUS_M
    private val still = PoolBall(CUE_BALL_ID, Vec3(0.5, 0.5, r))
    private val forward = Vec3(1.0, 0.0, 0.0)

    @Test
    fun centreHitGivesPureTranslation() {
        val b = CueStrike.apply(still, forward, speed = 2.0, sideOffset = 0.0, heightOffset = 0.0, elevationRad = 0.0)
        assertEquals(2.0, b.velocity.x, 1e-12)
        assertEquals(0.0, b.velocity.y, 1e-12)
        assertEquals(0.0, b.angularVelocity.length(), 1e-12)
    }

    @Test
    fun topSpinGivesForwardRotationOfTwoPointFiveVOverR() {
        val b = CueStrike.apply(still, forward, speed = 2.0, sideOffset = 0.0, heightOffset = 1.0, elevationRad = 0.0)
        assertEquals(2.5 * 2.0 / r, b.angularVelocity.y, 1e-9)
    }

    @Test
    fun backSpinRotatesTheOtherWay() {
        val b = CueStrike.apply(still, forward, speed = 2.0, sideOffset = 0.0, heightOffset = -1.0, elevationRad = 0.0)
        assertTrue(b.angularVelocity.y < 0.0)
    }

    @Test
    fun rightSideHitSpinsAroundVerticalAxisPositively() {
        val b = CueStrike.apply(still, forward, speed = 2.0, sideOffset = 0.5, heightOffset = 0.0, elevationRad = 0.0)
        assertEquals(1.25 * 2.0 / r, b.angularVelocity.z, 1e-9)
    }

    @Test
    fun elevationSplitsTheImpulseBetweenHorizontalAndVertical() {
        val angle = 0.2
        val b = CueStrike.apply(still, forward, speed = 3.0, sideOffset = 0.0, heightOffset = 0.0, elevationRad = angle)
        assertEquals(3.0 * sin(angle), b.velocity.z, 1e-12)
        assertTrue(b.velocity.x > 0.0)
    }

    @Test
    fun invalidContactPointIsRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            CueStrike.apply(still, forward, speed = 1.0, sideOffset = 1.0, heightOffset = 1.0, elevationRad = 0.0)
        }
    }

    @Test
    fun zeroHorizontalDirectionIsRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            CueStrike.apply(still, Vec3(0.0, 0.0, 1.0), speed = 1.0, sideOffset = 0.0, heightOffset = 0.0, elevationRad = 0.0)
        }
    }
}
