package com.eightballpro.assistant.domain.vision

import org.junit.Assert.assertEquals
import org.junit.Test

class GameStateClassifierTest {

    @Test
    fun returnsMenuStateWhenTableIsNotDetected() {
        val result = GameStateClassifier.classify(
            image = SyntheticImage(240, 140).build(),
            bounds = null,
            felt = ColorProfile.BLUE_FELT,
        )
        assertEquals(GameState.MENU, result.state)
    }

    @Test
    fun returnsLiveMatchStateForStandardTableImage() {
        val image = SyntheticImage.twoBallTable()
        val bounds = TableBounds(20, 20, 219, 119, feltCoverage = 0.98)
        val result = GameStateClassifier.classify(image, bounds, ColorProfile.BLUE_FELT)

        assertEquals(GameState.LIVE_MATCH, result.state)
    }

    @Test
    fun returnsTableEditorStateWhenTopBarHasEditorButtons() {
        val imageBuilder = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, SyntheticImage.FELT)

        // Draw top editor UI control buttons (bright orange/blue pixels)
        for (x in 10..230) {
            for (y in 0..15) {
                imageBuilder.fillRect(x, y, x, y, 0xFFFF8A3D.toInt())
            }
        }
        val image = imageBuilder.build()
        val bounds = TableBounds(20, 20, 219, 119, feltCoverage = 0.98)
        val result = GameStateClassifier.classify(image, bounds, ColorProfile.BLUE_FELT)

        assertEquals(GameState.TABLE_EDITOR, result.state)
    }
}
