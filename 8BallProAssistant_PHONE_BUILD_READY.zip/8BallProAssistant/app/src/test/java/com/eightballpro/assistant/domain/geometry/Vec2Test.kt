package com.eightballpro.assistant.domain.geometry

import org.junit.Assert.assertEquals
import org.junit.Test

class Vec2Test {

    private val eps = 1e-9

    @Test
    fun addAndSubtract() {
        val r = Vec2(1.0, 2.0) + Vec2(3.0, -1.0)
        assertEquals(4.0, r.x, eps)
        assertEquals(1.0, r.y, eps)
        val d = Vec2(1.0, 2.0) - Vec2(3.0, -1.0)
        assertEquals(-2.0, d.x, eps)
        assertEquals(3.0, d.y, eps)
    }

    @Test
    fun lengthAndDistance() {
        assertEquals(5.0, Vec2(3.0, 4.0).length(), eps)
        assertEquals(5.0, Vec2.ZERO.distanceTo(Vec2(3.0, 4.0)), eps)
    }

    @Test
    fun dotProductOfPerpendicularVectorsIsZero() {
        assertEquals(0.0, Vec2(1.0, 0.0) dot Vec2(0.0, 1.0), eps)
    }

    @Test
    fun normalizedOrZeroHandlesZeroAndNonZero() {
        assertEquals(Vec2.ZERO, Vec2.ZERO.normalizedOrZero())
        assertEquals(1.0, Vec2(0.0, 5.0).normalizedOrZero().length(), eps)
    }

    @Test
    fun perpendicularIsOrthogonal() {
        val v = Vec2(2.0, 7.0)
        assertEquals(0.0, v dot v.perpendicular(), eps)
    }
}
