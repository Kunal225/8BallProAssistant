package com.eightballpro.assistant.domain.spin

import com.eightballpro.assistant.domain.geometry.Vec2
import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.math.sqrt

class SpinContactPointTest {

    private val eps = 1e-9
    private val diag = 1.0 / sqrt(2.0)

    @Test
    fun modelsNineContactPoints() {
        assertEquals(9, SpinContactPoint.entries.size)
    }

    @Test
    fun centerHitHasNoOffset() {
        assertEquals(Vec2.ZERO, SpinContactPoint.CENTER.normalizedOffset())
    }

    @Test
    fun everyOtherPointLiesOnTheRim() {
        SpinContactPoint.entries
            .filter { it != SpinContactPoint.CENTER }
            .forEach { point ->
                assertEquals("rim length for ${point.name}", 1.0, point.normalizedOffset().length(), eps)
            }
    }

    @Test
    fun topSpinAndBackSpinAreVerticalOpposites() {
        assertEquals(Vec2(0.0, 1.0), SpinContactPoint.TOP_SPIN.normalizedOffset())
        assertEquals(Vec2(0.0, -1.0), SpinContactPoint.BACK_SPIN.normalizedOffset())
    }

    @Test
    fun diagonalPointsHaveEqualComponents() {
        val bl = SpinContactPoint.BOTTOM_LEFT.normalizedOffset()
        assertEquals(-diag, bl.x, eps)
        assertEquals(-diag, bl.y, eps)
    }
}
