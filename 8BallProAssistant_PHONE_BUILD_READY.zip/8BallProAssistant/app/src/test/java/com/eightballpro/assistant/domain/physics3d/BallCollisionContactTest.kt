package com.eightballpro.assistant.domain.physics3d

import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.table.TableSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

/**
 * The contact point of a ball-ball collision: where the two surfaces touch, which is the midpoint between the
 * two ball centres. It is not the position of either ball.
 */
class BallCollisionContactTest {

    private val r = BallPhysics.RADIUS_M
    private val table = TableGeometry3D.from(TableSpec.NINE_FOOT)
    private val engine = PoolPhysicsEngine(table, PhysicsConfig(rollingFriction = 0.001))

    private fun ball(id: Int, x: Double, y: Double, vx: Double = 0.0, vy: Double = 0.0) =
        PoolBall(id, Vec3(x, y, r), Vec3(vx, vy, 0.0))

    private fun firstCollision(state: WorldState): BallCollision? =
        engine.step(state).events.filterIsInstance<BallCollision>().firstOrNull()

    // ---- existing consumers ----

    @Test
    fun aCollisionBuiltTheOldWayStillWorksAndHasNoPoint() {
        val c = BallCollision(0.25, 0, 3, 1.5)
        assertEquals(0.25, c.time, 0.0)
        assertEquals(0, c.ballA)
        assertEquals(3, c.ballB)
        assertEquals(1.5, c.closingSpeed, 0.0)
        assertNull(c.point)
        // Destructuring the original four values is unchanged.
        val (time, a, b, closing) = c
        assertEquals(0.25, time, 0.0)
        assertEquals(0, a)
        assertEquals(3, b)
        assertEquals(1.5, closing, 0.0)
    }

    @Test
    fun collisionCountAndShotResultStillCountCollisions() {
        val result = engine.simulate(listOf(ball(0, 0.5, 0.6, vx = 3.0), ball(1, 1.2, 0.6)), maxTime = 2.0)
        assertTrue(result.collisionCount >= 1)
        assertEquals(result.collisionCount, result.events.count { it is BallCollision })
    }

    // ---- accuracy of the contact point ----

    @Test
    fun aHeadOnContactIsHalfwayBetweenTheTwoCentres() {
        val cue = ball(CUE_BALL_ID, 1.0, 0.6, vx = 1.0)
        // Just overlapping, so the very first step detects the contact.
        val target = ball(1, 1.0 + 2.0 * r - 0.0002, 0.6)
        val hit = firstCollision(WorldState(0.0, listOf(cue, target)))!!

        assertEquals(setOf(CUE_BALL_ID, 1), setOf(hit.ballA, hit.ballB))
        val p = hit.point
        assertNotNull(p)
        assertEquals(1.0 + r, p!!.x, 5e-4)
        assertEquals(0.6, p.y, 1e-9)
        assertEquals(r, p.z, 1e-6)
    }

    @Test
    fun aCutShotContactIsOffTheCueBallsTravelLine() {
        val angle = Math.toRadians(30.0)
        val cue = ball(CUE_BALL_ID, 1.0, 0.6, vx = 1.0)
        val gap = 2.0 * r - 0.0002
        val target = ball(1, 1.0 + gap * cos(angle), 0.6 + gap * sin(angle))
        val hit = firstCollision(WorldState(0.0, listOf(cue, target)))!!

        val p = hit.point!!
        assertEquals(1.0 + r * cos(angle), p.x, 5e-4)
        assertEquals(0.6 + r * sin(angle), p.y, 5e-4)
        // About 14 mm to the side of the cue ball's centre line, so it cannot be the cue ball's own position.
        assertTrue(p.y - 0.6 > 0.012)
    }

    @Test
    fun theContactPointIsTheSameWhicheverBallComesFirstInTheList() {
        val cue = ball(CUE_BALL_ID, 1.0, 0.6, vx = 1.0)
        val target = ball(1, 1.0 + 2.0 * r - 0.0002, 0.6)
        val a = firstCollision(WorldState(0.0, listOf(cue, target)))!!.point!!
        val b = firstCollision(WorldState(0.0, listOf(target, cue)))!!.point!!
        assertEquals(a.x, b.x, 1e-9)
        assertEquals(a.y, b.y, 1e-9)
    }

    @Test
    fun inAFullSimulationTheFirstCueContactIsOneBallRadiusBeforeTheTargetCentre() {
        val targetX = 1.5
        val cue = ball(CUE_BALL_ID, 0.5, 0.6, vx = 3.0)
        val target = ball(1, targetX, 0.6)
        val result = engine.simulate(listOf(cue, target), maxTime = 2.0)

        val hit = result.events.filterIsInstance<BallCollision>()
            .first { it.ballA == CUE_BALL_ID || it.ballB == CUE_BALL_ID }
        val p = hit.point!!
        // The target is at rest until it is hit, so the contact is exactly one radius short of its centre.
        assertEquals(targetX - r, p.x, 1e-3)
        assertEquals(0.6, p.y, 1e-6)
    }

    @Test
    fun everyCollisionInAShotCarriesAPointInsideTheTable() {
        val result = engine.simulate(
            listOf(ball(CUE_BALL_ID, 0.6, 0.55, vx = 2.5, vy = 0.4), ball(1, 1.1, 0.6), ball(2, 1.16, 0.68)),
            maxTime = 3.0,
        )
        val collisions = result.events.filterIsInstance<BallCollision>()
        assertTrue(collisions.isNotEmpty())
        for (c in collisions) {
            val p = c.point
            assertNotNull(p)
            assertTrue(p!!.x in 0.0..table.length)
            assertTrue(p.y in 0.0..table.width)
        }
    }
}
