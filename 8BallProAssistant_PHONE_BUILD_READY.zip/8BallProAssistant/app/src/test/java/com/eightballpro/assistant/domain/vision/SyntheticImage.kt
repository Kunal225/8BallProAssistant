package com.eightballpro.assistant.domain.vision

/** Builds small synthetic images for tests. Felt is blue, the background is near black, and balls are discs. */
class SyntheticImage(private val width: Int, private val height: Int, background: Int = BACKGROUND) {
    private val pixels = IntArray(width * height) { background }

    fun fillRect(x0: Int, y0: Int, x1: Int, y1: Int, color: Int): SyntheticImage {
        for (y in y0..y1) for (x in x0..x1) pixels[y * width + x] = color
        return this
    }

    fun disc(cx: Double, cy: Double, radius: Double, color: Int): SyntheticImage {
        for (y in (cy - radius - 1).toInt()..(cy + radius + 1).toInt()) {
            for (x in (cx - radius - 1).toInt()..(cx + radius + 1).toInt()) {
                if (x !in 0 until width || y !in 0 until height) continue
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= radius * radius) pixels[y * width + x] = color
            }
        }
        return this
    }

    fun build(): ArgbImage = ArgbImage(width, height, pixels.copyOf())

    companion object {
        val FELT: Int = 0xFF1F6FB2.toInt()
        val WHITE: Int = 0xFFFFFFFF.toInt()
        val RED: Int = 0xFFE5484D.toInt()
        val BLACK_BALL: Int = 0xFF0A0A0A.toInt()
        val BACKGROUND: Int = 0xFF101010.toInt()

        /** 240x140 image: felt rectangle x 20..219, y 20..119; a white disc at (60,70) and a red disc at (150,60), radius 8. */
        fun twoBallTable(): ArgbImage = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, FELT)
            .disc(60.0, 70.0, 8.0, WHITE)
            .disc(150.0, 60.0, 8.0, RED)
            .build()
    }
}
