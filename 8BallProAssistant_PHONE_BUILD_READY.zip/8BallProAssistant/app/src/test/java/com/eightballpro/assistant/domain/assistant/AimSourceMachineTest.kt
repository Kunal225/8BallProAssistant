package com.eightballpro.assistant.domain.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AimSourceMachineTest {

    private val manual = AimSettings(targetU = 0.8, targetV = 0.2, power = 0.7)

    private fun reduce(state: AimState, vararg events: AimEvent): AimState =
        events.fold(state) { s, e -> AimSourceMachine.reduce(s, e) }

    @Test
    fun startsInAutoDetectionWithNoAim() {
        val s = AimState()
        assertEquals(AimSource.AUTO_DETECTION, s.source)
        assertNull(s.aim)
    }

    @Test
    fun userAimMakesTheSourceManual() {
        val s = reduce(AimState(), AimEvent.UserSet(manual))
        assertEquals(AimSource.USER_MANUAL, s.source)
        assertEquals(manual, s.aim)
    }

    @Test
    fun adjustingOnlyThePowerAlsoCountsAsManual() {
        val auto = reduce(AimState(), AimEvent.Detected(0.3, 0.6))
        val s = reduce(auto, AimEvent.UserSet(auto.aim!!.copy(power = 0.9)))
        assertEquals(AimSource.USER_MANUAL, s.source)
    }

    @Test
    fun detectionIsFollowedWhileTheSourceIsAuto() {
        val s = reduce(AimState(), AimEvent.Detected(0.3, 0.6))
        assertEquals(AimSource.AUTO_DETECTION, s.source)
        assertEquals(0.3, s.aim!!.targetU, 0.0)
        assertEquals(0.6, s.aim!!.targetV, 0.0)
    }

    @Test
    fun detectionKeepsThePowerTheAimAlreadyHad() {
        val withPower = reduce(AimState(), AimEvent.Detected(0.3, 0.6)).let {
            it.copy(aim = it.aim!!.copy(power = 0.9))
        }
        val s = reduce(withPower, AimEvent.Detected(0.4, 0.5))
        assertEquals(0.9, s.aim!!.power, 0.0)
        assertEquals(0.4, s.aim!!.targetU, 0.0)
    }

    // Scenario A: manual aim stays unchanged when auto-detection produces a new result.
    @Test
    fun detectionNeverOverwritesAManualAim() {
        val s = reduce(AimState(), AimEvent.UserSet(manual), AimEvent.Detected(0.1, 0.1))
        assertEquals(manual, s.aim)
        assertEquals(AimSource.USER_MANUAL, s.source)
    }

    // Scenario B: switching back to auto allows automatic updates.
    @Test
    fun resumingAutoAppliesTheDetectedAimAndFollowsLaterDetections() {
        val s = reduce(
            AimState(),
            AimEvent.UserSet(manual),
            AimEvent.ResumeAuto(0.25 to 0.75),
        )
        assertEquals(AimSource.AUTO_DETECTION, s.source)
        assertEquals(0.25, s.aim!!.targetU, 0.0)
        assertEquals(0.75, s.aim!!.targetV, 0.0)
        assertEquals(manual.power, s.aim!!.power, 0.0)

        val later = reduce(s, AimEvent.Detected(0.6, 0.4))
        assertEquals(0.6, later.aim!!.targetU, 0.0)
    }

    @Test
    fun resumingAutoWithoutADetectionKeepsTheAimButFollowsTheNextOne() {
        val resumed = reduce(AimState(), AimEvent.UserSet(manual), AimEvent.ResumeAuto(null))
        assertEquals(AimSource.AUTO_DETECTION, resumed.source)
        assertEquals(manual, resumed.aim)

        val later = reduce(resumed, AimEvent.Detected(0.6, 0.4))
        assertEquals(0.6, later.aim!!.targetU, 0.0)
        assertEquals(AimSource.AUTO_DETECTION, later.source)
    }

    // Scenario C: rapid manual adjustments are not overwritten by delayed detection results.
    @Test
    fun delayedDetectionsNeverBeatRapidManualAdjustments() {
        var s = AimState()
        for (i in 0 until 50) {
            val u = i / 50.0
            s = AimSourceMachine.reduce(s, AimEvent.UserSet(AimSettings(u, 1.0 - u, 0.5)))
            // A detection that was started before this adjustment arrives right after it.
            s = AimSourceMachine.reduce(s, AimEvent.Detected(0.99, 0.01))
        }
        assertEquals(49 / 50.0, s.aim!!.targetU, 0.0)
        assertEquals(AimSource.USER_MANUAL, s.source)
    }

    @Test
    fun detectionOutsideTheTableIsIgnoredNotClamped() {
        val before = reduce(AimState(), AimEvent.Detected(0.3, 0.6))
        val after = reduce(before, AimEvent.Detected(1.4, 0.5))
        assertEquals(before, after)
    }

    @Test
    fun resumingAutoWithAnOutOfRangeDetectionKeepsTheCurrentAim() {
        val s = reduce(AimState(), AimEvent.UserSet(manual), AimEvent.ResumeAuto(2.0 to 0.5))
        assertEquals(AimSource.AUTO_DETECTION, s.source)
        assertEquals(manual, s.aim)
    }
}
