package com.eightballpro.assistant.domain.assistant

import com.eightballpro.assistant.domain.analysis.AnalysisConfig
import com.eightballpro.assistant.domain.analysis.AnalysisPipeline
import com.eightballpro.assistant.domain.analysis.FrameAnalysisCoordinator
import com.eightballpro.assistant.domain.capture.CaptureState
import com.eightballpro.assistant.domain.capture.StopReason
import com.eightballpro.assistant.domain.frame.RawFrame
import com.eightballpro.assistant.domain.vision.ArgbImage
import com.eightballpro.assistant.domain.vision.SyntheticImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantSessionTest {

    private fun rgba(image: ArgbImage): RawFrame {
        val bytes = ByteArray(image.width * image.height * 4)
        for (i in image.pixels.indices) {
            val p = image.pixels[i]
            bytes[i * 4] = (p shr 16).toByte()
            bytes[i * 4 + 1] = (p shr 8).toByte()
            bytes[i * 4 + 2] = p.toByte()
            bytes[i * 4 + 3] = (p ushr 24).toByte()
        }
        return RawFrame(image.width, image.height, image.width * 4, bytes)
    }

    private val tableFrame = rgba(SyntheticImage.twoBallTable())

    /** Synthetic balls are sized to the test table, so the detections reach HIGH confidence. */
    private fun syntheticSession() = AssistantSession(
        coordinator = FrameAnalysisCoordinator(AnalysisPipeline(AnalysisConfig(ballRadiusToTableLength = 0.04))),
        minFrameIntervalMs = 400L,
    )

    private fun consented(session: AssistantSession) {
        session.setAcknowledged(true)
        assertNull(session.requestCapture())
        assertNull(session.onConsentResult(true))
    }

    @Test
    fun captureIsRefusedWithoutAcknowledgement() {
        val s = syntheticSession()
        assertNotNull(s.requestCapture())
        assertEquals(CaptureState.Idle, s.snapshot().captureState)
    }

    @Test
    fun fullFlowRequestConsentAnalyseAndStop() {
        val s = syntheticSession()
        consented(s)
        assertTrue(s.snapshot().captureState is CaptureState.Capturing)
        s.startAnalysis()
        assertEquals(RunState.RUNNING, s.snapshot().runState)

        val id = s.beginFrame(1_000L)
        assertNotNull(id)
        s.analyseFrame(id!!, tableFrame)
        val snap = s.snapshot()
        assertTrue(snap.detection.cueFound)
        assertEquals(1L, snap.framesAnalysed)
        assertFalse(snap.analysing)

        s.stopCapture()
        assertEquals(RunState.STOPPED, s.snapshot().runState)
        assertTrue(s.snapshot().captureState is CaptureState.Stopped)
    }

    @Test
    fun analysisCannotStartWithoutCapture() {
        val s = syntheticSession()
        s.startAnalysis()
        assertEquals(RunState.STOPPED, s.snapshot().runState)
        assertNotNull(s.snapshot().message)
    }

    @Test
    fun deniedConsentIsReportedAndCanBeRetried() {
        val s = syntheticSession()
        s.setAcknowledged(true)
        assertNull(s.requestCapture())
        assertNotNull(s.onConsentResult(false))
        assertTrue(s.snapshot().captureState is CaptureState.Denied)
        assertNull(s.requestCapture())
        assertTrue(s.isAwaitingConsent())
    }

    @Test
    fun onlyOneFrameIsAnalysedAtATimeAndFramesAreThrottled() {
        val s = syntheticSession()
        consented(s)
        s.startAnalysis()
        val first = s.beginFrame(1_000L)!!
        assertNull(s.beginFrame(2_000L))
        s.analyseFrame(first, tableFrame)
        assertNull(s.beginFrame(1_200L))
        assertNotNull(s.beginFrame(1_500L))
    }

    @Test
    fun abandonedFrameReleasesTheGate() {
        val s = syntheticSession()
        consented(s)
        s.startAnalysis()
        s.beginFrame(1_000L)
        s.abandonFrame("Frame conversion failed.")
        assertFalse(s.snapshot().analysing)
        assertNotNull(s.beginFrame(5_000L))
    }

    @Test
    fun pausedSessionDropsFrames() {
        val s = syntheticSession()
        consented(s)
        s.startAnalysis()
        s.pauseAnalysis()
        assertNull(s.beginFrame(10_000L))
        s.resumeAnalysis()
        assertNotNull(s.beginFrame(10_000L))
    }

    @Test
    fun predictionIsShownOnlyForACueAndAnAim() {
        val s = syntheticSession()
        consented(s)
        s.startAnalysis()
        s.analyseFrame(s.beginFrame(1_000L)!!, tableFrame)
        assertFalse(s.snapshot().prediction.available)
        s.setAim(AimSettings(targetU = 0.5, targetV = 0.5, power = 0.5))
        val view = s.snapshot().prediction
        assertTrue(view.available)
        assertFalse(view.headline.contains("Waiting"))
        assertTrue(view.confidence != PredictionConfidence.NONE)
    }

    @Test
    fun defaultBallSizeGivesNoCueAndNoPrediction() {
        val s = AssistantSession(minFrameIntervalMs = 0L)
        consented(s)
        s.startAnalysis()
        s.analyseFrame(s.beginFrame(1_000L)!!, tableFrame)
        val snap = s.snapshot()
        assertFalse(snap.detection.cueFound)
        assertFalse(snap.prediction.available)
        assertTrue(snap.prediction.headline.contains("no confident cue ball"))
    }

    @Test
    fun rejectedFrameClearsPreviousDetectionAndPrediction() {
        val s = syntheticSession()
        consented(s)
        s.startAnalysis()
        s.analyseFrame(s.beginFrame(1_000L)!!, tableFrame)
        s.setAim(AimSettings())
        s.analyseFrame(s.beginFrame(2_000L)!!, null)
        val snap = s.snapshot()
        assertEquals("No frame analysed yet", snap.detection.tableStatus)
        assertFalse(snap.prediction.available)
        assertEquals("No frame was received.", snap.message)
    }

    @Test
    fun systemEndedCaptureStopsAnalysisWithAReason() {
        val s = syntheticSession()
        consented(s)
        s.startAnalysis()
        s.onCaptureEnded("Permission was revoked.")
        val snap = s.snapshot()
        assertEquals(CaptureState.Stopped(StopReason.PROJECTION_ENDED), snap.captureState)
        assertEquals(RunState.STOPPED, snap.runState)
        assertEquals("Permission was revoked.", snap.captureError)
    }

    @Test
    fun serviceDestroyedWhileNotCapturingChangesNothing() {
        val s = syntheticSession()
        s.onServiceDestroyed()
        assertEquals(CaptureState.Idle, s.snapshot().captureState)
    }

    @Test
    fun aimValuesOutsideRangeAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { AimSettings(targetU = 1.5) }
        assertThrows(IllegalArgumentException::class.java) { AimSettings(power = -0.1) }
    }

    @Test
    fun powerMapsToSpeedRange() {
        assertEquals(AimSettings.MIN_SPEED, AimSettings(power = 0.0).speedMetersPerSecond(), 1e-12)
        assertEquals(AimSettings.MAX_SPEED, AimSettings(power = 1.0).speedMetersPerSecond(), 1e-12)
    }
}
