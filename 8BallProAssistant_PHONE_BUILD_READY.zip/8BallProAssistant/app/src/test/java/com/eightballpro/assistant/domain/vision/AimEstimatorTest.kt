package com.eightballpro.assistant.domain.vision

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AimEstimatorTest {

    @Test
    fun frameWithoutGuidelineReturnsNotDetectedWithMessage() {
        val image = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, SyntheticImage.FELT)
            .disc(60.0, 70.0, 8.0, SyntheticImage.WHITE)
            .build()
        val cal = PerspectiveCalibration.fromBounds(TableBounds(20, 20, 219, 119, 1.0))
        val result = AimEstimator.estimate(image, Point2D(0.2, 0.5), cal)

        assertFalse(result.detected)
        assertTrue(result.statusMessage.contains("Aim not detected"))
    }

    @Test
    fun frameWithBrightGuidelineEstimatesDirection() {
        val imageBuilder = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, SyntheticImage.FELT)
            .disc(60.0, 70.0, 8.0, SyntheticImage.WHITE)

        // Draw bright white aiming line extending from cue ball (60, 70) to (120, 70)
        for (x in 70..120) {
            for (y in 68..72) {
                imageBuilder.fillRect(x, y, x, y, SyntheticImage.WHITE)
            }
        }
        val image = imageBuilder.build()
        val cal = PerspectiveCalibration.fromBounds(TableBounds(20, 20, 219, 119, 1.0))
        val result = AimEstimator.estimate(image, Point2D(0.2, 0.5), cal)

        assertTrue(result.detected)
        assertTrue(result.confidence > 0.4)
    }
}
