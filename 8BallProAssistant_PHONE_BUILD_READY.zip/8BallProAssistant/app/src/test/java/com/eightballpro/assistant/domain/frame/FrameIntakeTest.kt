package com.eightballpro.assistant.domain.frame

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class FrameIntakeTest {

    private class FakeImage(val name: String) {
        var closed = 0
    }

    private class Harness(
        var reserveResult: (Long) -> Long? = { 1L },
        var convertResult: (FakeImage) -> RawFrame? = { frame() },
        var closeThrows: Boolean = false,
    ) {
        val reserveCalls = mutableListOf<Long>()
        val converted = mutableListOf<FakeImage>()
        val submitted = mutableListOf<Pair<Long, RawFrame?>>()

        val intake = FrameIntake<FakeImage>(
            reserve = { now -> reserveCalls += now; reserveResult(now) },
            convert = { image -> converted += image; convertResult(image) },
            release = { image ->
                image.closed++
                if (closeThrows) throw IllegalStateException("will not close")
            },
            submit = { id, f -> submitted += id to f },
        )

        companion object {
            fun frame() = RawFrame(1, 1, 4, ByteArray(4))
        }
    }

    // Scenario F: only reserved frames are processed.
    @Test
    fun anImageWithoutAReservationIsNeverConvertedAndIsClosedOnce() {
        val h = Harness(reserveResult = { null })
        val image = FakeImage("a")

        assertFalse(h.intake.accept(image, stamp = 100L, nowMs = 5L))

        assertTrue("dropped images must not be copied", h.converted.isEmpty())
        assertTrue(h.submitted.isEmpty())
        assertEquals(1, image.closed)
    }

    @Test
    fun aReservedImageIsConvertedOnceSubmittedAndClosedOnce() {
        val frame = Harness.frame()
        val h = Harness(reserveResult = { 7L }, convertResult = { frame })
        val image = FakeImage("a")

        assertTrue(h.intake.accept(image, stamp = 100L, nowMs = 5L))

        assertEquals(listOf(image), h.converted)
        assertEquals(1, h.submitted.size)
        assertEquals(7L, h.submitted[0].first)
        assertSame(frame, h.submitted[0].second)
        assertEquals(1, image.closed)
        assertEquals(listOf(5L), h.reserveCalls)
    }

    @Test
    fun theImageIsClosedBeforeTheFrameIsSubmitted() {
        val order = mutableListOf<String>()
        val image = FakeImage("a")
        val intake = FrameIntake<FakeImage>(
            reserve = { 1L },
            convert = { Harness.frame() },
            release = { order += "release" },
            submit = { _, _ -> order += "submit" },
        )
        intake.accept(image, 1L, 0L)
        assertEquals(listOf("release", "submit"), order)
    }

    @Test
    fun aConversionThatThrowsReleasesTheReservationWithANullFrameAndStillClosesTheImage() {
        val h = Harness(reserveResult = { 3L }, convertResult = { throw IllegalStateException("bad buffer") })
        val image = FakeImage("a")

        assertTrue(h.intake.accept(image, 100L, 0L))

        assertEquals(1, h.submitted.size)
        assertEquals(3L, h.submitted[0].first)
        assertNull(h.submitted[0].second)
        assertEquals(1, image.closed)
    }

    @Test
    fun aConversionThatReturnsNullAlsoReleasesTheReservation() {
        val h = Harness(reserveResult = { 3L }, convertResult = { null })
        h.intake.accept(FakeImage("a"), 100L, 0L)
        assertEquals(listOf<Pair<Long, RawFrame?>>(3L to null), h.submitted)
    }

    @Test
    fun aReserveThatThrowsClosesTheImageAndSubmitsNothing() {
        val h = Harness(reserveResult = { throw IllegalStateException("no") })
        val image = FakeImage("a")

        assertFalse(h.intake.accept(image, 100L, 0L))

        assertTrue(h.converted.isEmpty())
        assertTrue(h.submitted.isEmpty())
        assertEquals(1, image.closed)
    }

    @Test
    fun anImageThatWillNotCloseDoesNotStopTheFrameFromBeingSubmitted() {
        val h = Harness(reserveResult = { 9L }, closeThrows = true)
        val image = FakeImage("a")

        assertTrue(h.intake.accept(image, 100L, 0L))

        assertEquals(1, h.submitted.size)
        assertEquals(1, image.closed)
    }

    @Test
    fun theSameImageDeliveredTwiceIsAnalysedOnce() {
        val h = Harness(reserveResult = { now -> now })
        val first = FakeImage("a")
        val again = FakeImage("a again")

        assertTrue(h.intake.accept(first, stamp = 500L, nowMs = 1L))
        assertFalse(h.intake.accept(again, stamp = 500L, nowMs = 2L))

        assertEquals(1, h.reserveCalls.size)
        assertEquals(listOf(first), h.converted)
        assertEquals(1, h.submitted.size)
        assertEquals("the repeat must still be closed", 1, again.closed)
    }

    @Test
    fun aDroppedImageDoesNotMakeItsRepeatLookLikeADuplicate() {
        var allow = false
        val h = Harness(reserveResult = { if (allow) 1L else null })
        h.intake.accept(FakeImage("a"), stamp = 500L, nowMs = 1L)
        allow = true
        assertTrue(h.intake.accept(FakeImage("b"), stamp = 500L, nowMs = 2L))
        assertEquals(1, h.submitted.size)
    }

    @Test
    fun resetForgetsThePreviousImageForANewCaptureSession() {
        val h = Harness(reserveResult = { 1L })
        assertTrue(h.intake.accept(FakeImage("a"), 500L, 1L))
        h.intake.reset()
        assertTrue(h.intake.accept(FakeImage("b"), 500L, 2L))
        assertEquals(2, h.submitted.size)
    }

    @Test
    fun everyImageIsClosedExactlyOnceAndEveryReservationEndsInOneSubmit() {
        var next = 0L
        val h = Harness(
            reserveResult = { now -> if (now % 3L == 0L) null else ++next },
            convertResult = { image -> if (image.name.endsWith("7")) throw IllegalStateException("x") else Harness.frame() },
        )
        val images = (1..30).map { FakeImage("img$it") }
        images.forEachIndexed { i, image -> h.intake.accept(image, stamp = 1000L + i, nowMs = i.toLong()) }

        assertTrue(images.all { it.closed == 1 })
        assertEquals(h.reserveCalls.count { it % 3L != 0L }, h.submitted.size)
        assertEquals("ids are never submitted twice", h.submitted.size, h.submitted.map { it.first }.toSet().size)
    }
}
