package com.eightballpro.assistant.domain.capture

import com.eightballpro.assistant.domain.mode.Authorization
import com.eightballpro.assistant.domain.mode.GameMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CaptureStateMachineTest {

    private val ownAuthorised = CaptureEvent.RequestCapture(GameMode.OWN_GAME_AUTHORIZED, Authorization(true))

    private fun reduce(state: CaptureState, event: CaptureEvent) = CaptureStateMachine.reduce(state, event)

    @Test
    fun happyPathRequestConsentStopIsRecordedAsUserRequest() {
        var s = reduce(CaptureState.Idle, ownAuthorised)
        assertEquals(CaptureState.AwaitingConsent(GameMode.OWN_GAME_AUTHORIZED), s.state)
        assertNull(s.error)
        s = reduce(s.state, CaptureEvent.ConsentGranted)
        assertEquals(CaptureState.Capturing(GameMode.OWN_GAME_AUTHORIZED, rotations = 0), s.state)
        s = reduce(s.state, CaptureEvent.Stop)
        assertEquals(CaptureState.Stopped(StopReason.USER_REQUESTED), s.state)
    }

    @Test
    fun consentIsNeverAcceptedWithoutARequest() {
        val s = reduce(CaptureState.Idle, CaptureEvent.ConsentGranted)
        assertEquals(CaptureState.Idle, s.state)
        assertNotNull(s.error)
    }

    @Test
    fun thirdPartyModeCannotStartLiveCapture() {
        val s = reduce(CaptureState.Idle, CaptureEvent.RequestCapture(GameMode.THIRD_PARTY_SCREENSHOT, Authorization(true)))
        assertEquals(CaptureState.Idle, s.state)
        assertNotNull(s.error)
    }

    @Test
    fun ownGameWithoutAcknowledgementCannotStartCapture() {
        val s = reduce(CaptureState.Idle, CaptureEvent.RequestCapture(GameMode.OWN_GAME_AUTHORIZED, Authorization(false)))
        assertEquals(CaptureState.Idle, s.state)
        assertNotNull(s.error)
    }

    @Test
    fun deniedConsentIsRecordedAndCanBeRetried() {
        var s = reduce(CaptureState.Idle, ownAuthorised)
        s = reduce(s.state, CaptureEvent.ConsentDenied)
        assertEquals(CaptureState.Denied(attempts = 1), s.state)
        assertNotNull(s.error)
        s = reduce(s.state, ownAuthorised)
        assertEquals(CaptureState.AwaitingConsent(GameMode.OWN_GAME_AUTHORIZED), s.state)
    }

    @Test
    fun duplicateRequestWhileCapturingIsRefused() {
        val capturing = CaptureState.Capturing(GameMode.OWN_GAME_AUTHORIZED, 0)
        val s = reduce(capturing, ownAuthorised)
        assertEquals(capturing, s.state)
        assertNotNull(s.error)
    }

    @Test
    fun consentGrantedWhileAlreadyCapturingDoesNotRestartCapture() {
        val capturing = CaptureState.Capturing(GameMode.OWN_GAME_AUTHORIZED, rotations = 2)
        val s = reduce(capturing, CaptureEvent.ConsentGranted)
        assertEquals(capturing, s.state)
        assertNotNull(s.error)
    }

    @Test
    fun systemTerminationStopsCaptureWithReason() {
        val s = reduce(CaptureState.Capturing(GameMode.OWN_GAME_AUTHORIZED, 0), CaptureEvent.ProjectionEnded)
        assertEquals(CaptureState.Stopped(StopReason.PROJECTION_ENDED), s.state)
        assertNotNull(s.error)
    }

    @Test
    fun rotationIsCountedWithoutStoppingCapture() {
        val s = reduce(CaptureState.Capturing(GameMode.OWN_GAME_AUTHORIZED, 0), CaptureEvent.Rotated)
        assertEquals(CaptureState.Capturing(GameMode.OWN_GAME_AUTHORIZED, rotations = 1), s.state)
        assertNull(s.error)
    }

    @Test
    fun stopCancelsAPendingConsentRequest() {
        val s = reduce(CaptureState.AwaitingConsent(GameMode.OWN_GAME_AUTHORIZED), CaptureEvent.Stop)
        assertEquals(CaptureState.Stopped(StopReason.USER_REQUESTED), s.state)
    }

    @Test
    fun stopWhenIdleIsHarmless() {
        val s = reduce(CaptureState.Idle, CaptureEvent.Stop)
        assertEquals(CaptureState.Idle, s.state)
        assertNull(s.error)
    }
}
