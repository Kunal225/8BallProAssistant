package com.eightballpro.assistant.domain.analysis

import com.eightballpro.assistant.domain.assistant.RunState
import com.eightballpro.assistant.domain.frame.RawFrame
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.vision.ArgbImage
import com.eightballpro.assistant.domain.vision.BallClass
import com.eightballpro.assistant.domain.vision.SyntheticImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FrameAnalysisCoordinatorTest {

    /** Synthetic table tuned to the synthetic ball size, as in AnalysisTest. */
    private val syntheticPipeline = AnalysisPipeline(AnalysisConfig(ballRadiusToTableLength = 0.04))

    private fun rgba(image: ArgbImage): RawFrame {
        val bytes = ByteArray(image.width * image.height * 4)
        for (i in image.pixels.indices) {
            val p = image.pixels[i]
            bytes[i * 4] = (p shr 16).toByte()
            bytes[i * 4 + 1] = (p shr 8).toByte()
            bytes[i * 4 + 2] = p.toByte()
            bytes[i * 4 + 3] = (p ushr 24).toByte()
        }
        return RawFrame(image.width, image.height, image.width * 4, bytes)
    }

    private val tableFrame = rgba(SyntheticImage.twoBallTable())

    /** Direction from the detected cue (0.2, 0.5) toward the object ball (0.65, 0.4), in metres. */
    private val towardObject = Vec3(1.0, -0.1, 0.0)

    @Test
    fun analysesSyntheticFrameIntoDetectionsAndPhysics() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        val outcome = c.submit(1, RunState.RUNNING, tableFrame)
        assertTrue(outcome is FrameOutcome.Analysed)
        outcome as FrameOutcome.Analysed
        assertNotNull(outcome.result.table)
        assertTrue(outcome.result.balls.any { it.cls == BallClass.CUE })
        assertTrue(outcome.physics.balls.any { it.isCue })
    }

    @Test
    fun skipsFramesWhenNotRunning() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        val outcome = c.submit(1, RunState.PAUSED, tableFrame)
        assertTrue(outcome is FrameOutcome.Skipped)
        assertFalse(c.predict(towardObject, 1.0, 0.0, 0.0, 0.0).view.available)
    }

    @Test
    fun rejectsNullFrameAndClearsPreviousAnalysis() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        c.submit(1, RunState.RUNNING, tableFrame)
        val rejected = c.submit(2, RunState.RUNNING, null)
        assertTrue(rejected is FrameOutcome.Rejected)
        // The old detections must not survive a failed frame.
        assertFalse(c.predict(towardObject, 1.0, 0.0, 0.0, 0.0).view.available)
    }

    @Test
    fun olderOrRepeatedFrameIdsAreSkipped() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        c.submit(5, RunState.RUNNING, tableFrame)
        assertTrue(c.submit(5, RunState.RUNNING, tableFrame) is FrameOutcome.Skipped)
        assertTrue(c.submit(3, RunState.RUNNING, tableFrame) is FrameOutcome.Skipped)
    }

    @Test
    fun overlappingSubmitWhileAnalysingIsSkipped() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        var nested: FrameOutcome? = null
        c.onAnalysisStarted = {
            c.onAnalysisStarted = null
            nested = c.submit(2, RunState.RUNNING, tableFrame)
        }
        val outer = c.submit(1, RunState.RUNNING, tableFrame)
        assertTrue(outer is FrameOutcome.Analysed)
        assertTrue(nested is FrameOutcome.Skipped)
        assertEquals("Previous frame is still being analysed.", (nested as FrameOutcome.Skipped).reason)
    }

    @Test
    fun predictionFromCurrentFrameIsAvailableAndCurrent() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        c.submit(1, RunState.RUNNING, tableFrame)
        val ticket = c.predict(towardObject, 1.5, 0.0, 0.0, 0.0)
        assertTrue(ticket.view.available)
        assertNotNull(ticket.shot)
        assertTrue(ticket.shot!!.cueDistance > 0.0)
        assertTrue(c.isCurrent(ticket))
    }

    @Test
    fun predictionBecomesStaleWhenANewerFrameArrives() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        c.submit(1, RunState.RUNNING, tableFrame)
        val ticket = c.predict(towardObject, 1.5, 0.0, 0.0, 0.0)
        assertTrue(c.isCurrent(ticket))
        c.submit(2, RunState.RUNNING, tableFrame)
        assertFalse(c.isCurrent(ticket))
    }

    @Test
    fun predictionBecomesStaleWhenTheNewFrameIsRejected() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        c.submit(1, RunState.RUNNING, tableFrame)
        val ticket = c.predict(towardObject, 1.5, 0.0, 0.0, 0.0)
        c.submit(2, RunState.RUNNING, null)
        assertFalse(c.isCurrent(ticket))
    }

    @Test
    fun invalidateDropsAllPredictions() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        c.submit(1, RunState.RUNNING, tableFrame)
        val ticket = c.predict(towardObject, 1.5, 0.0, 0.0, 0.0)
        c.invalidate()
        assertFalse(c.isCurrent(ticket))
        assertFalse(c.predict(towardObject, 1.5, 0.0, 0.0, 0.0).view.available)
    }

    @Test
    fun invalidShotSettingsAreReportedNotThrown() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        c.submit(1, RunState.RUNNING, tableFrame)
        // Side and height offsets together lie outside the ball surface.
        val ticket = c.predict(towardObject, 1.5, sideOffset = 1.0, heightOffset = 1.0, elevationRad = 0.0)
        assertFalse(ticket.view.available)
        assertTrue(ticket.view.headline.startsWith("Invalid shot settings"))
    }

    @Test
    fun predictionWithoutAnyAnalysisIsUnavailable() {
        val c = FrameAnalysisCoordinator(syntheticPipeline)
        val ticket = c.predict(towardObject, 1.0, 0.0, 0.0, 0.0)
        assertFalse(ticket.view.available)
        assertEquals(0L, ticket.frameId)
    }
}
