package com.eightballpro.assistant.domain.physics3d

import org.junit.Assert.assertEquals
import org.junit.Test

class Vec3Test {
    private val eps = 1e-12

    @Test
    fun crossProductOfAxesFollowsRightHandRule() {
        val c = Vec3(1.0, 0.0, 0.0).cross(Vec3(0.0, 1.0, 0.0))
        assertEquals(0.0, c.x, eps)
        assertEquals(0.0, c.y, eps)
        assertEquals(1.0, c.z, eps)
    }

    @Test
    fun crossProductIsPerpendicularToBothInputs() {
        val a = Vec3(1.0, 2.0, 3.0)
        val b = Vec3(-2.0, 0.5, 4.0)
        val c = a.cross(b)
        assertEquals(0.0, c.dot(a), 1e-9)
        assertEquals(0.0, c.dot(b), 1e-9)
    }

    @Test
    fun lengthDistanceAndNormalisation() {
        assertEquals(5.0, Vec3(3.0, 4.0, 0.0).length(), eps)
        assertEquals(5.0, Vec3.ZERO.distanceTo(Vec3(3.0, 4.0, 0.0)), eps)
        assertEquals(1.0, Vec3(0.0, 0.0, 9.0).normalizedOrZero().length(), eps)
        assertEquals(Vec3.ZERO, Vec3.ZERO.normalizedOrZero())
    }

    @Test
    fun horizontalDropsZ() {
        assertEquals(Vec3(1.0, 2.0, 0.0), Vec3(1.0, 2.0, 7.0).horizontal())
    }
}
