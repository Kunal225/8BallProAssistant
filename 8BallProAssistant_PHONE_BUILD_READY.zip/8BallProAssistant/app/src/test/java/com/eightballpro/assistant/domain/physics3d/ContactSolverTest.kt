package com.eightballpro.assistant.domain.physics3d

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactSolverTest {

    private val m = BallPhysics.MASS_KG
    private val r = BallPhysics.RADIUS_M

    private fun ball(id: Int, x: Double, y: Double, vx: Double = 0.0, vy: Double = 0.0, vz: Double = 0.0,
                     wx: Double = 0.0, wy: Double = 0.0, wz: Double = 0.0) =
        PoolBall(id, Vec3(x, y, r), Vec3(vx, vy, vz), Vec3(wx, wy, wz))

    /** Relative tangential velocity of the two contact points, as used by the solver. */
    private fun pairSlip(a: PoolBall, b: PoolBall): Vec3 {
        val n = (b.position - a.position).normalizedOrZero()
        val ra = n * r
        val rb = n * (-r)
        val rel = (a.velocity + a.angularVelocity.cross(ra)) - (b.velocity + b.angularVelocity.cross(rb))
        return rel - n * rel.dot(n)
    }

    @Test
    fun headOnCollisionWithFullRestitutionTransfersAllVelocity() {
        val a = ball(1, 0.0, 0.0, vx = 1.0)
        val b = ball(2, 2 * r, 0.0)
        val (ra, rb) = ContactSolver.resolveBallPair(a, b, restitution = 1.0, friction = 0.0)
        assertEquals(0.0, ra.velocity.x, 1e-9)
        assertEquals(1.0, rb.velocity.x, 1e-9)
    }

    @Test
    fun headOnCollisionWithHalfRestitutionSplitsVelocityOneToThree() {
        val a = ball(1, 0.0, 0.0, vx = 1.0)
        val b = ball(2, 2 * r, 0.0)
        val (ra, rb) = ContactSolver.resolveBallPair(a, b, restitution = 0.5, friction = 0.0)
        assertEquals(0.25, ra.velocity.x, 1e-9)
        assertEquals(0.75, rb.velocity.x, 1e-9)
    }

    @Test
    fun separatingBallsAreNotChanged() {
        val a = ball(1, 0.0, 0.0, vx = -1.0)
        val b = ball(2, 2 * r, 0.0, vx = 1.0)
        val (ra, rb) = ContactSolver.resolveBallPair(a, b, restitution = 0.9, friction = 0.2)
        assertEquals(a, ra)
        assertEquals(b, rb)
    }

    @Test
    fun linearMomentumIsConservedInOblique3DCollisionWithSpinAndFriction() {
        val a = ball(1, 0.0, 0.0, vx = 1.5, vy = 0.4, wx = 0.3, wy = -20.0, wz = 5.0)
        val b = ball(2, 2 * r * 0.98, 0.02)
        val before = a.velocity * m + b.velocity * m
        val (ra, rb) = ContactSolver.resolveBallPair(a, b, restitution = 0.9, friction = 0.2)
        val after = ra.velocity * m + rb.velocity * m
        assertEquals(0.0, (after - before).length(), 1e-12)
    }

    @Test
    fun fullFrictionRemovesTangentialContactSlip() {
        val a = ball(1, 0.0, 0.0, vx = 2.0, vy = 0.5, wz = 30.0)
        val b = ball(2, 2 * r * 0.99, 0.0)
        val (ra, rb) = ContactSolver.resolveBallPair(a, b, restitution = 0.8, friction = 5.0)
        assertTrue(pairSlip(ra, rb).length() < 1e-9)
    }

    @Test
    fun cushionReboundReversesNormalVelocityByRestitutionAndKeepsTangentialWithoutFriction() {
        val b = ball(1, r, 0.5, vx = -1.0, vy = 0.5)
        val after = ContactSolver.resolveCushion(b, Vec3(1.0, 0.0, 0.0), restitution = 0.8, friction = 0.0)
        assertEquals(0.8, after.velocity.x, 1e-9)
        assertEquals(0.5, after.velocity.y, 1e-9)
    }

    @Test
    fun cushionFrictionReducesSpinInducedContactSlip() {
        val b = ball(1, r, 0.5, vx = -1.0, wy = -50.0)
        val slipBefore = slipAtRail(b)
        val after = ContactSolver.resolveCushion(b, Vec3(1.0, 0.0, 0.0), restitution = 0.8, friction = 0.2)
        val slipAfter = slipAtRail(after)
        assertTrue("slip should decrease: $slipBefore -> $slipAfter", slipAfter < slipBefore)
    }

    @Test
    fun ballMovingAwayFromCushionIsNotChanged() {
        val b = ball(1, r, 0.5, vx = 1.0)
        assertEquals(b, ContactSolver.resolveCushion(b, Vec3(1.0, 0.0, 0.0), restitution = 0.8, friction = 0.2))
    }

    private fun slipAtRail(b: PoolBall): Double {
        val n = Vec3(1.0, 0.0, 0.0)
        val contact = b.velocity + b.angularVelocity.cross(n * (-r))
        return (contact - n * contact.dot(n)).length()
    }
}
