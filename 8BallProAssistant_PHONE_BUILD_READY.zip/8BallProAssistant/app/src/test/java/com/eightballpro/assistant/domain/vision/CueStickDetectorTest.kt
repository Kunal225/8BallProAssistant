package com.eightballpro.assistant.domain.vision

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CueStickDetectorTest {

    @Test
    fun returnsNotDetectedWhenNoCueStickIsPresent() {
        val image = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, SyntheticImage.FELT)
            .disc(60.0, 70.0, 8.0, SyntheticImage.WHITE)
            .build()
        val cal = PerspectiveCalibration.fromBounds(TableBounds(20, 20, 219, 119, 1.0))
        val result = CueStickDetector.detect(image, Point2D(0.2, 0.5), cal)

        assertFalse(result.detected)
        assertTrue(result.statusMessage.contains("Cue stick not detected"))
    }

    @Test
    fun detectsCueStickOrientationAngle() {
        val imageBuilder = SyntheticImage(240, 140)
            .fillRect(20, 20, 219, 119, SyntheticImage.FELT)
            .disc(60.0, 70.0, 8.0, SyntheticImage.WHITE)

        // Draw dark cue stick behind cue ball along 180° direction
        for (x in 5..45) {
            for (y in 68..72) {
                imageBuilder.fillRect(x, y, x, y, SyntheticImage.BLACK_BALL)
            }
        }
        val image = imageBuilder.build()
        val cal = PerspectiveCalibration.fromBounds(TableBounds(20, 20, 219, 119, 1.0))
        val result = CueStickDetector.detect(image, Point2D(0.2, 0.5), cal)

        assertTrue(result.detected)
        assertTrue(result.confidence > 0.4)
    }
}
