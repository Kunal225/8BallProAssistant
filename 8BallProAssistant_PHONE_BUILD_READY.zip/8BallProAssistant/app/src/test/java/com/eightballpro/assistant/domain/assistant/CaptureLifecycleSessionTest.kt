package com.eightballpro.assistant.domain.assistant

import com.eightballpro.assistant.domain.capture.CaptureState
import com.eightballpro.assistant.domain.capture.StopReason
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The capture lifecycle as the session sees it, which is what the screen capture service and the consent
 * activity act on. The service and activity themselves need a device.
 */
class CaptureLifecycleSessionTest {

    private fun session(minFrameIntervalMs: Long = 0L): AssistantSession =
        AssistantSession(minFrameIntervalMs = minFrameIntervalMs).also { it.setAcknowledged(true) }

    private fun AssistantSession.startCapture() {
        assertNull(requestCapture())
        assertNull(onConsentResult(true))
    }

    @Test
    fun firstCaptureInitialisationReachesCapturingAndRunning() {
        val s = session()
        assertNull(s.requestCapture())
        assertTrue(s.snapshot().captureState is CaptureState.AwaitingConsent)

        assertNull(s.onConsentResult(true))

        assertTrue(s.snapshot().captureState is CaptureState.Capturing)
        assertEquals(RunState.RUNNING, s.snapshot().runState)
    }

    @Test
    fun repeatedCaptureSessionsEachStartAndStopCleanly() {
        val s = session()
        repeat(4) {
            s.startCapture()
            assertNotNull("a running capture hands out a frame id", s.beginFrame(it * 1000L))
            s.abandonFrame("test")
            s.stopCapture()
            assertEquals(CaptureState.Stopped(StopReason.USER_REQUESTED), s.snapshot().captureState)
            assertEquals(RunState.STOPPED, s.snapshot().runState)
        }
    }

    @Test
    fun stopThenRestartWorksAndStoppedCaptureHandsOutNoFrames() {
        val s = session()
        s.startCapture()
        s.stopCapture()
        assertNull("no frames after stop", s.beginFrame(0L))

        s.startCapture()
        assertNotNull(s.beginFrame(10_000L))
    }

    @Test
    fun aSecondCaptureRequestWhileCapturingIsRefused() {
        val s = session()
        s.startCapture()
        assertNotNull(s.requestCapture())
        assertTrue(s.snapshot().captureState is CaptureState.Capturing)
    }

    @Test
    fun revokedPermissionEndsCaptureAndAnalysisWithTheReason() {
        val s = session()
        s.startCapture()
        assertNotNull(s.beginFrame(0L))

        s.onCaptureEnded("Screen capture ended. It was stopped by the system or permission was revoked.")

        val snap = s.snapshot()
        assertEquals(CaptureState.Stopped(StopReason.PROJECTION_ENDED), snap.captureState)
        assertEquals(RunState.STOPPED, snap.runState)
        assertTrue(snap.captureError!!.contains("revoked"))
        assertNull("no new frames after the projection ended", s.beginFrame(10_000L))
    }

    @Test
    fun aCaptureFailureIsReportedAndStopsAnalysis() {
        val s = session()
        s.startCapture()

        s.onCaptureFailed("Could not create the capture display.")

        assertEquals(CaptureState.Stopped(StopReason.PROJECTION_ENDED), s.snapshot().captureState)
        assertEquals(RunState.STOPPED, s.snapshot().runState)
        assertEquals("Could not create the capture display.", s.snapshot().captureError)
    }

    @Test
    fun aServiceThatIsDestroyedWhileCapturingEndsTheCapture() {
        val s = session()
        s.startCapture()
        s.onServiceDestroyed()
        assertFalse(s.snapshot().captureState is CaptureState.Capturing)
        assertEquals(RunState.STOPPED, s.snapshot().runState)
    }

    // The consent activity starts the capture service only when onConsentResult returns null.
    @Test
    fun aGrantThatArrivesAfterTheUserStoppedIsRefusedAndStartsNothing() {
        val s = session()
        assertNull(s.requestCapture())
        s.stopCapture() // the user pressed Stop capture while the system dialog was still open

        val refusal = s.onConsentResult(true)

        assertNotNull("the activity must not start the service for this grant", refusal)
        assertFalse(s.snapshot().captureState is CaptureState.Capturing)
        assertEquals(RunState.STOPPED, s.snapshot().runState)
    }

    @Test
    fun aGrantWithNoRequestAtAllIsRefused() {
        val s = session()
        assertNotNull(s.onConsentResult(true))
        assertFalse(s.snapshot().captureState is CaptureState.Capturing)
    }

    @Test
    fun aDeniedConsentLeavesNoCapture() {
        val s = session()
        assertNull(s.requestCapture())
        assertNotNull(s.onConsentResult(false))
        assertTrue(s.snapshot().captureState is CaptureState.Denied)
        assertEquals(RunState.STOPPED, s.snapshot().runState)
    }

    // Scenario F at session level: a frame id is handed out only when analysis wants a frame.
    @Test
    fun framesAreReservedOnlyWhileRunningAndOneAtATime() {
        val s = session()
        assertNull("not capturing yet", s.beginFrame(0L))
        s.startCapture()

        val first = s.beginFrame(0L)
        assertNotNull(first)
        assertNull("the previous frame is still being analysed", s.beginFrame(1L))
        assertTrue(s.snapshot().analysing)

        s.abandonFrame("released")
        assertFalse(s.snapshot().analysing)

        val second = s.beginFrame(2L)
        assertNotNull(second)
        assertTrue("frame ids are never reused", second!! > first!!)
    }

    @Test
    fun pausedAnalysisReservesNoFrames() {
        val s = session()
        s.startCapture()
        s.pauseAnalysis()
        assertNull(s.beginFrame(0L))
        s.resumeAnalysis()
        assertNotNull(s.beginFrame(1L))
    }

    @Test
    fun framesAreThrottledToTheMinimumInterval() {
        val s = session(minFrameIntervalMs = 400L)
        s.startCapture()
        assertNotNull(s.beginFrame(1_000L))
        s.abandonFrame("done")
        assertNull("too soon", s.beginFrame(1_100L))
        assertNotNull(s.beginFrame(1_400L))
    }
}
