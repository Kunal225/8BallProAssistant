package com.eightballpro.assistant.data.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.settings.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * Integration tests: a real DataStore backed by a file on the JVM file system.
 * No Android device or emulator is needed. Not executed in the authoring environment.
 */
class SettingsRepositoryIntegrationTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun storeFile(name: String = "settings.preferences_pb"): File = tmp.root.resolve(name)

    private fun createStore(file: File, job: Job): DataStore<Preferences> =
        PreferenceDataStoreFactory.create(
            scope = CoroutineScope(Dispatchers.IO + job),
            produceFile = { file },
        )

    /** Opens a repository on [file] for the duration of [block], then stops the DataStore scope. */
    private suspend fun withRepository(file: File, block: suspend (SettingsRepository) -> Unit) {
        val job = SupervisorJob()
        try {
            block(SettingsRepository(createStore(file, job)))
        } finally {
            job.cancelAndJoin()
        }
    }

    @Test
    fun emptyStoreReturnsDefaults() = runBlocking<Unit> {
        withRepository(storeFile()) { repo ->
            assertEquals(AppSettings(), repo.settings.first())
        }
    }

    @Test
    fun updatePhysicsIsReadBackFromTheSameStore() = runBlocking<Unit> {
        withRepository(storeFile()) { repo ->
            val result = repo.updatePhysics { it.copy(slidingFriction = 0.33) }
            assertTrue(result.isSuccess)
            assertEquals(0.33, repo.settings.first().physics.slidingFriction, 1e-12)
        }
    }

    @Test
    fun settingsSurviveRecreatingTheStore() = runBlocking<Unit> {
        val file = storeFile()
        withRepository(file) { repo ->
            repo.updatePhysics { it.copy(slidingFriction = 0.33, ballRestitution = 0.9) }
            repo.setKeepScreenOn(true)
            repo.setShowGuideLines(false)
        }
        // Second store instance on the same file simulates an app restart.
        withRepository(file) { repo ->
            val s = repo.settings.first()
            assertEquals(0.33, s.physics.slidingFriction, 1e-12)
            assertEquals(0.9, s.physics.ballRestitution, 1e-12)
            assertTrue(s.keepScreenOn)
            assertFalse(s.showGuideLines)
        }
    }

    @Test
    fun invalidUpdateIsRejectedAndNothingIsStored() = runBlocking<Unit> {
        withRepository(storeFile()) { repo ->
            val result = repo.updatePhysics { it.copy(slidingFriction = 9.0) }
            assertTrue(result.isFailure)
            assertEquals(PhysicsConfig.DEFAULT, repo.settings.first().physics)
        }
    }

    @Test
    fun outOfRangeStoredValueFallsBackToDefaultPhysics() = runBlocking<Unit> {
        val job = SupervisorJob()
        try {
            val store = createStore(storeFile(), job)
            // Write an invalid value directly, using the same key name the repository uses.
            store.edit { it[doublePreferencesKey("physics_sliding_friction")] = 9.0 }
            assertEquals(PhysicsConfig.DEFAULT, SettingsRepository(store).settings.first().physics)
        } finally {
            job.cancelAndJoin()
        }
    }

    @Test
    fun newPhysicsFieldsPersistAcrossRestart() = runBlocking<Unit> {
        val file = storeFile()
        withRepository(file) { repo ->
            repo.updatePhysics { it.copy(ballFriction = 0.12, clothRestitution = 0.6) }
        }
        withRepository(file) { repo ->
            val p = repo.settings.first().physics
            assertEquals(0.12, p.ballFriction, 1e-12)
            assertEquals(0.6, p.clothRestitution, 1e-12)
        }
    }
}
