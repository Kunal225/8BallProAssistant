package com.eightballpro.assistant.android.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/** Reader replacement on rotation, with fake readers that log what happens to them. */
class ReaderSwapTest {

    private class FakeReader(val name: String) {
        var closed = false
    }

    private class Env(
        var createFails: Boolean = false,
        var attachFails: Boolean = false,
        var restoreFails: Boolean = false,
        var releaseFails: Boolean = false,
    ) {
        val log = mutableListOf<String>()
        val created = mutableListOf<FakeReader>()

        fun swap(previous: FakeReader?): ReaderSwap.Outcome<FakeReader> = ReaderSwap.swap(
            previous = previous,
            create = {
                log += "create"
                if (createFails) throw IllegalStateException("no reader")
                FakeReader("new").also { created += it }
            },
            attach = {
                log += "attach:${it.name}"
                if (attachFails) throw IllegalStateException("cannot attach")
            },
            restore = {
                log += "restore:${it.name}"
                if (restoreFails) throw IllegalStateException("cannot restore")
            },
            release = {
                log += "release:${it.name}"
                it.closed = true
                if (releaseFails) throw IllegalStateException("cannot close")
            },
        )
    }

    // Scenario D: rotation replaces the reader without leaking.
    @Test
    fun aSuccessfulReplacementActivatesTheNewReaderAndReleasesTheOldOneAfterwards() {
        val env = Env()
        val old = FakeReader("old")

        val outcome = env.swap(old)

        assertTrue(outcome is ReaderSwap.Outcome.Replaced)
        assertSame(env.created.single(), (outcome as ReaderSwap.Outcome.Replaced).active)
        assertEquals(listOf("create", "attach:new", "release:old"), env.log)
        assertTrue(old.closed)
        assertFalse(env.created.single().closed)
    }

    // Scenario E: a failed replacement does not destroy the previous working reader.
    @Test
    fun aFailedAttachReleasesTheNewReaderAndKeepsTheOldOne() {
        val env = Env(attachFails = true)
        val old = FakeReader("old")

        val outcome = env.swap(old)

        assertTrue(outcome is ReaderSwap.Outcome.KeptPrevious)
        assertSame(old, (outcome as ReaderSwap.Outcome.KeptPrevious).active)
        assertFalse("the old reader must stay open", old.closed)
        assertTrue("the new reader must not leak", env.created.single().closed)
        assertEquals(listOf("create", "attach:new", "release:new", "restore:old"), env.log)
    }

    @Test
    fun aFailedCreateKeepsTheOldReaderAndLeavesNothingBehind() {
        val env = Env(createFails = true)
        val old = FakeReader("old")

        val outcome = env.swap(old)

        assertTrue(outcome is ReaderSwap.Outcome.KeptPrevious)
        assertFalse(old.closed)
        assertTrue(env.created.isEmpty())
    }

    @Test
    fun ifTheOldReaderCannotBePutBackTheOutcomeIsFailedAndTheNewReaderIsStillReleased() {
        val env = Env(attachFails = true, restoreFails = true)
        val old = FakeReader("old")

        val outcome = env.swap(old)

        assertSame(ReaderSwap.Outcome.Failed, outcome)
        assertTrue(env.created.single().closed)
    }

    @Test
    fun withoutAPreviousReaderAFailedAttachIsFailedAndTheNewReaderIsReleased() {
        val env = Env(attachFails = true)

        val outcome = env.swap(null)

        assertSame(ReaderSwap.Outcome.Failed, outcome)
        assertTrue(env.created.single().closed)
        assertFalse(env.log.any { it.startsWith("restore") })
    }

    @Test
    fun withoutAPreviousReaderASuccessfulAttachJustActivatesTheNewOne() {
        val env = Env()
        val outcome = env.swap(null)
        assertTrue(outcome is ReaderSwap.Outcome.Replaced)
        assertEquals(listOf("create", "attach:new"), env.log)
    }

    @Test
    fun anOldReaderThatWillNotCloseStillCountsAsAReplacement() {
        val env = Env(releaseFails = true)
        val old = FakeReader("old")

        val outcome = env.swap(old)

        assertTrue(outcome is ReaderSwap.Outcome.Replaced)
        assertTrue("release was attempted", old.closed)
    }

    @Test
    fun repeatedRotationsNeverLeaveMoreThanOneOpenReader() {
        val env = Env()
        var current: FakeReader = FakeReader("old")
        val all = mutableListOf(current)
        repeat(10) { i ->
            env.attachFails = i % 3 == 1 // some rotations fail
            when (val outcome = env.swap(current)) {
                is ReaderSwap.Outcome.Replaced -> { current = outcome.active; all += outcome.active }
                is ReaderSwap.Outcome.KeptPrevious -> current = outcome.active
                ReaderSwap.Outcome.Failed -> error("a swap with a restorable previous reader must not fail")
            }
        }
        val open = (all + env.created).distinct().filter { !it.closed }
        assertEquals(listOf(current), open)
    }
}
