package com.eightballpro.assistant.domain.analysis

import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.table.TableSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AngleAnalyzerTest {

    private val table = TableGeometry3D.from(TableSpec.NINE_FOOT)
    private val cuePos = Vec3(0.5, 0.635, BallPhysics.RADIUS_M)

    @Test
    fun calculatesHorizontalAimAngle() {
        val dir = Vec3(1.0, 0.0, 0.0)
        val analysis = AngleAnalyzer.analyze(cuePos, dir, emptyList(), table)
        assertEquals(0.0, analysis.aimAngleDeg, 1e-6)
    }

    @Test
    fun calculatesCutAndImpactAngleForObjectBallCollision() {
        val dir = Vec3(1.0, 0.0, 0.0)
        val objectBall = PoolBall(1, Vec3(1.0, 0.65, BallPhysics.RADIUS_M))
        val analysis = AngleAnalyzer.analyze(cuePos, dir, listOf(objectBall), table)

        assertNotNull(analysis.cutAngleDeg)
        assertNotNull(analysis.impactAngleDeg)
        assertEquals(1, analysis.targetBallId)
        assertTrue(analysis.summaryText.contains("Target Ball: 1"))
    }
}
