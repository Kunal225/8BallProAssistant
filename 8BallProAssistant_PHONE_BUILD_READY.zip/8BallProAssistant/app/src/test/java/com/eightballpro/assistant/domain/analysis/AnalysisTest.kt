package com.eightballpro.assistant.domain.analysis

import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.CUE_BALL_ID
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.table.TableSpec
import com.eightballpro.assistant.domain.vision.Assessment
import com.eightballpro.assistant.domain.vision.BallClass
import com.eightballpro.assistant.domain.vision.Confidence
import com.eightballpro.assistant.domain.vision.Point2D
import com.eightballpro.assistant.domain.vision.SyntheticImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AnalysisPipelineTest {

    /**
     * The synthetic balls are 8 px in radius on a 200 px table. Real balls are 1.1 % of table length, so
     * the test sets the ratio to match the synthetic scale. The default ratio is tested separately below.
     */
    private val syntheticConfig = AnalysisConfig(ballRadiusToTableLength = 0.04)

    @Test
    fun findsCueAndObjectWithNormalisedPositions() {
        val result = AnalysisPipeline(syntheticConfig).analyze(SyntheticImage.twoBallTable())
        assertNotNull(result.table)
        assertEquals(2, result.balls.size)
        val cue = result.balls.first { it.cls == BallClass.CUE }
        val object1 = result.balls.first { it.cls == BallClass.OBJECT }
        assertEquals(0.2, cue.centre.x, 0.01)
        assertEquals(0.5, cue.centre.y, 0.01)
        assertEquals(0.65, object1.centre.x, 0.01)
        assertEquals(0.4, object1.centre.y, 0.01)
        assertEquals(Confidence.HIGH, cue.assessment.level)
        assertFalse(result.warnings.any { it.contains("Cue ball not identified") })
    }

    @Test
    fun defaultBallRatioFlagsSyntheticSizeAsUncertain() {
        // Default ratio expects a ball about 2 px in radius on this 200 px table, so the size check fails honestly.
        val result = AnalysisPipeline().analyze(SyntheticImage.twoBallTable())
        assertTrue(result.balls.isNotEmpty())
        assertTrue(result.balls.none { it.assessment.level == Confidence.HIGH })
        assertTrue(result.balls.any { a -> a.assessment.reasons.any { it.contains("size") } })
    }

    @Test
    fun imageWithoutTableReportsAWarningAndNoBalls() {
        val result = AnalysisPipeline().analyze(SyntheticImage(64, 32).build())
        assertNull(result.table)
        assertTrue(result.balls.isEmpty())
        assertTrue(result.warnings.first().contains("No table detected"))
    }

    @Test
    fun manualEditsMoveReplaceAndAddBalls() {
        val auto = AnalysisPipeline(syntheticConfig).analyze(SyntheticImage.twoBallTable()).balls
        val cueIndex = auto.indexOfFirst { it.cls == BallClass.CUE }
        val edited = ManualEdits.apply(
            auto,
            listOf(
                ManualEdit(index = cueIndex, cls = BallClass.CUE, centre = Point2D(0.3, 0.5)),
                ManualEdit(index = null, cls = BallClass.BLACK, centre = Point2D(0.8, 0.5)),
            ),
        )
        assertEquals(3, edited.size)
        assertEquals(Confidence.USER_CONFIRMED, edited[cueIndex].assessment.level)
        assertEquals(0.3, edited[cueIndex].centre.x, 1e-12)
        assertEquals(BallClass.BLACK, edited.last().cls)
    }

    @Test
    fun removeDropsOnlyTheRequestedIndices() {
        val balls = listOf(
            DetectedBall(null, BallClass.CUE, Point2D(0.1, 0.1), Assessment(1.0, Confidence.HIGH, emptyList()), DetectionSource.AUTO),
            DetectedBall(null, BallClass.OBJECT, Point2D(0.2, 0.2), Assessment(1.0, Confidence.HIGH, emptyList()), DetectionSource.AUTO),
        )
        val kept = ManualEdits.remove(balls, setOf(1))
        assertEquals(1, kept.size)
        assertEquals(BallClass.CUE, kept.single().cls)
    }
}

class DetectionToPhysicsTest {

    private val table = TableGeometry3D.from(TableSpec.NINE_FOOT)

    private fun detection(cls: BallClass, u: Double, v: Double, level: Confidence, score: Double = 0.9) = DetectedBall(
        id = null, cls = cls, centre = Point2D(u, v),
        assessment = Assessment(score, level, emptyList()), source = DetectionSource.AUTO,
    )

    @Test
    fun cueMapsToMetresOnTheCloth() {
        val input = DetectionToPhysics.build(listOf(detection(BallClass.CUE, 0.2, 0.5, Confidence.HIGH)), table)
        val cue = input.balls.single()
        assertEquals(CUE_BALL_ID, cue.id)
        assertEquals(0.2 * 2.54, cue.position.x, 1e-9)
        assertEquals(0.5 * 1.27, cue.position.y, 1e-9)
        assertEquals(BallPhysics.RADIUS_M, cue.position.z, 1e-12)
    }

    @Test
    fun uncertainBallsAreExcludedWithAWarning() {
        val input = DetectionToPhysics.build(
            listOf(
                detection(BallClass.CUE, 0.2, 0.5, Confidence.HIGH),
                detection(BallClass.OBJECT, 0.6, 0.4, Confidence.UNCERTAIN),
            ),
            table,
        )
        assertEquals(1, input.balls.size)
        assertEquals(1, input.excluded.size)
        assertTrue(input.warnings.any { it.contains("excluded") })
    }

    @Test
    fun missingCueIsWarned() {
        val input = DetectionToPhysics.build(listOf(detection(BallClass.OBJECT, 0.6, 0.4, Confidence.HIGH)), table)
        assertTrue(input.balls.none { it.isCue })
        assertTrue(input.warnings.any { it.contains("No confident cue ball") })
    }

    @Test
    fun ballOutsidePlayAreaIsExcluded() {
        val input = DetectionToPhysics.build(
            listOf(detection(BallClass.CUE, 0.2, 0.5, Confidence.HIGH), detection(BallClass.OBJECT, 0.001, 0.5, Confidence.HIGH)),
            table,
        )
        assertEquals(1, input.balls.size)
        assertTrue(input.warnings.any { it.contains("outside the playing area") })
    }

    @Test
    fun manualUserConfirmedBallsAreUsed() {
        val input = DetectionToPhysics.build(
            listOf(
                detection(BallClass.CUE, 0.2, 0.5, Confidence.HIGH),
                detection(BallClass.OBJECT, 0.6, 0.4, Confidence.USER_CONFIRMED),
            ),
            table,
        )
        assertEquals(2, input.balls.size)
    }
}

class ShotPredictionTest {

    private val table = TableGeometry3D.from(TableSpec.NINE_FOOT)
    private val config = PhysicsConfig()

    private fun input(): PhysicsInput = DetectionToPhysics.build(
        listOf(
            DetectedBall(null, BallClass.CUE, Point2D(0.2, 0.5), Assessment(0.9, Confidence.HIGH, emptyList()), DetectionSource.AUTO),
            DetectedBall(null, BallClass.OBJECT, Point2D(0.6, 0.5), Assessment(0.9, Confidence.HIGH, emptyList()), DetectionSource.AUTO),
        ),
        table,
    )

    @Test
    fun noCueMeansNoPrediction() {
        val empty = PhysicsInput(balls = emptyList(), excluded = emptyList(), warnings = emptyList())
        assertNull(ShotPrediction.predict(empty, table, config, Vec3(1.0, 0.0, 0.0), 1.0, 0.0, 0.0, 0.0))
    }

    @Test
    fun predictionMovesTheCueAlongTheDirection() {
        val result = ShotPrediction.predict(input(), table, config, Vec3(1.0, 0.0, 0.0), 1.5, 0.0, 0.0, 0.0)!!
        val cueStart = input().balls.first { it.isCue }.position
        val cueFinal = result.finalBalls.first { it.isCue }.position
        assertTrue(cueFinal.x > cueStart.x)
        assertEquals(cueStart.y, cueFinal.y, 1e-6)
    }

    @Test
    fun predictionDoesNotModifyTheInputAndIsDeterministic() {
        val inputBefore = input()
        val a = ShotPrediction.predict(inputBefore, table, config, Vec3(1.0, 0.0, 0.0), 1.5, 0.2, -0.1, 0.0)!!
        val b = ShotPrediction.predict(inputBefore, table, config, Vec3(1.0, 0.0, 0.0), 1.5, 0.2, -0.1, 0.0)!!
        assertEquals(input().balls, inputBefore.balls)
        assertEquals(a.finalBalls, b.finalBalls)
        assertEquals(a.collisionCount, b.collisionCount)
    }
}
