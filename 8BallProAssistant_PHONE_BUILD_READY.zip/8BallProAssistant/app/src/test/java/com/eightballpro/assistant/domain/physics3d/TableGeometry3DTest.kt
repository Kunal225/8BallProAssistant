package com.eightballpro.assistant.domain.physics3d

import com.eightballpro.assistant.domain.table.PocketPosition
import com.eightballpro.assistant.domain.table.TableSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TableGeometry3DTest {

    private val table = TableGeometry3D.from(TableSpec.NINE_FOOT)

    @Test
    fun convertsNineFootTableToMetres() {
        assertEquals(2.54, table.length, 1e-12)
        assertEquals(1.27, table.width, 1e-12)
        assertEquals(6, table.pockets.size)
    }

    @Test
    fun cornerAndSidePocketsHaveTheirCaptureRadii() {
        val corner = table.pockets.first { it.name == PocketPosition.TOP_LEFT }
        val side = table.pockets.first { it.name == PocketPosition.TOP_MIDDLE }
        assertTrue(corner.isCorner)
        assertFalse(side.isCorner)
        assertEquals(TableGeometry3D.CORNER_CAPTURE_M, corner.captureRadius, 1e-12)
        assertEquals(TableGeometry3D.SIDE_CAPTURE_M, side.captureRadius, 1e-12)
    }

    @Test
    fun ballCentreInsideCushionsIsInPlayAreaAndOutsideIsNot() {
        val r = BallPhysics.RADIUS_M
        assertTrue(table.isInsidePlayArea(Vec3(1.0, 0.6, r)))
        assertTrue(table.isInsidePlayArea(Vec3(r, r, r)))
        assertFalse(table.isInsidePlayArea(Vec3(r / 2, 0.6, r)))
    }

    @Test
    fun ballNearPocketIsCapturedAndDistantBallIsNot() {
        val nearCorner = Vec3(0.02, 0.02, BallPhysics.RADIUS_M)
        assertEquals(PocketPosition.TOP_LEFT, table.capturingPocket(nearCorner)?.name)
        assertNull(table.capturingPocket(Vec3(1.0, 0.6, BallPhysics.RADIUS_M)))
    }
}
