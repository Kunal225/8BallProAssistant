package com.eightballpro.assistant.domain.overlay

import org.junit.Assert.assertEquals
import org.junit.Test

class OverlayStateMachineTest {

    private val screen = ScreenBounds(width = 1080, height = 2400)

    private fun reduce(state: OverlayState, event: OverlayEvent) = OverlayStateMachine.reduce(state, event, screen)

    @Test
    fun permissionFlowMovesFromNeedsPermissionToBubbleAtDefaultPosition() {
        var s: OverlayState = OverlayState.Hidden
        s = reduce(s, OverlayEvent.PermissionMissing)
        assertEquals(OverlayState.NeedsPermission, s)
        s = reduce(s, OverlayEvent.PermissionGranted(savedPosition = null))
        // Default: right edge, one third down the screen. x = 1080 - 56 - 8, y = 2400 / 3.
        assertEquals(OverlayState.Bubble(OverlayPosition(1016, 800)), s)
    }

    @Test
    fun showBubbleRestoresSavedPositionWhenItIsOnScreen() {
        val s = reduce(OverlayState.Hidden, OverlayEvent.ShowBubble(OverlayPosition(100, 200)))
        assertEquals(OverlayState.Bubble(OverlayPosition(100, 200)), s)
    }

    @Test
    fun savedPositionOffScreenIsClampedInsideTheMargin() {
        val s = reduce(OverlayState.Hidden, OverlayEvent.ShowBubble(OverlayPosition(5000, -10)))
        assertEquals(OverlayState.Bubble(OverlayPosition(1016, 8)), s)
    }

    @Test
    fun tapOpensPanelAndMinimizeReturnsToBubble() {
        val bubble = OverlayState.Bubble(OverlayPosition(1016, 800))
        val panel = reduce(bubble, OverlayEvent.TapBubble)
        // The 320 px panel is clamped inside the right margin: x = 1080 - 320 - 8 = 752.
        assertEquals(OverlayState.Panel(OverlayPosition(752, 800)), panel)
        assertEquals(OverlayState.Bubble(OverlayPosition(752, 800)), reduce(panel, OverlayEvent.Minimize))
    }

    @Test
    fun closeAlwaysHides() {
        assertEquals(OverlayState.Hidden, reduce(OverlayState.Bubble(OverlayPosition(10, 10)), OverlayEvent.Close))
        assertEquals(OverlayState.Hidden, reduce(OverlayState.Panel(OverlayPosition(10, 10)), OverlayEvent.Close))
        assertEquals(OverlayState.Hidden, reduce(OverlayState.NeedsPermission, OverlayEvent.Close))
    }

    @Test
    fun dragMovesTheBubbleAndClampsToScreen() {
        val s = reduce(OverlayState.Bubble(OverlayPosition(100, 100)), OverlayEvent.Drag(dx = -500, dy = -500))
        assertEquals(OverlayState.Bubble(OverlayPosition(8, 8)), s)
    }

    @Test
    fun snapToNearestEdgeMovesTowardTheCloserSide() {
        // Centre x = 300 + 28 = 328, which is left of 540, so the bubble snaps to the left margin.
        val s = reduce(OverlayState.Bubble(OverlayPosition(300, 500)), OverlayEvent.SnapToNearestEdge)
        assertEquals(OverlayState.Bubble(OverlayPosition(8, 500)), s)
    }

    @Test
    fun invalidEventsAreIgnored() {
        assertEquals(OverlayState.Hidden, reduce(OverlayState.Hidden, OverlayEvent.TapBubble))
        assertEquals(OverlayState.Hidden, reduce(OverlayState.Hidden, OverlayEvent.Drag(5, 5)))
        assertEquals(OverlayState.NeedsPermission, reduce(OverlayState.NeedsPermission, OverlayEvent.Minimize))
    }

    @Test
    fun permissionMissingDoesNotOverwriteAVisibleBubble() {
        val bubble = OverlayState.Bubble(OverlayPosition(10, 10))
        assertEquals(bubble, reduce(bubble, OverlayEvent.PermissionMissing))
    }
}
