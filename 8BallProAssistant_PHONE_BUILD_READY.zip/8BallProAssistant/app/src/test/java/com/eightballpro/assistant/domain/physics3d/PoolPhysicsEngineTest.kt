package com.eightballpro.assistant.domain.physics3d

import com.eightballpro.assistant.domain.physics.PhysicsConfig
import com.eightballpro.assistant.domain.table.PocketPosition
import com.eightballpro.assistant.domain.table.TableSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Engine tests. The expected values come from analytic results for solid spheres. The same
 * expectations were checked against an independent numerical model during development.
 */
class PoolPhysicsEngineTest {

    private val r = BallPhysics.RADIUS_M
    private val g = BallPhysics.GRAVITY
    private val table = TableGeometry3D.from(TableSpec.NINE_FOOT)
    private val midY = table.width / 2.0

    private fun engine(config: PhysicsConfig = PhysicsConfig(rollingFriction = 0.001), dt: Double = 2e-5) =
        PoolPhysicsEngine(table, config, dt)

    private fun ball(id: Int, x: Double, y: Double, vx: Double = 0.0, vy: Double = 0.0) =
        PoolBall(id, Vec3(x, y, r), Vec3(vx, vy, 0.0))

    /** Horizontal slip speed at the contact point. Zero means pure rolling. */
    private fun floorSlip(b: PoolBall): Double {
        val contact = b.velocity + b.angularVelocity.cross(Vec3(0.0, 0.0, -r))
        return Vec3(contact.x, contact.y, 0.0).length()
    }

    @Test
    fun slidingBallReachesRollingAtFiveSeventhsOfItsSpeedAfterTheExpectedTime() {
        val e = engine()
        var state = WorldState(0.0, listOf(ball(0, 0.5, 0.5, vx = 2.0)))
        while (state.time < 2.0) {
            state = e.step(state).state
            if (state.time > 0.01 && floorSlip(state.balls[0]) < 1e-5) break
        }
        val b = state.balls[0]
        val expectedTime = 2 * 2.0 / (7 * 0.2 * g)
        assertEquals(5.0 / 7.0 * 2.0, b.velocity.x, 0.03)
        assertEquals(expectedTime, state.time, 0.03 * expectedTime)
        assertEquals(b.velocity.x, b.angularVelocity.y * r, 0.03)
    }

    @Test
    fun topSpinShotRollsOutAtTenSeventhsOfItsSpeed() {
        val e = engine()
        val struck = CueStrike.apply(
            PoolBall(CUE_BALL_ID, Vec3(0.5, 0.5, r)), Vec3(1.0, 0.0, 0.0),
            speed = 2.0, sideOffset = 0.0, heightOffset = 1.0, elevationRad = 0.0,
        )
        var state = WorldState(0.0, listOf(struck))
        while (state.time < 3.0) {
            state = e.step(state).state
            if (state.time > 0.01 && floorSlip(state.balls[0]) < 1e-5) break
        }
        assertEquals(10.0 / 7.0 * 2.0, state.balls[0].velocity.x, 0.04)
    }

    @Test
    fun rollingResistanceDeceleratesARollingBallAtMuTimesGOverOnePointFour() {
        val config = PhysicsConfig(rollingFriction = 0.01)
        val e = engine(config, dt = 2e-5)
        var state = WorldState(0.0, listOf(PoolBall(0, Vec3(0.5, 0.5, r), Vec3(2.0, 0.0, 0.0), Vec3(0.0, 2.0 / r, 0.0))))
        val steps = (1.0 / 2e-5).toInt()
        repeat(steps) { state = e.step(state).state }
        val expectedDeceleration = 0.01 * g / (1.0 + BallPhysics.INERTIA / (BallPhysics.MASS_KG * r * r))
        assertEquals(2.0 - expectedDeceleration, state.balls[0].velocity.x, 0.002)
    }

    @Test
    fun droppedBallRebondsAtRestitutionSpeedAndApexScalesWithRestitutionSquared() {
        val e = engine(PhysicsConfig(clothRestitution = 0.5), dt = 2e-5)
        val h = 0.1
        var state = WorldState(0.0, listOf(PoolBall(0, Vec3(0.5, 0.5, r + h))))
        var impactSpeed = -1.0
        var apex = 0.0
        var bounced = false
        while (state.time < 2.0) {
            val before = state.balls[0].velocity.z
            state = e.step(state).state
            val b = state.balls[0]
            if (!bounced && before < 0.0 && b.velocity.z > 0.0) {
                impactSpeed = -before
                bounced = true
            }
            if (bounced) apex = maxOf(apex, b.position.z - r)
            if (bounced && b.velocity.z < 0.0) break
        }
        assertTrue("ball should bounce", bounced)
        assertEquals(Math.sqrt(2 * g * h), impactSpeed, 0.01 * Math.sqrt(2 * g * h))
        assertEquals(0.25, apex / h, 0.03)
    }

    @Test
    fun cueBallStrikesObjectBallAndTransfersMomentum() {
        val cue = ball(CUE_BALL_ID, 0.5, midY, vx = 1.5)
        val target = ball(1, 0.9, midY)
        val result = engine().simulate(listOf(cue, target), maxTime = 3.0)
        assertTrue(result.collisionCount >= 1)
        val objectFinal = result.finalBalls.first { it.id == 1 }
        assertTrue("object ball should move forward", objectFinal.position.x > 0.95)
    }

    @Test
    fun ballRollingIntoCornerIsPocketed() {
        val start = PoolBall(CUE_BALL_ID, Vec3(0.09, 0.09, r), Vec3(-0.7, -0.7, 0.0))
        val result = engine().simulate(listOf(start), maxTime = 2.0, sampleInterval = 1.0 / 60.0)
        assertEquals(PocketPosition.TOP_LEFT, result.pocketed.single().pocket)
        assertTrue(result.cuePocketed)
    }

    @Test
    fun ballHeadingForRailRebounds() {
        val start = ball(CUE_BALL_ID, 0.3, midY, vx = -1.0)
        val result = engine().simulate(listOf(start), maxTime = 1.0)
        assertTrue(result.events.filterIsInstance<CushionImpact>().any { it.cushionIndex == 0 })
        assertTrue(result.finalBalls.single().position.x > r)
    }

    @Test
    fun simulationIsDeterministic() {
        val balls = listOf(
            CueStrike.apply(PoolBall(CUE_BALL_ID, Vec3(0.5, midY, r)), Vec3(1.0, 0.1, 0.0), 2.5, 0.2, -0.3, 0.0),
            ball(1, 1.0, midY + 0.02),
        )
        val a = engine().simulate(balls, maxTime = 4.0)
        val b = engine().simulate(balls, maxTime = 4.0)
        assertEquals(a.finalBalls, b.finalBalls)
        assertEquals(a.events, b.events)
    }

    @Test
    fun stationaryBallsEndTheSimulationImmediately() {
        val result = engine().simulate(listOf(ball(CUE_BALL_ID, 0.5, midY)), maxTime = 5.0)
        assertEquals(0.0, result.duration, 0.0)
        assertEquals(0.0, result.cueDistance, 0.0)
    }
}
