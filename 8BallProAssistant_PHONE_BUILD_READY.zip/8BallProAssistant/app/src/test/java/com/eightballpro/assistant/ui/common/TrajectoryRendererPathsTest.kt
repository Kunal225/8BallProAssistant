package com.eightballpro.assistant.ui.common

import com.eightballpro.assistant.domain.assistant.AimSource
import com.eightballpro.assistant.domain.physics3d.BallCollision
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.CUE_BALL_ID
import com.eightballpro.assistant.domain.physics3d.CushionImpact
import com.eightballpro.assistant.domain.physics3d.Frame
import com.eightballpro.assistant.domain.physics3d.Vec3
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrajectoryRendererPathsTest {

    private val length = 2.0
    private val width = 1.0
    private val r = BallPhysics.RADIUS_M

    private fun frame(time: Double, vararg balls: Pair<Int, Pair<Double, Double>>) =
        Frame(time, balls.associate { (id, p) -> id to Vec3(p.first, p.second, r) })

    // ---- physicsPaths ----

    @Test
    fun pathsAreTheSampledPhysicsPositionsInTableUnits() {
        val frames = listOf(
            frame(0.0, CUE_BALL_ID to (0.5 to 0.5), 3 to (1.0 to 0.5)),
            frame(0.1, CUE_BALL_ID to (0.7 to 0.5), 3 to (1.0 to 0.5)),
            frame(0.2, CUE_BALL_ID to (0.9 to 0.5), 3 to (1.2 to 0.6)),
        )
        val paths = TrajectoryRenderer.physicsPaths(frames, length, width)

        assertEquals(3, paths.cuePath.size)
        assertEquals(0.25, paths.cuePath[0].u, 1e-12)
        assertEquals(0.5, paths.cuePath[0].v, 1e-12)
        assertEquals(0.45, paths.cuePath[2].u, 1e-12)
        assertEquals(listOf(3), paths.objectPaths.keys.toList())
        assertEquals(0.6, paths.objectPaths.getValue(3)[2].u, 1e-12)
        assertEquals(0.6, paths.objectPaths.getValue(3)[2].v, 1e-12)
    }

    @Test
    fun noFramesGiveNoPaths() {
        val paths = TrajectoryRenderer.physicsPaths(emptyList(), length, width)
        assertTrue(paths.cuePath.isEmpty())
        assertTrue(paths.objectPaths.isEmpty())
    }

    @Test
    fun objectBallsThatBarelyMoveAreLeftOutOnlyWhenAMinimumIsGiven() {
        val frames = listOf(
            frame(0.0, CUE_BALL_ID to (0.5 to 0.5), 3 to (1.0 to 0.5), 4 to (1.4 to 0.5)),
            frame(0.1, CUE_BALL_ID to (0.7 to 0.5), 3 to (1.0 to 0.5), 4 to (1.5 to 0.5)),
        )
        assertEquals(setOf(3, 4), TrajectoryRenderer.physicsPaths(frames, length, width).objectPaths.keys)
        assertEquals(
            setOf(4),
            TrajectoryRenderer.physicsPaths(frames, length, width, minObjectMovementM = 0.01).objectPaths.keys,
        )
    }

    @Test
    fun positionsFarOutsideTheTableAreSkipped() {
        val frames = listOf(
            frame(0.0, CUE_BALL_ID to (0.5 to 0.5)),
            frame(0.1, CUE_BALL_ID to (5.0 to 0.5)),
            frame(0.2, CUE_BALL_ID to (0.6 to 0.5)),
        )
        assertEquals(2, TrajectoryRenderer.physicsPaths(frames, length, width).cuePath.size)
    }

    // ---- firstCueContact ----

    private fun collision(time: Double, a: Int, b: Int, point: Vec3?) = BallCollision(time, a, b, 1.0, point)

    @Test
    fun contactIsTheFirstCueCollisionPoint() {
        val events = listOf(
            collision(0.30, CUE_BALL_ID, 2, Vec3(1.0, 0.5, r)),
            collision(0.50, 2, 5, Vec3(1.5, 0.5, r)),
        )
        val contact = TrajectoryRenderer.firstCueContact(events, length, width)
        assertNotNull(contact)
        assertEquals(0.5, contact!!.u, 1e-12)
        assertEquals(0.5, contact.v, 1e-12)
    }

    @Test
    fun contactIgnoresCollisionsBetweenOtherBallsEvenWhenTheyHappenFirst() {
        val events = listOf(
            collision(0.10, 2, 5, Vec3(0.2, 0.2, r)),
            collision(0.40, 7, CUE_BALL_ID, Vec3(1.0, 0.25, r)),
        )
        val contact = TrajectoryRenderer.firstCueContact(events, length, width)!!
        assertEquals(0.5, contact.u, 1e-12)
        assertEquals(0.25, contact.v, 1e-12)
    }

    @Test
    fun contactIsTheEarliestCueCollisionEvenIfTheListIsNotSorted() {
        val events = listOf(
            collision(0.80, CUE_BALL_ID, 3, Vec3(1.6, 0.5, r)),
            collision(0.20, CUE_BALL_ID, 2, Vec3(0.4, 0.5, r)),
        )
        assertEquals(0.2, TrajectoryRenderer.firstCueContact(events, length, width)!!.u, 1e-12)
    }

    @Test
    fun noCueCollisionGivesNoContact() {
        val events = listOf(
            collision(0.10, 2, 5, Vec3(0.2, 0.2, r)),
            CushionImpact(0.2, CUE_BALL_ID, 1, 1.0),
        )
        assertNull(TrajectoryRenderer.firstCueContact(events, length, width))
        assertNull(TrajectoryRenderer.firstCueContact(emptyList(), length, width))
    }

    @Test
    fun aCollisionWithoutAPositionGivesNoContactInsteadOfAGuess() {
        val events = listOf(collision(0.30, CUE_BALL_ID, 2, null))
        assertNull(TrajectoryRenderer.firstCueContact(events, length, width))
    }

    // ---- aimAngleDegrees ----

    @Test
    fun aimAngleFollowsTheTableAxes() {
        assertEquals(0.0, TrajectoryRenderer.aimAngleDegrees(0.25, 0.5, 0.75, 0.5, length, width)!!, 1e-9)
        assertEquals(90.0, TrajectoryRenderer.aimAngleDegrees(0.25, 0.5, 0.25, 1.0, length, width)!!, 1e-9)
        assertEquals(180.0, TrajectoryRenderer.aimAngleDegrees(0.75, 0.5, 0.25, 0.5, length, width)!!, 1e-9)
        assertEquals(270.0, TrajectoryRenderer.aimAngleDegrees(0.25, 0.5, 0.25, 0.0, length, width)!!, 1e-9)
    }

    @Test
    fun aimAngleUsesMetresNotNormalisedUnits() {
        // 0.1 of the length is 0.2 m and 0.2 of the width is 0.2 m, so the line is at 45 degrees.
        assertEquals(45.0, TrajectoryRenderer.aimAngleDegrees(0.5, 0.5, 0.6, 0.7, length, width)!!, 1e-9)
    }

    @Test
    fun aimAngleIsUndefinedWhenTheTargetIsTheCueBall() {
        assertNull(TrajectoryRenderer.aimAngleDegrees(0.4, 0.4, 0.4, 0.4, length, width))
    }

    // ---- overlayLayers ----

    private fun layers(
        live: Boolean = true,
        cue: Boolean = true,
        source: AimSource,
        detectedNow: Boolean = false,
        prediction: Boolean = true,
        shot: Boolean = true,
    ) = TrajectoryRenderer.overlayLayers(live, cue, source, detectedNow, prediction, shot)

    @Test
    fun aManualAimShowsThePreviewAndAnAvailablePredictionShowsThePhysics() {
        val l = layers(source = AimSource.USER_MANUAL)
        assertTrue(l.aimPreview)
        assertTrue(l.physicsPaths)
    }

    @Test
    fun aManualAimWithoutAPredictionShowsOnlyThePreview() {
        val l = layers(source = AimSource.USER_MANUAL, prediction = false)
        assertTrue(l.aimPreview)
        assertFalse(l.physicsPaths)
        assertFalse(layers(source = AimSource.USER_MANUAL, shot = false).physicsPaths)
    }

    @Test
    fun anAutoAimIsShownOnlyWhileItIsDetectedInTheCurrentFrame() {
        assertTrue(layers(source = AimSource.AUTO_DETECTION, detectedNow = true).aimPreview)
        val stale = layers(source = AimSource.AUTO_DETECTION, detectedNow = false)
        assertFalse(stale.aimPreview)
        assertFalse(stale.physicsPaths)
    }

    @Test
    fun nothingAimRelatedIsDrawnOutsideALiveMatchOrWithoutACueBall() {
        val notLive = layers(live = false, source = AimSource.USER_MANUAL)
        assertFalse(notLive.ballMarkers)
        assertFalse(notLive.aimPreview)
        assertFalse(notLive.physicsPaths)

        val noCue = layers(cue = false, source = AimSource.USER_MANUAL)
        assertTrue(noCue.ballMarkers)
        assertFalse(noCue.aimPreview)
        assertFalse(noCue.physicsPaths)
    }

    @Test
    fun physicsPathsNeverAppearWithoutThePreview() {
        for (source in AimSource.values()) for (detected in listOf(true, false)) for (live in listOf(true, false)) {
            for (cue in listOf(true, false)) for (pred in listOf(true, false)) for (shot in listOf(true, false)) {
                val l = layers(live, cue, source, detected, pred, shot)
                if (l.physicsPaths) assertTrue(l.aimPreview)
            }
        }
    }
}
