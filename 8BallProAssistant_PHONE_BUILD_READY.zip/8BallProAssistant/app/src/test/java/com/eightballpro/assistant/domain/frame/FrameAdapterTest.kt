package com.eightballpro.assistant.domain.frame

import com.eightballpro.assistant.domain.vision.ArgbImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FrameAdapterTest {

    /** Frame whose pixel at (x, y) has R = x, G = y, B = 7, A = 255. Optional row padding. */
    private fun frame(width: Int, height: Int, padding: Int = 0): RawFrame {
        val stride = width * 4 + padding
        val bytes = ByteArray(stride * height) { (1).toByte() }
        for (y in 0 until height) for (x in 0 until width) {
            val i = y * stride + x * 4
            bytes[i] = x.toByte(); bytes[i + 1] = y.toByte(); bytes[i + 2] = 7; bytes[i + 3] = 0xFF.toByte()
        }
        return RawFrame(width, height, stride, bytes)
    }

    private fun converted(result: FrameConversion): ArgbImage {
        assertTrue("expected success, got $result", result is FrameConversion.Converted)
        return (result as FrameConversion.Converted).image
    }

    @Test
    fun nullFrameIsRejectedNotGuessed() {
        assertTrue(FrameAdapter.convert(null) is FrameConversion.Rejected)
    }

    @Test
    fun invalidDimensionsAreRejected() {
        assertTrue(FrameAdapter.convert(RawFrame(0, 10, 0, ByteArray(0))) is FrameConversion.Rejected)
        assertTrue(FrameAdapter.convert(RawFrame(FrameAdapter.MAX_DIMENSION + 1, 1, 0, ByteArray(0))) is FrameConversion.Rejected)
    }

    @Test
    fun stridesSmallerThanARowAreRejected() {
        assertTrue(FrameAdapter.convert(RawFrame(4, 2, 8, ByteArray(32))) is FrameConversion.Rejected)
    }

    @Test
    fun shortBuffersAreRejected() {
        assertTrue(FrameAdapter.convert(RawFrame(4, 2, 16, ByteArray(20))) is FrameConversion.Rejected)
    }

    @Test
    fun emptyOrOutOfBoundsCropIsRejected() {
        val f = frame(4, 4)
        assertTrue(FrameAdapter.convert(f, CropRect(2, 2, 2, 3)) is FrameConversion.Rejected)
        assertTrue(FrameAdapter.convert(f, CropRect(0, 0, 5, 4)) is FrameConversion.Rejected)
    }

    @Test
    fun pixelValuesAreMappedToArgbWithPadding() {
        val img = converted(FrameAdapter.convert(frame(3, 2, padding = 5)))
        assertEquals(3, img.width)
        assertEquals(2, img.height)
        val p = img.pixelAt(2, 1)
        assertEquals(0xFF, (p ushr 24) and 0xFF)
        assertEquals(2, (p shr 16) and 0xFF)
        assertEquals(1, (p shr 8) and 0xFF)
        assertEquals(7, p and 0xFF)
    }

    @Test
    fun cropKeepsOnlyTheRequestedRegion() {
        val img = converted(FrameAdapter.convert(frame(6, 6), CropRect(2, 1, 5, 4)))
        assertEquals(3, img.width)
        assertEquals(3, img.height)
        // Top-left of the crop is source (2, 1).
        assertEquals(2, (img.pixelAt(0, 0) shr 16) and 0xFF)
        assertEquals(1, (img.pixelAt(0, 0) shr 8) and 0xFF)
    }

    @Test
    fun quarterTurnsSwapDimensions() {
        val img = converted(FrameAdapter.convert(frame(4, 2), rotation = FrameRotation.R90))
        assertEquals(2, img.width)
        assertEquals(4, img.height)
    }

    @Test
    fun rotationsMatchNaiveReferenceOnCroppedRegion() {
        val src = frame(5, 4, padding = 3)
        val crop = CropRect(1, 1, 4, 4) // 3 wide, 3 high
        val base = referenceCrop(src, crop)
        for (rot in FrameRotation.values()) {
            val got = converted(FrameAdapter.convert(src, crop, rot))
            val expected = referenceRotate(base, rot)
            assertEquals("width for $rot", expected.first, got.width)
            assertEquals("height for $rot", expected.second, got.height)
            assertTrue("pixels for $rot", got.pixels.contentEquals(expected.third))
        }
    }

    /** Naive reference: crop, then rotate with explicit 2D loops. Clockwise for R90. */
    private fun referenceCrop(src: RawFrame, c: CropRect): Triple<Int, Int, IntArray> {
        val out = IntArray(c.width * c.height)
        for (y in 0 until c.height) for (x in 0 until c.width) {
            out[y * c.width + x] = pixel(src, c.left + x, c.top + y)
        }
        return Triple(c.width, c.height, out)
    }

    private fun referenceRotate(base: Triple<Int, Int, IntArray>, rot: FrameRotation): Triple<Int, Int, IntArray> {
        val (w, h, px) = base
        fun at(x: Int, y: Int) = px[y * w + x]
        return when (rot) {
            FrameRotation.R0 -> Triple(w, h, px.copyOf())
            FrameRotation.R90 -> Triple(h, w, IntArray(w * h) { i -> val ox = i % h; val oy = i / h; at(oy, h - 1 - ox) })
            FrameRotation.R180 -> Triple(w, h, IntArray(w * h) { i -> val ox = i % w; val oy = i / w; at(w - 1 - ox, h - 1 - oy) })
            FrameRotation.R270 -> Triple(h, w, IntArray(w * h) { i -> val ox = i % h; val oy = i / h; at(w - 1 - oy, ox) })
        }
    }

    private fun pixel(src: RawFrame, x: Int, y: Int): Int {
        val i = y * src.rowStrideBytes + x * 4
        val b = src.bytes
        return ((b[i + 3].toInt() and 0xFF) shl 24) or ((b[i].toInt() and 0xFF) shl 16) or
            ((b[i + 1].toInt() and 0xFF) shl 8) or (b[i + 2].toInt() and 0xFF)
    }
}
