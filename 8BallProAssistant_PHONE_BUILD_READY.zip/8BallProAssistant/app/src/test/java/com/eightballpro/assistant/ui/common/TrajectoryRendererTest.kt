package com.eightballpro.assistant.ui.common

import com.eightballpro.assistant.domain.assistant.AimSettings
import com.eightballpro.assistant.domain.physics3d.BallPhysics
import com.eightballpro.assistant.domain.physics3d.CUE_BALL_ID
import com.eightballpro.assistant.domain.physics3d.Frame
import com.eightballpro.assistant.domain.physics3d.PoolBall
import com.eightballpro.assistant.domain.physics3d.PoolPhysicsEngine
import com.eightballpro.assistant.domain.physics3d.TableGeometry3D
import com.eightballpro.assistant.domain.physics3d.Vec3
import com.eightballpro.assistant.domain.table.TableSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Unit tests for [TrajectoryRenderer].
 *
 * Verifies:
 * 1. Metre-to-normalised conversion.
 * 2. Normalised-to-screen conversion.
 * 3. Aim line is non-trivial when cue and aim differ.
 * 4. Aim line is trivial when cue and aim are the same.
 * 5. Placeholder cue position when no detection.
 * 6. Detected cue ball position used over placeholder.
 * 7. Horizontal trajectory through physics frames.
 * 8. Vertical trajectory through physics frames.
 * 9. Diagonal trajectory.
 * 10. Out-of-bounds metres returns null.
 * 11. Empty physics frames produce no path.
 * 12. Missing cue ball detection triggers MANUAL_AIM_PREVIEW status.
 * 13. Prediction unavailable → CUE_DETECTED_MANUAL_AIM or WAITING_FOR_CUE_BALL.
 * 14. LIVE_PREDICTION status when all data available.
 * 15. Object ball path filtered out when it doesn't move.
 * 16. Object ball path retained when it moves significantly.
 * 17. Canvas scale is uniform (table aspect ratio preserved).
 * 18. Corner pocket at (0,0) maps to canvas top-left corner (within inset).
 * 19. Physics simulation frames are correctly converted in a real simulation.
 */
class TrajectoryRendererTest {

    private val table    = TableGeometry3D.from(TableSpec.NINE_FOOT)
    private val tLen     = table.length   // 2.54 m
    private val tWid     = table.width    // 1.27 m
    private val r        = BallPhysics.RADIUS_M

    // A generous canvas: landscape, similar to the 240 dp panel at hdpi.
    private val canvasW  = 720f
    private val canvasH  = 360f
    private val inset    = 16f

    // ── Helper: make a Frame with the given ball positions ───────────────────
    private fun frame(vararg balls: Pair<Int, Vec3>): Frame =
        Frame(0.0, balls.associate { (id, pos) -> id to pos })

    // ── Helper: check two Doubles are approximately equal ────────────────────
    private fun assertApprox(expected: Double, actual: Double, eps: Double = 1e-9) {
        assertEquals("expected ≈ $expected, got $actual", expected, actual, eps)
    }

    private fun assertApproxF(expected: Float, actual: Float, eps: Float = 1e-3f) {
        assertEquals("expected ≈ $expected, got $actual", expected, actual, eps)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 1. metresToNormalised — in-bounds
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun metresToNormalised_centreOfTable() {
        val (u, v) = TrajectoryRenderer.metresToNormalised(tLen / 2, tWid / 2, tLen, tWid)!!
        assertApprox(0.5, u)
        assertApprox(0.5, v)
    }

    @Test fun metresToNormalised_topLeftCorner() {
        val (u, v) = TrajectoryRenderer.metresToNormalised(0.0, 0.0, tLen, tWid)!!
        assertApprox(0.0, u)
        assertApprox(0.0, v)
    }

    @Test fun metresToNormalised_bottomRightCorner() {
        val (u, v) = TrajectoryRenderer.metresToNormalised(tLen, tWid, tLen, tWid)!!
        assertApprox(1.0, u)
        assertApprox(1.0, v)
    }

    @Test fun metresToNormalised_quarterPoint() {
        val (u, v) = TrajectoryRenderer.metresToNormalised(tLen * 0.25, tWid * 0.75, tLen, tWid)!!
        assertApprox(0.25, u, 1e-9)
        assertApprox(0.75, v, 1e-9)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. metresToNormalised — out-of-bounds
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun metresToNormalised_farOutsideReturnsNull() {
        assertNull(TrajectoryRenderer.metresToNormalised(-1.0, 0.5, tLen, tWid))
        assertNull(TrajectoryRenderer.metresToNormalised(tLen + 1.0, 0.5, tLen, tWid))
        assertNull(TrajectoryRenderer.metresToNormalised(0.5, -1.0, tLen, tWid))
        assertNull(TrajectoryRenderer.metresToNormalised(0.5, tWid + 1.0, tLen, tWid))
    }

    @Test fun metresToNormalised_slightlyOutsideWithinMarginReturnsClampedValue() {
        // The default margin is 5 %; a value at -0.03*tLen is within tolerance
        val uv = TrajectoryRenderer.metresToNormalised(-0.03 * tLen, tWid / 2, tLen, tWid)
        assertNotNull(uv)
        assertApprox(0.0, uv!!.first)   // clamped to 0
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. normalisedToScreen — spot checks
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun normToScreen_centreOfTableMapsToApproximatelyCentreOfCanvas() {
        val (x, y) = TrajectoryRenderer.normalisedToScreen(0.5, 0.5, canvasW, canvasH, tLen, tWid, inset)
        // The table is centred in the canvas; centre of table ≈ centre of canvas.
        assertEquals(canvasW / 2f, x, 1f)
        assertEquals(canvasH / 2f, y, 1f)
    }

    @Test fun normToScreen_topLeftIsInsideInset() {
        val (x, y) = TrajectoryRenderer.normalisedToScreen(0.0, 0.0, canvasW, canvasH, tLen, tWid, inset)
        // Top-left corner must be at or beyond the inset (table is centred).
        assertTrue("x=$x should be >= inset=$inset", x >= inset)
        assertTrue("y=$y should be >= inset=$inset", y >= inset)
    }

    @Test fun normToScreen_bottomRightIsInsideCanvas() {
        val (x, y) = TrajectoryRenderer.normalisedToScreen(1.0, 1.0, canvasW, canvasH, tLen, tWid, inset)
        assertTrue("x=$x should be <= canvasW=$canvasW", x <= canvasW)
        assertTrue("y=$y should be <= canvasH=$canvasH", y <= canvasH)
    }

    @Test fun normToScreen_uniformScale_tableAspectRatioPreserved() {
        // The table is 2× as long as it is wide. The pixel width of the table should be 2× the height.
        val (x0, y0) = TrajectoryRenderer.normalisedToScreen(0.0, 0.0, canvasW, canvasH, tLen, tWid, inset)
        val (x1, y1) = TrajectoryRenderer.normalisedToScreen(1.0, 0.0, canvasW, canvasH, tLen, tWid, inset)
        val (_, y2)  = TrajectoryRenderer.normalisedToScreen(0.0, 1.0, canvasW, canvasH, tLen, tWid, inset)
        val tablePixelW = x1 - x0
        val tablePixelH = y2 - y0
        // Expected aspect ratio: tLen / tWid = 2.54 / 1.27 = 2.0
        val expectedRatio = (tLen / tWid).toFloat()
        assertEquals(expectedRatio, tablePixelW / tablePixelH, 0.01f)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 4. Aim line non-trivial when cue and aim differ
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun aimLine_nonTrivialWhenDifferentPositions() {
        // Placeholder cue at (0.25, 0.5), aim at (0.75, 0.5) — clearly different
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(targetU = 0.75, targetV = 0.5, power = 0.5),
            predAvailable = false,
            physicsFrames = emptyList(),
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertTrue("aim line should be non-trivial", rs.aimLine.isNonTrivial)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 5. Aim line trivial when placeholder cue == aim target
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun aimLine_trivialWhenPlaceholderMatchesAim() {
        // Placeholder cue is at (0.25, 0.5). Aim set to exactly that.
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(
                targetU = TrajectoryRenderer.PLACEHOLDER_CUE_U,
                targetV = TrajectoryRenderer.PLACEHOLDER_CUE_V,
                power   = 0.5,
            ),
            predAvailable = false,
            physicsFrames = emptyList(),
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertFalse("aim line should be trivial when both endpoints coincide", rs.aimLine.isNonTrivial)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 6. Default aim (0.5, 0.5) produces a visible line from placeholder (0.25, 0.5)
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun aimLine_defaultAimFromPlaceholderIsVisible() {
        // This is THE key regression: AimSettings() defaults to targetU=0.5, targetV=0.5.
        // Placeholder cue is at (0.25, 0.5). The line must be non-trivial.
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(), // defaults: targetU=0.5, targetV=0.5
            predAvailable = false,
            physicsFrames = emptyList(),
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertTrue(
            "Default aim (0.5,0.5) from placeholder cue (0.25,0.5) must produce a visible aim line. " +
                "isNonTrivial=${rs.aimLine.isNonTrivial} " +
                "fromU=${rs.aimLine.fromU} toU=${rs.aimLine.toU}",
            rs.aimLine.isNonTrivial,
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 7. Placeholder cue when no detection
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun cueBall_usesPlaceholderWhenNoDetection() {
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = false,
            physicsFrames = emptyList(),
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertFalse(rs.cueBall.isDetected)
        assertApprox(TrajectoryRenderer.PLACEHOLDER_CUE_U, rs.cueBall.u)
        assertApprox(TrajectoryRenderer.PLACEHOLDER_CUE_V, rs.cueBall.v)
        assertEquals(TrajectoryRenderer.CanvasStatus.MANUAL_AIM_PREVIEW, rs.status)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 8. Empty physics frames → empty cuePath
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun cuePath_emptyWhenNoFrames() {
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = emptyList(),
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertTrue(rs.cuePath.isEmpty())
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 9. Horizontal trajectory: frames from (x=r, y=midY) to (x=1.0, y=midY)
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun cuePath_horizontalTrajectory() {
        val midY = tWid / 2
        val frames = listOf(
            frame(CUE_BALL_ID to Vec3(0.1, midY, r)),
            frame(CUE_BALL_ID to Vec3(0.5, midY, r)),
            frame(CUE_BALL_ID to Vec3(1.0, midY, r)),
        )
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = frames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertEquals(3, rs.cuePath.size)
        // All v values should be equal (midY / tWid = 0.5)
        rs.cuePath.forEach { pt ->
            assertApprox(0.5, pt.v, 1e-9)
        }
        // u values should increase
        assertTrue(rs.cuePath[0].u < rs.cuePath[1].u)
        assertTrue(rs.cuePath[1].u < rs.cuePath[2].u)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 10. Vertical trajectory
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun cuePath_verticalTrajectory() {
        val midX = tLen / 2
        val frames = listOf(
            frame(CUE_BALL_ID to Vec3(midX, 0.1, r)),
            frame(CUE_BALL_ID to Vec3(midX, 0.5, r)),
            frame(CUE_BALL_ID to Vec3(midX, 1.0, r)),
        )
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = frames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertEquals(3, rs.cuePath.size)
        // All u values should be equal (midX / tLen = 0.5)
        rs.cuePath.forEach { pt -> assertApprox(0.5, pt.u, 1e-9) }
        // v values should increase
        assertTrue(rs.cuePath[0].v < rs.cuePath[1].v)
        assertTrue(rs.cuePath[1].v < rs.cuePath[2].v)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 11. Diagonal trajectory
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun cuePath_diagonalTrajectory() {
        val frames = listOf(
            frame(CUE_BALL_ID to Vec3(0.2, 0.2, r)),
            frame(CUE_BALL_ID to Vec3(0.8, 0.8, r)),
        )
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = frames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertEquals(2, rs.cuePath.size)
        assertTrue(rs.cuePath[0].u < rs.cuePath[1].u)
        assertTrue(rs.cuePath[0].v < rs.cuePath[1].v)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 12. Out-of-bounds frames are dropped
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun cuePath_outOfBoundsFramesDropped() {
        val frames = listOf(
            frame(CUE_BALL_ID to Vec3(0.5, 0.5, r)),   // valid
            frame(CUE_BALL_ID to Vec3(10.0, 10.0, r)), // wildly out of bounds
            frame(CUE_BALL_ID to Vec3(1.0, 0.5, r)),   // valid
        )
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = frames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        // The out-of-bounds frame should be excluded
        assertEquals(2, rs.cuePath.size)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 13. Object ball path filtered out when it doesn't move
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun objectPath_filteredWhenStationary() {
        val midY  = tWid / 2
        val objId = 1
        // Object ball stays exactly at (1.0, midY) across all frames
        val frames = listOf(
            frame(CUE_BALL_ID to Vec3(0.1, midY, r), objId to Vec3(1.0, midY, r)),
            frame(CUE_BALL_ID to Vec3(0.5, midY, r), objId to Vec3(1.0, midY, r)),
        )
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = frames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertTrue("stationary object ball path should be filtered out", rs.objectPaths.isEmpty())
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 14. Object ball path retained when it moves significantly
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun objectPath_retainedWhenMoving() {
        val midY  = tWid / 2
        val objId = 1
        val frames = listOf(
            frame(CUE_BALL_ID to Vec3(0.1, midY, r), objId to Vec3(0.5, midY, r)),
            frame(CUE_BALL_ID to Vec3(0.4, midY, r), objId to Vec3(1.5, midY, r)),
        )
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = frames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertTrue("moving object ball path should be retained", rs.objectPaths.containsKey(objId))
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 15. Status transitions
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun status_manualAimPreviewWhenNoResult() {
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = false,
            physicsFrames = emptyList(),
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertEquals(TrajectoryRenderer.CanvasStatus.MANUAL_AIM_PREVIEW, rs.status)
    }

    @Test fun status_livePredictionWhenAllDataAvailable() {
        // Build a minimal AnalysisResult with a detected cue ball at (0.25, 0.5)
        val fakeResult = buildFakeAnalysisResultWithCue(cueBallU = 0.25, cueBallV = 0.5)
        val fakeFrames = listOf(
            frame(CUE_BALL_ID to Vec3(0.25 * tLen, 0.5 * tWid, r)),
            frame(CUE_BALL_ID to Vec3(0.75 * tLen, 0.5 * tWid, r)),
        )
        val rs = TrajectoryRenderer.deriveState(
            latestResult  = fakeResult,
            aim           = AimSettings(targetU = 0.75, targetV = 0.5, power = 0.5),
            predAvailable = true,
            physicsFrames = fakeFrames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertEquals(TrajectoryRenderer.CanvasStatus.LIVE_PREDICTION, rs.status)
        assertTrue(rs.cueBall.isDetected)
        assertTrue(rs.aimLine.isNonTrivial)
        assertEquals(2, rs.cuePath.size)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 16. Physics engine frames convert correctly
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun physicsFrames_realSimulationConvertsCorrectly() {
        // Run the real physics engine and verify that the resulting frames map into [0,1]²
        val cueBall = PoolBall(
            CUE_BALL_ID,
            Vec3(0.25 * tLen, tWid / 2, r),
            Vec3(1.5, 0.0, 0.0),   // moving in +x direction
        )
        val result  = PoolPhysicsEngine(table, com.eightballpro.assistant.domain.physics.PhysicsConfig())
            .simulate(listOf(cueBall), maxTime = 2.0)
        assertTrue("simulation should produce at least 2 frames", result.frames.size >= 2)

        val rs = TrajectoryRenderer.deriveState(
            latestResult  = null,
            aim           = AimSettings(),
            predAvailable = true,
            physicsFrames = result.frames,
            tableLengthM  = tLen,
            tableWidthM   = tWid,
            canvasW       = canvasW,
            canvasH       = canvasH,
        )
        assertTrue("cuePath should not be empty for a moving ball", rs.cuePath.isNotEmpty())
        // All points must be in [0,1]
        rs.cuePath.forEach { pt ->
            assertTrue("u=${pt.u} out of range", pt.u in 0.0..1.0)
            assertTrue("v=${pt.v} out of range", pt.v in 0.0..1.0)
        }
        // The ball moved in +x, so the last point should have higher u than the first
        assertTrue(
            "ball moving right: last u (${rs.cuePath.last().u}) should be > first u (${rs.cuePath.first().u})",
            rs.cuePath.last().u > rs.cuePath.first().u,
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 17. Corner pocket at (0,0) maps to canvas near top-left after inset
    // ─────────────────────────────────────────────────────────────────────────
    @Test fun pocketCorner_mapsToTopLeftRegion() {
        val (x, y) = TrajectoryRenderer.normalisedToScreen(0.0, 0.0, canvasW, canvasH, tLen, tWid, inset)
        // Should be somewhere in the top-left quadrant, within the canvas
        assertTrue("x=$x should be >= inset", x >= inset - 1f)
        assertTrue("y=$y should be >= inset", y >= inset - 1f)
        assertTrue("x=$x should be < canvasW/2", x < canvasW / 2f)
        assertTrue("y=$y should be < canvasH / 2", y < canvasH / 2f)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Builds a minimal [com.eightballpro.assistant.domain.analysis.AnalysisResult] with one
     * detected cue ball at the specified normalised position. All other fields are minimal stubs.
     */
    private fun buildFakeAnalysisResultWithCue(cueBallU: Double, cueBallV: Double):
            com.eightballpro.assistant.domain.analysis.AnalysisResult {
        val cueBall = com.eightballpro.assistant.domain.analysis.DetectedBall(
            id         = null,
            cls        = com.eightballpro.assistant.domain.vision.BallClass.CUE,
            centre     = com.eightballpro.assistant.domain.vision.Point2D(cueBallU, cueBallV),
            assessment = com.eightballpro.assistant.domain.vision.Assessment(
                score   = 1.0,
                level   = com.eightballpro.assistant.domain.vision.Confidence.HIGH,
                reasons = listOf("test"),
            ),
            source     = com.eightballpro.assistant.domain.analysis.DetectionSource.MANUAL,
        )
        return com.eightballpro.assistant.domain.analysis.AnalysisResult(
            analysedWidth    = 480,
            analysedHeight   = 270,
            table            = null,
            tableAssessment  = null,
            calibration      = null,
            balls            = listOf(cueBall),
            unmappedBlobs    = 0,
            warnings         = emptyList(),
        )
    }
}
