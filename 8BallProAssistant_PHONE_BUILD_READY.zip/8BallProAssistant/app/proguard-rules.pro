# Batch 1: no reflection-based libraries yet. Rules will be added when
# serialization, networking or native code is introduced in later batches.
