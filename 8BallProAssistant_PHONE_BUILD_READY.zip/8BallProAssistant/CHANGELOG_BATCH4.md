> Historical. See CHANGELOG.md for the current state.

# Changelog — Batch 4 (partial)

## Added (new files only)
- `domain/frame/FrameAdapter.kt`: converts a RawFrame (RGBA_8888, row stride) to ArgbImage, with crop and rotation (0/90/180/270) in one pass. Rejects null frames, invalid sizes, short buffers, empty or out-of-bounds crops.
- `domain/assistant/AssistantRunMachine.kt`: RunState (STOPPED, RUNNING, PAUSED) and events Start, Pause, Resume, Stop, CaptureEnded. Start needs an active capture. Frames are processed only while RUNNING and not overlapping.
- `domain/assistant/AssistantPresenter.kt`: DetectionView and PredictionView. Predictions are withheld without a confident cue or a simulated shot. Confidence is at most MEDIUM.
- Tests: `FrameAdapterTest` (crop, padding, rotations against a naive reference), `AssistantTest.kt` (run machine, presenter).
- `tools/frame_adapter_reference_model.py`: Python reference of the crop and rotation mapping. 49 of 49 pass.
- `BATCH4_AUDIT.md`, `TEST_REPORT_BATCH4.md`, `BUILD_REPORT_BATCH4.md`.

## Modified
- `tools/audit_project.py`: Batch 4 label and pending issues.

## Not modified
- No Batch 3 source file, test, manifest, or Gradle file was changed. Verified by SHA-256 comparison with the baseline.

## Not added (blocked)
- Floating bubble, panel, overlay service, MediaProjection, notifications, manifest service entries. Require the Android Studio project ZIP.
