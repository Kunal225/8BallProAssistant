> Historical. See CHANGELOG.md for the current state.

# Changelog — Batch 3 (domain layer, not yet compiled)

## Scope completed in this increment

Batch 3 is being built in steps. This increment completes the pure-Kotlin domain layer. The Android
service, windows, and MediaProjection code are NOT in this increment and are listed under "Not yet".

### 3.1 Dual game mode and policy (`domain/mode`)
- `GameMode.OWN_GAME_AUTHORIZED` (Mode A) and `GameMode.THIRD_PARTY_SCREENSHOT` (Mode B).
- `ModePolicy.decideLiveCapture`: live capture is refused for Mode B in all cases, and for Mode A until the
  user acknowledges authorisation.
- Mode B capabilities: screenshot import and offline practice only. No live capture, no live analysis.

### 3.2 Overlay state management (`domain/overlay`)
- Pure state machine: Hidden, NeedsPermission, Bubble, Panel.
- Transitions: permission flow, show with saved position, tap to expand, minimise, close, drag with
  clamping, snap to nearest screen edge. Invalid events leave the state unchanged.

### 3.3 Capture state management (`domain/capture`)
- Pure state machine: Idle, AwaitingConsent, Capturing, Stopped, Denied.
- Invariant: `Capturing` is reachable only from `AwaitingConsent` through `ConsentGranted`, and
  `AwaitingConsent` is reachable only through a `RequestCapture` that passes the mode policy.
- Stop cancels a pending request. System termination and rotation are handled as events.

### 3.4 Image analysis (`domain/vision`)
- `ArgbImage`, box `Downsampler` (memory limit), `ColorProfile` (HSV felt rule), `hueDegrees`.
- `TableBoundaryDetector`: felt bounding box from row and column density.
- `BallDetector`: connected components of non-felt pixels inside the table, with fill ratio and mean colour.
- `BallClassifier`: CUE, OBJECT, BLACK, or UNCERTAIN. Striped balls are UNCERTAIN by design.

### 3.5 Calibration and confidence (`domain/vision`, `domain/analysis`)
- `PerspectiveCalibration`: four-corner bilinear model with inverse mapping by Newton iteration and validity check.
  Exact for axis-aligned tables; approximate for trapezoidal views.
- `ConfidenceEvaluator`: roundness, size against the expected ball size, classification clarity, and
  inside/outside play area. Produces HIGH, MEDIUM, LOW, UNCERTAIN, or USER_CONFIRMED, with reasons.
- `ManualEdits`: move, add, and remove balls. Manual edits are marked USER_CONFIRMED.
- `AnalysisPipeline`: shared by Mode A frames and Mode B screenshots. Positions are table-normalised, so they
  do not depend on screen resolution. The pipeline does not store or upload images.

### 3.6 Physics integration (`domain/analysis`)
- `DetectionToPhysics.build`: only HIGH, MEDIUM, or user-confirmed balls are used. Excluded balls are reported.
- `ShotPrediction.predict`: builds a new `ShotResult` from the detected cue. Does not modify the detections.
  Reuses the Batch 2 engine. Real-world accuracy is not claimed.

## Verification performed in this environment
- Python reference model of the vision algorithms (`tools/vision_reference_model.py`): 9 of 9 checks pass on
  synthetic images. This checks the algorithms, not the Kotlin code.
- Structural check of all Kotlin files: brackets balanced, packages match folders (0 issues in 49 files).

## Not yet implemented (later increments)
- 3.7 Android layer: foreground service, floating bubble and panel windows, MediaProjection consent and capture,
  rotation handling in the Android layer, service restart handling, and the manifest permissions and service declaration.
- Bitmap adapter from the Android `Bitmap` / `ImageReader` to `ArgbImage`.
- Panel UI sections (Dashboard, Game Mode, Screen Capture, Table Analysis, Ball Detection, Physics,
  Trajectory Preview, Calibration, Settings) and the practice simulator screen integration.
- Hindi and English strings.
- Instrumented and device tests.
- Build and unit-test results. Nothing in this increment has been compiled or run.
